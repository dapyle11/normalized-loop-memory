# Finite-alphabet communication with noisy forward memory in a normalized loop

AI-assisted mathematical research draft prepared for Daniel A. Pyle, 30 October 2026.

## What this repository contains

This archive collects the complete research notebook, its later audit addendum,
and their existing reproducibility releases. It is intended to be uploaded to a
new GitHub repository as one ZIP. Uploading the ZIP does not require unpacking it.
Researchers who want to run the code can download and extract it locally.

- `documents/`: the 34-page extended notebook and 8-page review addendum.
- `extended_research/`: proofs, exact certificates, simulations, and the original
  verification runner, expanded into an ordinary directory for use.
- `review_addendum/`: the fresh adversarial checks, physical-boundary diagnostic,
  elementary proofs, reviewer questions, and source for the audit addendum.
- `release_archives/`: both original source ZIPs preserved byte-for-byte.
- `provenance.json`: exact release sizes and hashes.
- `manifest.sha256`: integrity hashes for this combined archive's files.

The focused manuscript being prepared for Hexagon is not included in this
research snapshot. It will cite this repository when its public URL is supplied.
The archive does not contain a placeholder or invented repository URL.

## Scientific scope

The main model assumes one backward classical binary symmetric channel and one
charged forward bit or qubit, with no additional shared seed, retained side
record, or shared entanglement. It optimizes worst-message success under
message-dependent normalization for a single use. Exact finite-alphabet
characterizations and proofs are given under those assumptions. Four messages
are the minimum for a strict qubit advantage in this particular model; that is
not a claim about general quantum communication or a physical time-travel device.

The backward channel is an assumed mathematical resource, not a constructed
receiver. Ordinary forward-running simulations with later selection do not send
information into the past. The addendum explains the physical gap and gives
credited applications of established no-backward-signalling and probability
results. A controllable physical enforcement mechanism has not been derived.

This work was generated and checked with AI assistance. Separate checks within
that workflow are not independent human peer review or proof-assistant
verification. Independent human review and a complete originality comparison
remain pending. No claim of scientific priority, physical realization, or
resolution of the general many-use noisy-memory capacity problem is made.
The code, notebook and addendum must be interpreted with their stated resource
restrictions and cited prior work.

## Reproduce the calculations

The expanded source directories are byte-identical to the contents of the
preserved releases. Verify integrity before rerunning, because some scripts
rewrite generated results and timing metadata:

```sh
sha256sum -c manifest.sha256
```

Use Python 3.11 or later. The original research release lists NumPy, SciPy,
SymPy and mpmath in its requirements file; the addendum uses NumPy and SymPy.
Installing those dependencies in a virtual environment is sufficient. Tested
versions are recorded inside the releases.

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r extended_research/requirements.txt
(cd extended_research && python run_checks.py --full)
(cd review_addendum && python run_checks.py)
```

For the standard-library-only subset of the original exact certificates:

```sh
(cd extended_research && python run_checks.py --certificates-only)
```

Read each directory's README for PDF rebuilding and optional exploratory
calculations. Tests are mathematical checks, not laboratory experiments.
The original releases' recorded results are preserved; any additional packaging
rerun is described in the accompanying packaging verification record.

## Provenance and licensing

The PDFs, source archives and expanded contents are preserved without changes to
formulas, code, proofs or results. This wrapper adds only navigation, provenance,
and integrity records. It does not silently relicense the software or grant a
new license to third-party material. No repository-wide software license has
been assigned by this packaging. Source-specific notices and cited works remain
applicable; a public upload alone is not an open-source license grant.

No external reviewer, laboratory experiment, GitHub publication or Hexagon
submission is represented as having occurred. The owner performs publication.
