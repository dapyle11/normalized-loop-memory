"""Run all addendum checks from any current working directory."""
from pathlib import Path
from datetime import datetime, timezone
import json
import platform
import subprocess
import sys
import numpy
import sympy

root = Path(__file__).resolve().parent
results = root / 'results'
results.mkdir(exist_ok=True)
scripts = ['adversarial_checks.py', 'bernstein_rederive.py',
           'physical_signal_criterion_verify.py', 'boundary_ledger_verify.py']
for name in scripts:
    print('\nRUN', name, flush=True)
    result = subprocess.run([sys.executable, str(root / 'tests' / name)],
                            cwd=root, text=True, capture_output=True)
    (results / (Path(name).stem + '.log')).write_text(result.stdout + result.stderr)
    print(result.stdout, end='')
    if result.returncode:
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
summary = {'status': 'PASS', 'scripts': scripts,
           'timestamp_utc': datetime.now(timezone.utc).isoformat(),
           'python': platform.python_version(), 'numpy': numpy.__version__,
           'sympy': sympy.__version__,
           'scope': 'Mathematical checks only; not a physical experiment or human review.'}
(results / 'run_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('\nAll four verification scripts passed.')
