#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for pass in 1 2; do
  pdflatex -interaction=nonstopmode -halt-on-error review_addendum.tex > build.log 2>&1 || {
    tail -60 build.log
    exit 1
  }
done
printf 'Built review_addendum.pdf\n'
