# Backward information audit and physical requirements

Prepared for Daniel Pyle, 30 October 2026. This is an AI-generated and AI-checked
research addendum, not independent human review, a novelty determination,
submission-ready research, or a physical backward-channel demonstration.

## What is included

- `review_addendum.tex`: the complete source for the accompanying PDF.
- `source_memos/`: finalized mathematical audit, physical criterion, physics-gap
  audit, human review questions and the bounded prior-art comparison.
- `tests/`: four runnable verification scripts and the exact rational
  finite-alphabet oracle imported by the adversarial checker.
- `results/`: outputs and logs from the release's verification run, plus runtime
  versions and a UTC run timestamp.
- `manifest.sha256`: integrity hashes of the packaged sources and recorded results.

The earlier 34-page notebook is not duplicated or modified. Its broader claims
are not newly certified here. The PDF contains full proofs of the final-effect
criterion and contrast bounds it presents. The restricted communication theorem
audit is reported rather than reproducing that entire earlier proof.

## Reproduce the checks

Use Python 3.11 or later with NumPy and SymPy. For a fresh virtual environment:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python run_checks.py
```

The runner uses paths relative to its own file, so it also works from another
working directory. It overwrites generated files in `results/` only. Expected
results are summarized on the PDF's reproducibility page. Tiny floating-point
residuals may differ by platform; symbolic and rational checks use exact equality.
The stated scripts' random seeds are fixed. No optimizer or internet access is
required by the tests.

The release scripts were run successfully after extraction into a clean temporary
directory. Review `results/run_summary.json` for the actual versions. A subsequent
rerun will change timestamps and possibly numeric residuals, so perform the
integrity check before rerunning if you want to verify the packaged originals.

## Rebuild the PDF

Use a normal TeX Live installation providing pdfLaTeX, Latin Modern, AMS packages,
mathtools, booktabs, enumitem, microtype, hyperref and fancyhdr:

```sh
bash build_pdf.sh
```

This builds `review_addendum.pdf`. The PDF's metadata timestamp can vary. Neither
the numerical tests nor LaTeX compilation establishes scientific validity. The
delivered PDF was separately rendered and every page visually inspected.

## Provenance and portability edits

The audit and final-effect scripts were copied from the finalized research pass.
Only import/output paths were made bundle-relative; formulas, seeds, sample
counts and assertions were preserved. The exact rational oracle was copied
without mathematical edits. `boundary_ledger_verify.py` independently checks the
reset and setting-bias examples using rational arithmetic. `run_checks.py` runs
these four scripts and records their environment. Source memos retain their
research prose and refer to script basenames; the actual scripts are in `tests/`.

The memos' phrases such as independently rederived refer only to checks within
the AI research workflow, not review by an independent human. All sources remain
subject to the assumptions, scope limits and primary-source attributions stated
in the PDF. No external reviewer, experiment or submission is represented here.

## Integrity

From the extracted root, run `sha256sum -c manifest.sha256` before rerunning tests.
