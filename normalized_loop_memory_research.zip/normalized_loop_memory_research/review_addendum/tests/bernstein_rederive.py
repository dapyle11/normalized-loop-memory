from pathlib import Path
import sympy as s, json
from math import comb
v,w,x=s.symbols('v w x');p=w/(v*(v+1));A=1-p
t=A*v/(1+A*v);a=A*v*v/(v*v+1-w);h=a-s.Rational(1,2);C=t/A;T=1-C/2
Q=2*(T*T-(t-T/2)**2/h**2)+t*C*C/(2*(1-t))
# Strip the claimed strictly positive scale, then reconstruct the polynomial from the original Q.
R=s.factor(Q*2*(v-1)**2*(1+A*v)**4/(A*v)*(v+1)**3)
R=s.Poly(s.cancel(R.subs(v,1+3*x)),x,w)
assert R.degree(x)==9 and R.degree(w)==3
B=[]
for i in range(10):
 row=[]
 for j in range(4):
  b=sum(R.coeff_monomial(x**k*w**l)*s.Rational(comb(i,k),comb(9,k))*s.Rational(comb(j,l),comb(3,l)) for k in range(i+1) for l in range(j+1))
  assert b<=0
  row.append(b)
 B.append(row)
assert all(b<0 for b in B[-1])
rebuild=sum(B[i][j]*comb(9,i)*x**i*(1-x)**(9-i)*comb(3,j)*w**j*(1-w)**(3-j) for i in range(10) for j in range(4))
assert s.Poly(rebuild-R.as_expr(),x,w).is_zero
out={'all_40_coefficients_nonpositive':True,'last_row':[str(b) for b in B[-1]],'exact_reconstruction':True,'source':'Derived anew from quadratic maximum, not imported from existing verifier.'}
open(Path(__file__).resolve().parents[1]/'results'/'bernstein_results.json','w').write(json.dumps(out,indent=2)+'\n');print(out)
