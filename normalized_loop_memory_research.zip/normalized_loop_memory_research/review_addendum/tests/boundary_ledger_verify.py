"""Exact diagonal examples for ordinary selection, reset and setting bias."""
from fractions import Fraction as Q
from pathlib import Path
import json

checks = {}
for early in ([Q(1, 2), Q(1, 2)], [Q(3, 4), Q(1, 4)]):
    successes = []
    for x in (0, 1):
        success = [early[r] if r == x else Q(0) for r in (0, 1)]
        failure = [early[r] - success[r] for r in (0, 1)]
        assert [success[r] + failure[r] for r in (0, 1)] == early
        assert success[x] / sum(success) == 1
        # X control followed by reset to |0> makes final F certain for every r.
        reset_success = early[:]
        assert sum(reset_success) == 1
        assert reset_success == early
        successes.append(sum(success))
    assert successes == early
    selected_setting = [Q(1, 2) * z / sum(Q(1, 2) * s for s in successes)
                        for z in successes]
    assert selected_setting == early

checks['all_outcome_identity'] = True
checks['selected_r_equals_x'] = True
checks['certain_reset_leaves_earlier_distribution'] = True
checks['balanced_success_rates_do_not_create_all_trial_signal'] = True
checks['biased_setting_posterior'] = ['3/4', '1/4']
checks['status'] = 'PASS'
out = Path(__file__).resolve().parents[1] / 'results' / 'boundary_ledger_results.json'
out.write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps(checks, indent=2))
