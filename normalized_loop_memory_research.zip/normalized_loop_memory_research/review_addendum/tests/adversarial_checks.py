import sys,json
from pathlib import Path
import numpy as np
from fractions import Fraction as F
sys.path.insert(0,str(Path(__file__).resolve().parent))
from finite_alphabet_oracle import decision
rng=np.random.default_rng(202610300557)
I=np.eye(2);pauli=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]])
maxerr=0.;count=0
# Direct raw matrix contractions with entirely generic (not commuting or symmetric) preparations and effects.
for M in range(1,10):
 for trial in range(150):
  p=F(int(rng.integers(1,50)),100);eps=F(int(rng.integers(0,101)),100)
  row=rng.dirichlet(np.ones(M),size=2)
  tau=np.zeros((M,2,2,2),complex)
  for m in range(M):
   for b in range(2):
    v=rng.normal(size=3);v=v/np.linalg.norm(v)*rng.random()**.15
    tau[m,b]=row[b,m]*(I+np.einsum('i,ijk->jk',v,pauli))/2
  T=row.sum(axis=0)
  d=np.array([[np.trace((tau[m,0]-tau[m,1])@s).real for s in pauli] for m in range(M)])
  D=d.sum(axis=0);h=(1-2*float(p))*(1-float(eps))/2
  best=[]
  for m in range(M):
   opts=[np.zeros((2,2)),I]
   for _ in range(8):
    n=rng.normal(size=3);n/=np.linalg.norm(n);opts.append((I+np.einsum('i,ijk->jk',n,pauli))/2)
   vals=[]
   for E in opts:
    w=np.zeros(M)
    for y in range(M):
     for b in range(2):
      rho=(1-float(eps))*tau[y,b]+float(eps)*np.trace(tau[y,b])*I/2
      for a in range(2):
       w[y]+=(1-float(p) if a==b else float(p))*np.trace((E if a==0 else I-E)@rho).real
    vals.append(w[m]/w.sum())
    if np.isclose(np.trace(E),1):
     n=np.array([np.trace(E@s).real for s in pauli])
     formula=(T[m]/2+h*n@d[m])/(1+h*n@D)
     maxerr=max(maxerr,abs(formula-vals[-1]))
   best.append(max(vals))
  t=F(max(0,int(min(best)*10**8)-1),10**8)
  assert decision(M,p,eps,t)['feasible'], (M,p,eps,t)
  count+=1
# Scalar cap derived directly by squaring sphere-distance inequality.
import sympy as s
S,t,r,h=s.symbols('S t r h',positive=True)
a=s.Rational(1,2)+h
cap=(S*S+t*t*r*r-(t-S/2)**2/h**2)/(2*t*r)
L=t*(1-h*r)/a;H=t*(1+h*r)/a
assert s.simplify(cap.subs(S,L)+L)==0
assert s.simplify(cap.subs(S,H)-H)==0
assert s.simplify(s.diff(cap,S).subs(S,H)-1-(2-r)/(2*h*r))==0
assert s.simplify(s.diff(cap,S,2)-(1-1/(4*h*h))/(t*r))==0
out={'generic_raw_matrix_protocols':count,'largest_direct_contraction_vs_reduction_error':maxerr,'counterexamples':0,'symbolic_cap_checks':4,'limitations':'Random tests are not universal proofs; direct proof reading supplies the mathematical audit. No physical experiment or human peer review.'}
open(Path(__file__).resolve().parents[1]/'results'/'adversarial_results.json','w').write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
