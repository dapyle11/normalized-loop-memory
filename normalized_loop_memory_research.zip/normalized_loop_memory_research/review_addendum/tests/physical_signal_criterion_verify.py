"""Regression checks for established final-effect reweighting bounds.
No simulation here sends information backward. Python 3 + NumPy.
"""
from fractions import Fraction as Q
from pathlib import Path
import json
import numpy as np

exact_cases=0
for eta in [Q(0),Q(1,10),Q(1,2),Q(4,5),Q(1)]:
    for lam in [Q(0),Q(1,5),Q(1,2),Q(4,5),Q(1)]:
        laws=[]
        for x in [0,1]:
            success=[(1+eta*lam*(-1)**(r+x))/4 for r in [0,1]]
            failure=[(1-eta*lam*(-1)**(r+x))/4 for r in [0,1]]
            assert sum(success)==sum(failure)==Q(1,2)
            assert [success[r]+failure[r] for r in [0,1]]==[Q(1,2)]*2
            law=[2*z for z in success]
            assert law[x]==(1+eta*lam)/2
            laws.append(law)
        tv=sum(abs(a-b) for a,b in zip(*laws))/2
        assert tv==eta*lam
        exact_cases+=1

rng=np.random.default_rng(30102026)
def psd(d):
    z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
    return z@z.conj().T + np.eye(d)*.05
max_violation=0.
max_sharpness_error=0.
for _ in range(1000):
    d=int(rng.integers(2,7)); gx=psd(d);gy=psd(d)
    ys,yv=np.linalg.eigh(gy)
    yinv=(yv*(ys**-.5))@yv.conj().T
    ev,v=np.linalg.eigh(yinv@gx@yinv)
    m,M=ev[0],ev[-1]
    bound=(np.sqrt(M)-np.sqrt(m))/(np.sqrt(M)+np.sqrt(m))
    branches=[psd(d) for _ in range(5)]
    wx=np.array([np.trace(gx@a).real for a in branches]);wy=np.array([np.trace(gy@a).real for a in branches])
    px=wx/wx.sum();py=wy/wy.sum()
    tv=np.abs(px-py).sum()/2
    max_violation=max(max_violation,tv-bound)
    assert tv<=bound+1e-10
    # Independently construct exact-bound endpoint ensembles from generalized eigenvectors.
    states=[];weights=[]
    qmass=[np.sqrt(M)/(np.sqrt(m)+np.sqrt(M)),np.sqrt(m)/(np.sqrt(m)+np.sqrt(M))]
    for j,k in enumerate([0,-1]):
        u=yinv@v[:,k];u=u/np.linalg.norm(u)
        state=np.outer(u,u.conj());states.append(state)
        weights.append(qmass[j]/np.trace(gy@state).real)
    wx=np.array([weights[j]*np.trace(gx@states[j]).real for j in range(2)])
    wy=np.array([weights[j]*np.trace(gy@states[j]).real for j in range(2)])
    sharp=np.abs(wx/wx.sum()-wy/wy.sum()).sum()/2
    err=abs(sharp-bound);max_sharpness_error=max(max_sharpness_error,err)
    assert err<1e-9
result={"status":"PASS","exact_qubit_bridge_and_flag_cases":exact_cases,
        "random_noncommuting_general_effect_cases":1000,"random_sharpness_constructions":1000,
        "max_bound_violation":max_violation,"max_sharpness_error":max_sharpness_error,
        "scope":"Mathematical regression checks only; no physical backward channel."}
(Path(__file__).resolve().parents[1]/'results'/'physical_signal_criterion_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
