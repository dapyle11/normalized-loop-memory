# Final bounded primary-literature scope audit

Checked 2026-10-30. This is a focused overlap audit, **not a certification of novelty**. Relevant operational/model sections of primary full texts were inspected; search snippets alone were not used to establish the comparisons below. The mathematical results in this repository require their separate proof audits.

## Model being compared

One backward classical BSC(p), one forward BSC(q) bit or depolarizing qubit, no other retained memory, shared seed, or shared entanglement, arbitrary local stochastic instruments, and one-use worst-message success after message-dependent normalization. The classical embedding of the qubit channel is q=epsilon/2. The claims under review are exact restricted-model M=3/M=4 results and a proposed all-M scalar characterization—not general capacities or physical backward signalling.

## Closest antecedents and precise distinctions

### 1. Conditional worst-case decoding is already explicit prior art

Ji, Regula, Wilde, [*Postselected communication over quantum channels*, arXiv:2308.02583v3](https://arxiv.org/html/2308.02583v3), Sec. 3.1, Eq. (20), already defines classical error as one minus the minimum over messages of correct weight divided by that message's output trace. Secs. 3.2–3.3 and subsequent capacity theorems study entanglement/nonsignalling assistance. Thus neither conditional minimax decoding nor its per-message denominator is a new objective here. Their general probabilistic-supermap framework can express many restrictions; its published assisted capacity formulas are not automatically the optimum under our single charged noisy forward carrier. The distinction must be the feasible resource set, not a purported new error criterion.

### 2. The retrocausal decoder–memory–encoder architecture is already prior art

Ji, Lloyd, Wilde, [*Retrocausal Capacity of a Quantum Channel*, arXiv:2509.08965v3](https://arxiv.org/html/2509.08965v3), main-text Eqs. (1)–(2), and supplement Sec. IV.1, explicitly use a decoder leaving a forward quantum memory for the encoder. Sec. IV.1 permits arbitrary-dimensional noiseless memory. The developed finite-resource problem restricts that resource, adds fixed noise, and fixes a classical binary backward channel. Hence the contraction and the use of forward memory cannot be claimed as new. The published general-resource theorem does not by itself certify this restricted achievable optimum. Retain the existing citation to the noisy-memory direction near main-text Eqs. (12)–(13), without calling this a solution of its full asymptotic frontier.

### 3. Independent-device dimension witnesses are particularly close conceptual antecedents

Bowles, Quintino, Brunner, [*Certifying the dimension of classical and quantum systems in a prepare-and-measure scenario with independent devices*, arXiv:1311.1525v3](https://arxiv.org/html/1311.1525), Eqs. (1)–(2), explicitly allow local randomness but forbid shared randomness. They emphasize the resulting nonconvex feasible set. Eqs. (3)–(6) give a nonlinear determinant witness for four preparations, two binary measurements, and a bit/qubit distinction. This is closer to our side-resource convention than a convexified dimension witness. However their observed conditional table has independent preparation/measurement inputs, not our decoder-outcome-weighted BSC loop and message-dependent ratio. No equivalence of their witness optimum with our threshold/scalar formulas was identified. Cite them for the existing phenomenon and independence convention, not as a proof of these formulas.

### 4. General dimension-matched quantum advantages long predate this work

Gallego, Brunner, Hadley, Acín, [*Device-independent tests of classical and quantum dimensions*, arXiv:1010.5064](https://arxiv.org/pdf/1010.5064), pp. 1–3, Eqs. (1)–(4), formulate ordinary prepare-and-measure correlation tables and dimension witnesses. Their discussion distinguishes uncorrelated mixtures from mixtures using shared correlations. The finite-dimensional quantum/classical separation itself is therefore not a defensible novelty claim. Our objective instead contracts a table with a fixed backward channel and normalizes by message. A reduction transferring their optimization to this objective would need to preserve those weights, local trace constraints, noise, and absence of a shared seed; none is supplied merely by invoking dimension witnesses.

### 5. Random access codes do not solve the present message task

Ambainis, Leung, Mancinska, Ozols, [*Quantum Random Access Codes with Shared Randomness*, arXiv:0810.2937v3](https://arxiv.org/pdf/0810.2937), Secs. 2.1–2.2 and 3.2–3.4, distinguish independent local randomization from a distribution over joint strategies. Their task encodes an n-bit string into one carrier and recovers a queried bit, with worst case over string/index pairs. This differs from recovery of the entire M-valued message in a normalized loop. The Bloch-sphere and measurement-geometry techniques are relevant precedents, but their shared-randomness symmetrization cannot be imported here for free. Their n parameter must not be equated with our message count M.

### 6. Ordinary feedback capacities use different causal and resource assumptions

Bowen, [*Quantum Feedback Channels*, arXiv:quant-ph/0209076v4](https://arxiv.org/pdf/quant-ph/0209076), introduction and Sec. III, defines unlimited noiseless quantum feedback. Its recursive protocol retains systems/ancillas across ordinary channel uses. This is neither a one-carrier noisy memory restriction nor message-conditioned postselection. Its capacity equalities do not rule out, or establish, the restricted one-use advantage here.

A recent potentially misleading near-match is Wilde, [*Finite-blocklength classical communication over the quantum erasure channel with and without classical feedback*, arXiv:2610.00440](https://arxiv.org/html/2610.00440), Sec. 2.2 and Secs. 6–7. It permits quantum memories and ordinary causal classical feedback, uses an erasure channel, and gives a four-message quantum/classical separation with four forward transmissions (including a worst-message comparison). These are not our one-use BSC loop, fixed noisy feedback carrier, or postselection normalization. Nevertheless, avoid any broad claim that four-message finite-blocklength quantum/classical separation is itself new.

## Existing normalization check

The earlier `noisy_memory/related_work_scope.md` records Carney's *Tracing the Loop*, arXiv:2609.08716v2, and the distinction between input-independent normalization there and the message-dependent normalization here. That earlier check is retained; this pass does not independently re-audit that paper.

## Recommended citation/claim changes

- Strengthen the 2024 Ji–Regula–Wilde citation with **Eq. (20)**: the exact type of minimax conditional objective is prior art.
- Keep Bowles–Quintino–Brunner prominently beside the no-shared-seed convention; do not describe independent-device nonconvexity as new.
- Cite QRAC work only as conceptual/technical context, explicitly excluding its free shared-randomness convention and different retrieval target.
- Describe the results as independently derived, checked exact calculations in a stated restricted model. Do not use “first,” “new physical effect,” or “solution of the general noisy-memory capacity problem.”
- A scalar feasibility oracle can be a useful specific mathematical contribution even when the formalism, quantum/classical separation, and conditional objective all have antecedents. Priority for that exact contribution remains unestablished.

## Search scope and stopping condition

Queries covered postselected communication with bounded memory, dimension witnesses/independent devices, QRAC shared randomness, and quantum feedback capacity. Primary full-text model sections were followed for the closest candidates above. Broader searches predominantly returned ordinary feedback control, Deutsch-CTC complexity, or experimental postselection with different resource ledgers; these were not promoted into alleged theorem overlaps. No checked source established the exact BSC/depolarizing one-carrier formulas or all-M scalar characterization. That is a limited negative search result, not evidence sufficient to assert priority. Stop this bounded pass here: no identified remaining high-value exact-model lead warrants expanding to an unbounded literature survey.
