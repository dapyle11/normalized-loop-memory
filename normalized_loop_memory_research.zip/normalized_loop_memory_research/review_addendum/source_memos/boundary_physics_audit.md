# Physical audit of the final-boundary mechanism

Date: 30 October 2026. This is an AI-assisted mathematical and source audit, not independent human review, a laboratory result, or a proof that all possible theories forbid backward communication.

## Finding

The proposed final-effect expression is a valid way to calculate a selected ensemble. Promoting that selected ensemble to the statistics of every physical run requires an additional law or physical resource. Neither a nontrivial positive matrix F nor the ability to implement a measurement having F as an outcome supplies that resource. No Hamiltonian or laboratory implementation of deterministic, record-reweighting final selection has been derived here.

This gap is not merely detector inefficiency. It separates an ordinary instrument, which has all its outcomes, from a proposed fundamental boundary law, which changes which complete histories are assigned probability.

## 1. Exact operational ledger

Let the earlier readable record be R and the retained system Q. After the earlier measurement the state is

    rho_RQ = sum_r |r><r| tensor A_r,
    A_r >= 0,  rho_Q = sum_r A_r,  Tr rho_Q = 1.

A_r includes the probability of r, so p(r)=Tr A_r. The future intervention x selects a completely positive trace-preserving map E_x. For a later measurement outcome S having effect 0 <= F <= I,

    w_rx = Tr[F E_x(A_r)],
    Z_x = sum_r w_rx,
    P(r | x,S) = w_rx/Z_x                         (Z_x > 0).

Every complementary outcome must also be counted in an ordinary experiment:

    P(r | x) = Tr[F E_x(A_r)] + Tr[(I-F) E_x(A_r)]
             = Tr E_x(A_r) = Tr A_r.

Thus different conditional laws P(r|x,S) are not a backward signal available in the earlier record alone. The distinction remains even when Z_x is exactly the same for every x.

For a general positive F not bounded by I, multiplication by a positive constant makes it a valid effect without changing the normalized expression. This mathematical rescaling says nothing about making its outcome certain.

## 2. Why a Hamiltonian implementation does not follow

Any ordinary construction consisting of a fixed earlier apparatus/ancilla state, later Hamiltonian evolution, later measurements with every outcome retained, and disposal of unobserved degrees of freedom defines a trace-preserving map on the later quantum system. For any such map Lambda_x,

    Tr_Q[(id_R tensor Lambda_x)(rho_RQ)] = rho_R.

Equivalently, Lambda_x^dagger(I)=I. This remains true with arbitrary correlations between R and the later apparatus, provided the later operation does not act on the stored record and the initial state does not depend on x. Ancillas, feedback, dissipative dynamics, and repeat-until-success procedures do not evade the identity when their full outcome and trial ledgers are included.

This is a conditional no-go statement within ordinary forward quantum dynamics. It does not assume that all theories of quantum gravity must have that structure. A candidate beyond that structure must specify which premise changes and derive the new observable probabilities.

### Resetting is not forcing the selected history

Take A_0=|0><0|/2, A_1=|1><1|/2, E_0=identity, E_1(rho)=X rho X, and F=|0><0|. Selected runs obey P(r=x|x,S)=1, with Z_0=Z_1=1/2. Unselected earlier records remain fair for both interventions.

Now replace the final selection by an ordinary reset map rho -> |0><0| Tr rho. The final F measurement succeeds with certainty, but the reset leaves P(r=0|x)=P(r=1|x)=1/2. It does not recreate the selected earlier distribution. A detector that always clicks and a law that excludes all incompatible earlier histories are different resources.

## 3. External intervention versus postselected random settings

Suppose x is generated independently with distribution pi_x after the early record is fixed. In an ordinary experiment,

    P(r,x,S) = pi_x w_rx,
    P(x|S) = pi_x Z_x / sum_y pi_y Z_y.

Therefore selection generally changes the observed distribution of settings as well as outcomes. A family of per-setting normalized expressions w_rx/Z_x must not silently be treated as a global joint distribution with the original setting prior pi_x. A theory using the joint law pi_x w_rx/Z_x is supplying an intervention convention that holds pi_x fixed; a global final-boundary rule applied to the setting generator instead yields the preceding reweighted prior. These are different assumptions, not interchangeable calculations.

### Exact example

Use A_0=3|0><0|/4 and A_1=|1><1|/4, the same I/X controls, F=|0><0|, and pi_0=pi_1=1/2. Then

    Z_0=3/4,  Z_1=1/4,
    P(r=0|x=0,S)=1,  P(r=1|x=1,S)=1,
    P(x=0|S)=3/4,  P(x=1|S)=1/4.

The selected subensemble appears to predict x perfectly, but the all-trial earlier distribution is (3/4,1/4) for both values of x. This is ordinary selection bias, not backward communication. The balanced version in section 2 shows that equal setting frequencies and equal success rates are not sufficient safeguards either.

Separately, choosing x from an earlier record can create correlation in completely forward physics. An operational test must use a later setting source that is blind to the earlier record and relevant correlated information. Such independence is an explicit physical assumption supported by controls, not something proved by a correlation table alone.

## 4. Published context and limits

[Guryanova et al., Quantum 3, 211 (2019)](https://arxiv.org/html/1708.00669), section 2, distinguish an externally generated later setting from a choice informed by the earlier result. Appendix C, Theorem 1, characterizes single-party two-time states satisfying no-backwards-in-time signalling for all allowed measurements and transformations as an initial state paired with an identity final factor. The quantifier over interventions matters: a limited experiment may miss a nontrivial boundary. Their general two-time formalism also includes ancillas and correlations beyond the product initial-state/final-effect example used here. This existing theorem is not a new result of this project.

[Lloyd and Preskill, JHEP 08 (2014) 126](https://arxiv.org/html/1308.4209), section 6.5, give a conditional black-hole final-state scenario in which a later operation changes an earlier Bell record. Its proposed resource is a fundamental final boundary, not ordinary laboratory postselection. They also discuss access/timing and radiation-decoding limitations. Our earlier finite-qubit replication confirms its stated conditional algebra but does not establish those physical resources. The current audit supplies no route from that black-hole hypothesis to a tabletop receiver.

## 5. Minimum requirements for a physical proposal

Before calling any proposed device a receiver for later-chosen information, the proposal needs all of the following:

1. **A dynamical or boundary law.** Specify why the effective final effect is enforced as a law of the complete experiment rather than merely an outcome later selected by an analyst. An arbitrarily chosen F is not that explanation.
2. **Physical degrees of freedom and couplings.** Identify fields or systems, interaction Hamiltonians or the explicit modification replacing them, the preparation mechanism, and a parameter range where the description is valid.
3. **An intervention rule.** Specify how a sender can choose x, how the setting generator enters the boundary condition, and which controls are physically allowed. Do not silently compensate F for each intervention or assume unearned independent control.
4. **An earlier readable record.** Include its amplification/storage and the detector coupling in the model. A hidden variable, reconstructed past state, or later-conditioned label is not an earlier message.
5. **All-outcome probabilities.** Include losses, detector failures, no-clicks, rejected trials, and later flags. Demonstrate a difference in P(R|do(x)) before any later side information is available.
6. **A quantitative prediction.** Give signal strength, time interval, noise and memory dependence, and a null limit. A model that can explain any result by an adjustable unknown boundary is not yet a falsifiable receiver model.
7. **Consistency and resource checks.** Establish nonzero normalization for allowed interventions, account for apparatus/environment and any memory or shared information, and check the regime of spacetime and energetic assumptions.
8. **An experimental discrimination plan.** Before data collection, fix the decoding and trial rules, protect the earlier records, separate the future random-setting source, include forward-leakage and timing controls, and specify independent replication. Statistics can test a specified effect; they cannot supply its missing physical mechanism.

## Conclusion and stopping boundary

The mathematical final-effect criterion can tell us whether an assumed boundary would yield the desired dependence and how large it could be. It cannot establish that the boundary exists or can be imposed. The present physics branch is therefore ready for a precise theory-level question, not hardware: **what law supplies a controllable nontrivial effective final boundary on an accessible system while preserving a defined external intervention and earlier readable record?** No answer to that physical construction problem has been obtained in this audit.
