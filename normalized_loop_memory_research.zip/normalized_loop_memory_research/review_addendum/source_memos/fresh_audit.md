# Fresh adversarial audit, 30 October 2026

## Finding

I found no mathematical counterexample or proof gap in the specified finite-alphabet one-forward-qubit threshold theorem or the three-message equality theorem during this fresh AI-assisted audit. This is a bounded independent rederivation within the same AI research workflow, **not independent human review, formal proof-assistant verification, or a novelty determination**.

The conclusions require exactly the stated resource model: one assumed backward classical binary symmetric channel, one forward dimension-two carrier, local randomness only, no retained encoder-accessible side record, no shared seed or entanglement, and message-dependent normalization of the stipulated loop contraction. They do not construct a physical backwards channel. A shared seed, stored decoder label, input-independent normalization requirement, different channel, or multi-use coding task would change the problem.

## Proof checks

1. **Decoder reduction is genuinely reversible.** From row traces and Bloch positivity, the necessary constraints are sum T=2, sum u=0, |u|≤T, |d|≤T. The stated reconstruction v_b=(-1)^b t_b d/T satisfies positivity and reproduces d. No unmentioned common-state or POVM normalization constraint is needed for this prepare-and-measure decoder. Conversely, adding such a constraint would be a different model.
2. **Extreme encoder choices are legitimate.** Fixed-decoder success is a ratio of affine functionals with strictly positive denominator. It is a denominator-weighted average over extreme effects. Choosing a better extreme effect independently for each future message cannot worsen another message's success.
3. **Constant allocation and trace minimization are sound.** The two-row weighted dual bound proves the spillover formula, not just its particular construction. The minimum trace is feasible with the residual row capacities. Equal allocation among projectors therefore introduces no hidden row-imbalance assumption.
4. **Hard geometric step checked independently.** Direct differentiation of the spherical-cap formula gives the listed endpoints, negative second derivative, and derivative at the upper join minus one equal to (2-r)/(2hr). Hence its concavity and slope bound hold over 0<h<1/2, 0<r≤2. This justifies Jensen and replacing actual constant trace with minimum constant trace. The equal-transverse regular polygon construction is valid for every N≥2, including two opposite transverse vectors.
5. **Endpoint handling is explicit.** The h=0, r=0, N=0, N=1, M=1 and zero-trace cases are handled separately. The theorem excludes p=0 and p=1/2; these limits must not be described as covered without separate proofs. The arithmetic-test count O(M²) is not a bit-complexity bound polynomial in log M.
6. **Three-message sign certificate rederived.** Starting from the quadratic vertex maximum rather than the existing verifier, I substituted the physical variables, removed the positive scale, and reconstructed the degree-(9,3) Bernstein expansion. All 40 coefficients are nonpositive and the entire final row is strictly negative. Thus the asserted strict sign on 0<x≤1, 0<w≤1 follows. The constrained-vertex v>4 branch and complete-erasure branch remain necessary and are included in the proof.

## New numerical adversarial check

A newly written checker generated 1,350 generic quantum protocols for M=1 through 9, rational backward noise from 0.01 to 0.49, and depolarization including both endpoints. Preparations were independently generated full Bloch states with unrelated row probabilities; effects included generic projectors and both constants. It evaluated the original 2-by-2 matrix loop contractions directly, without using the reduced formula for their probabilities.

Every attained threshold was accepted by the exact rational oracle. Direct contraction and reduced projective ratios agreed to at most 3.3306690738754696e-16. Four geometric identities and the Bernstein reconstruction passed exactly in SymPy. Random tests do not prove global completeness; the universal argument above is the relevant proof check.

New files:
- `fresh_audit/adversarial_checks.py`
- `fresh_audit/adversarial_results.json`
- `fresh_audit/bernstein_rederive.py`
- `fresh_audit/bernstein_results.json`

## Presentation and submission cautions

The delivered notebook explicitly states the physical assumptions and distinguishes late-selected statistics from all-trial early records. It does not require a numerical claim correction on the portions examined here. Some *working-directory* historical README headings still describe already superseded open problems or pending audits. The inspected packaged-release README was updated, so those stale working notes should not be mistaken for an error in the delivered release. Treat the delivered notebook and packaged proof files as the current source of claims.

Before submission, commission a human quantum-information review, complete a targeted originality comparison, and preferably extract a short conventional theorem paper with a precise model statement. Do not advertise the result as sending information backwards or as solving general many-use capacity. No outside contact, physical experiment, or upload was performed for this audit.
