# Questions for independent human review

This is a technical review agenda, not a message sent to anyone. The calculations are AI-generated and AI-checked. No independent human review, formal proof-assistant verification, physical backward communication, or priority claim has occurred.

## Restricted communication mathematics

1. **Resource definition:** Does the decoder–forward-memory–encoder contraction exactly implement the stated one-use normalized-loop resource, with no uncharged shared seed, stored decoder label, entanglement, or auxiliary communication? Is a single forward BSC(q) at q=epsilon/2 the appropriate classical embedding of the depolarizing qubit for this comparison?
2. **Encoder reduction:** Does positive-denominator linear-fractional extremality justify replacing each binary quantum effect independently by 0, I, or a rank-one projector without changing another message's weights? Check the positivity bound and the distinction between message-conditioned normalization and ordinary averaged success.
3. **Decoder reconstruction:** Verify that the reduced variables T_m,u_m,d_m have precisely the claimed feasible set, and reconstruct valid subnormalized qubit states. Check zero-trace labels and row normalization explicitly.
4. **Global finite-alphabet proof:** Audit minimum constant-label trace, cap concavity and its slope at the join, Jensen's inequality, the replacement of actual constant trace by its minimum, and constructive regular-polygon closure for N=2 as well as N>2. Verify all erased-memory, r=0, and endpoint branches.
5. **Three-message equality:** Derive the polynomial certificate independently from the original optimization. Check the physical parameter domain, all 40 Bernstein coefficients, strictness on its boundary, and the continuity argument excluding thresholds above the classical root.
6. **Computation claims:** Verify exact rational certificate outputs against raw quantum contractions. O(M^2) counts constant-size arithmetic tests for a given rational threshold; it is not a bound on bit complexity independent of input precision, and M is not log(M).
7. **Prior art:** Is the exact restricted feasible set or scalar oracle equivalent to an existing prepare-and-measure, dimension-witness, postselected communication, or bounded-memory result? Conditional minimax decoding, the retrocausal architecture, and dimension-matched quantum advantages are already prior art. The broader asymptotic frontier is not claimed to improve.

## Physical boundary analysis

8. **Operational interpretation:** Does any proposed final-boundary law define probabilities for externally chosen interventions and stable earlier records, rather than merely condition an ordinary experiment on a later event? Explicitly model the setting generator and prohibit postselected trial exclusions.
9. **Accessible operations:** Are claims of signalling based on controls and earlier branch states actually available in the proposed physics? Non-scalar final effects alone are insufficient for arbitrary fixed preparations and restricted controls.
10. **Implementation and consistency:** What physical law enforces the boundary? Give a state/field evolution, composition rule, detector coupling, energy and noise budget, and treatment of zero-probability branches. Ordinary reset, feedback, or a detector guaranteed to click does not enforce an input-dependent selected branch.
11. **Testable prediction:** Derive a nonzero unconditional earlier-record contrast from that physical law, with an independently motivated parameter range. A mathematical upper bound or an adjustable toy parameter is not such a prediction. A null result constrains only the specified model and covered parameter range.

## Decision gates

A focused mathematical paper can be considered after errors are resolved and the closest antecedents are compared. A hardware proposal requires a separate physical model with a nonzero all-trial prediction. Neither gate is passed merely because another simulation reproduces the assumed loop law. No reviewer has been contacted.
