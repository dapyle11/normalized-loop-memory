# A testable mathematical criterion for a final-boundary backward signal

Date: 2026-10-30. Status: an application of established quantum-instrument and probability results, with an elementary derivation. **Not a new physical mechanism, novelty claim, laboratory experiment, or independent human review.**

## 1. The precise unresolved premise

An earlier sensor produces an immutable classical record R. Write its accompanying subnormalized system states as A_r >= 0, with A = sum_r A_r and Tr A = 1. The complete earlier apparatus, relevant environment and memories can be included in this system. The choice x is an externally intervened later input, not a variable inferred from R or chosen adaptively from it. The preparation and early instrument are fixed independently of x.

A later ordinary channel E_x is completely positive and trace preserving. For a fixed positive final effect F, define

    G_x = E_x^dagger(F),
    w_x(r) = Tr(G_x A_r),
    Z_x = Tr(G_x A),
    P_x(r) = w_x(r)/Z_x.                         (1)

Require Z_x > 0 for every allowed choice. For an ordinary selected measurement, 0 <= F <= I; its overall scale cancels from P_x. In ordinary QM, (1) is a **success-conditioned** law. It is not the earlier all-trial law. To interpret (1) as the earlier all-trial law requires an additional fundamental final-boundary postulate, enforced without a later success flag. This is precisely the presently unbuilt resource.

Ordinary completion uses final effects {F_k} summing to I. Then

    sum_k Tr[E_x^dagger(F_k) A_r] = Tr A_r,

for every x. The actual earlier record frequencies do not change. Even Z_x constant across settings does not remove selection bias: correlations between R and the final flag can change.

The general two-time-state no-backward-signalling result is established literature. Guryanova et al., Appendix C Theorem 1, characterize single-party two-time states satisfying no backward signalling under their allowed operations as rho tensor I. Their treatment is broader than the factorized preparation/final-effect setting used here. This memo must not be presented as rediscovering that theorem. [Primary source](https://arxiv.org/html/1708.00669).

## 2. Exact criterion with restricted apparatus and controls

For a fixed earlier instrument and two allowed settings x,y, there is no difference in the normalized earlier laws if and only if

    Tr[(G_x/Z_x - G_y/Z_y) A_r] = 0 for every r. (2)

Equivalently, the Hermitian difference is orthogonal, in the trace pairing, to span_R{A_r}. This is an exact finite-dimensional calculation, not a test requiring arbitrary sensors.

If the accessible A_r span all Hermitian operators, (2) reduces to G_x/Z_x = G_y/Z_y. More generally, **equality for every possible early ensemble holds if and only if G_x and G_y are positive scalar multiples**, assuming nonzero effects and valid normalizers. Sufficiency follows by cancellation. For necessity, equality for every two-branch ensemble forces the ratios Tr(G_x sigma)/Tr(G_y sigma) to be the same for all density operators sigma on their common positive support; linearity then gives proportional effects. Unequal supports can be detected by ensembles containing vectors in the differing kernel, provided both total normalizers remain positive.

This gives two separate failure modes:

1. The controls never change the effective final weighting: G_x is proportional to G_y.
2. They do change it, but the particular earlier sensor states cannot distinguish the change.

A non-scalar F by itself is therefore **not sufficient** for the proposed apparatus to communicate. For example, diagonal F with only diagonal unitaries gives G_x = F for every x. Also, if A_r = p_r sigma for all r, the record contains no information about the remaining system and P_x(r) = p_r for all x even when G_x varies.

If all unitaries and all early ensembles are available, absence of any dependence forces F proportional to I: U^dagger F U must be proportional to F for every U, equal trace removes the proportionality constant, and the only operator commuting with every unitary is a scalar. Conversely scalar F gives G_x = F for every CPTP E_x. This is a simple restricted-setting corollary of the established no-backward-signalling framework, not new physics.

For a smooth unitary control U(theta) = exp(-i theta H/hbar), a useful local diagnostic is

    dP_theta(r)/dtheta at 0
      = {Tr[i[H,F] A_r] - P_0(r) Tr[i[H,F] A]}/(hbar Z_0). (3)

Commutation kills this response. A zero first derivative does not prove no dependence: diagonal early branches and diagonal F with an X rotation have a second-order change. Use (2), not just a derivative test, for a global conclusion.

## 3. A sharp quantitative bound

Use total variation TV(P,Q) = (1/2) sum_r |P(r)-Q(r)|, ranging from zero to one.

Suppose G_y is positive definite on the accessible system support. Let m and M be the smallest and largest generalized eigenvalues of (G_x,G_y), equivalently the extreme eigenvalues of G_y^(-1/2) G_x G_y^(-1/2). Assume m > 0. Then

    m G_y <= G_x <= M G_y,

and for every earlier ensemble,

    TV(P_x,P_y) <= (sqrt(M)-sqrt(m))/(sqrt(M)+sqrt(m)). (4)

This is the sharp Hilbert-projective-metric/total-variation bound applied to effects. Its probability version is established; Cohen and Fausti Theorem 5.1 use twice our TV convention. Their bound is 2 tanh(H/4) in their convention, corresponding to tanh(H/4) here, with H <= log(M/m). [Primary source](https://arxiv.org/html/2309.02413v2). Positive-cone and quantum-information applications of Hilbert's metric also predate this memo: [Reeb, Kastoryano and Wolf (2011)](https://arxiv.org/abs/1102.5170).

Elementary proof: put Q_r=P_y(r), l_r=w_x(r)/w_y(r), and mu=sum_r Q_r l_r. Then m<=l_r<=M and P_x(r)=Q_r l_r/mu. Convexity of |l-mu| bounds its expectation by that of an endpoint-supported random variable with the same mean. Hence

    TV <= (M-mu)(mu-m)/[mu(M-m)].

Its maximum over mu in [m,M] occurs at mu=sqrt(mM), giving (4). If m=M the effects are proportional and TV is zero. The formula is interpreted by continuity as the trivial bound 1 when relative support is singular.

Sharpness when the early preparation is unrestricted: choose two pure states attaining the extreme generalized Rayleigh quotients m,M. Choose their physical mixture weights so their Q probabilities are sqrt(M)/(sqrt(m)+sqrt(M)) at m and sqrt(m)/(sqrt(m)+sqrt(M)) at M. This is possible because both G_y expectations are positive. Then mu=sqrt(mM) and equality holds. For a fixed preparation, sensor, or restricted state set, the actual maximum may be smaller.

## 4. Bound directly from final-effect anisotropy

If a I <= F <= b I with 0<a<=b, every CPTP E_x satisfies a I <= G_x <= b I. Therefore m>=a/b and M<=b/a in (4), yielding

    TV(P_x,P_y) <= (b-a)/(b+a).                  (5)

The bound is tight in the unrestricted model. Choose two orthogonal eigenvectors of F with eigenvalues b,a, earlier branches A_0=|b><b|/2 and A_1=|a><a|/2, and later controls identity or the unitary swapping these vectors. The conditional distributions are

    P_0=(b/(a+b), a/(a+b)),
    P_1=(a/(a+b), b/(a+b)).

Both success probabilities are (a+b)/2, yet their conditional TV equals (b-a)/(b+a). Retaining failures still gives the ordinary earlier law (1/2,1/2) for both controls. If a=0<b, the conditional TV can reach one; this does not establish physical deterministic postselection.

Equivalently write F=c(I+delta H), ||H||<=1, 0<=delta<1, c>0. Then TV<=delta. For a freely selected equiprobable binary message, optimal single-trial success from the earlier record is (1+TV)/2, thus at most (1+delta)/2 **if** the fundamental-boundary interpretation were available. This is a bound on an assumed model parameter, not an experimentally measured coupling or evidence of a channel.

For one selected effect G relative to the unconditioned earlier distribution, a I<=G<=b I instead gives the sharper single-reweighting bound

    TV(P_G, p_early) <= (sqrt(b)-sqrt(a))/(sqrt(b)+sqrt(a)). (6)

Do not confuse (6) with the two-setting bound (5).

## 5. Trace-preservation defects and why renormalization is not a mechanism

For a CP trace-decreasing map T_x, put G_x=T_x^dagger(I). All the same criteria and bounds apply to normalized selected branches. If G_x=c_x I, conditioning changes no earlier record probabilities; T_x/c_x is an ordinary CPTP map for c_x>0. If G_x is non-scalar, some inputs have different success probabilities, but a signal still requires accessible control and distinguishable early branches as in (2).

It is too strong to say every normalized non-TP map must look nonlinear on its output system: a measure-and-prepare operation can normalize to a constant output state even though its success effect is non-scalar. The relevant issue is the **joint law including the historical record**. Ordinary quantum operations retain rejected branches. Promoting only the normalized selected branch to an all-trial joint law changes that operational rule and needs justification beyond writing a denominator.

Standard past-quantum-state methods deliberately use future measurement records to improve retrodiction; they do not furnish an earlier receiver with those records. [Gammelmark, Julsgaard and Mølmer (2013)](https://arxiv.org/abs/1305.0681).

## 6. Consequence for further research

This analysis supplies a precise screening test for a candidate physical theory:

- Specify its actual initial preparation, sensor instrument, full environment, and allowed later interventions.
- Derive F or its more general two-time object from that theory, rather than assume it as a communications resource.
- Explain why (1) is the all-trial operational law rather than a posterior selected law, including the source of externally controllable x.
- Show the accessible effects violate (2), and compute a nonzero observable bound/prediction without hiding rejected outcomes or later decoding labels.
- Supply a dynamics and consistency rule for every allowed input, including zero-normalizer cases, and a physically calibrated parameter.

No reviewed construction currently supplies all of these for a buildable receiver. Equations (2)-(6) make the missing requirement explicit; they do not fill it. Continuing to optimize F or delta without a derivation would again assume the resource we are trying to create. The next substantive advance must be a physical model or relevant data that fixes those ingredients, or independent human assessment of the existing mathematical work.

## 7. Explicit bridge to the assumed binary symmetric channel

Use earlier branches A_r=|r><r|/2, r in {0,1}; let the future input x choose X^x, followed by depolarizing survival lambda in [0,1], D_lambda(rho)=lambda rho+(1-lambda)Tr(rho)I/2. Take F=(I+eta Z)/2 with eta in [0,1]. Then

    G_x = [I + eta lambda (-1)^x Z]/2,
    Tr(G_x A_r) = [1 + eta lambda (-1)^(r+x)]/4,
    Z_x=1/2,
    P_x(r) = [1 + eta lambda (-1)^(r+x)]/2.      (7)

Thus the **conditional or postulated forced-boundary** law is a BSC with crossover p=(1-eta lambda)/2. Matching the existing assumed backward BSC requires eta lambda=1-2p. This is an algebraic resource translation, not a prediction that eta exists in nature or is controllable. For p=.1, it requires eta lambda=.8; each factor must be at least .8 since both are at most one.

The complementary effect I-F produces the opposite selected bias with the same probability 1/2. Summing success and failure joint probabilities gives P_ordinary(r|do x)=1/2. Neither larger sensor precision nor lower ordinary noise removes this cancellation. Under restricted controls commuting with Z, the same F produces no message.

`physical_signal_criterion_verify.py` checks the qubit bridge and complete flag ledger with exact rational arithmetic, and tests the general effect bound on independently generated noncommuting positive matrices and ensembles. These are regression checks; the proofs above establish the continuous-domain claims. Numerical random checks are not physical experiments or proofs of realizability.
