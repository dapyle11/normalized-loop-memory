# Extended backward information research reproducibility package

Prepared for Daniel on 30 October 2026. This is an AI-generated mathematical
research notebook and reproducibility bundle, not independently human reviewed,
not a physical experiment, and not a submission-ready claim of scientific
priority. No equipment, real backward channel, or fundamental final-state
resource was supplied. Prior reports remain separate and unchanged.

## Results and their limits

The notebook gives full proofs for a declared one-use classical architecture:
one hypothetical backward binary symmetric channel BSC(p), one ordinary forward
BSC(q), a local stochastic decoder D(h,c|b), and encoder E(a|m,d). There is no
additional retained memory, shared seed, shared entanglement, hidden forward
label or other communication. Each message's loop weights are normalized by its
own positive Z_m. Success is the minimum conditional correct-message probability,
not average success, unconditioned laboratory throughput or an asymptotic rate.
The domain is 0<p<1/2 and 0<=q<=1/2. The minimax conditional-success
objective itself is established prior work: Ji, Regula and Wilde (2024), Eq.20.
The calculations here restrict the charged architecture and noise family; they
do not introduce that objective or settle the broader assisted-capacity problem.

Let A=1-p, s=p+q-2pq and r=1-s.

- **Two possible messages (one bit):** the optimum is exactly A=1-p even if the allowed
  forward carrier is quantum. The general trace bound is
  A/[A+(M-1)p]; for M=2 it is attained by ignoring forward memory and directly
  using the stipulated backward BSC. This does not establish that such a
  backward channel exists.
- **Three messages:** the exact optimum T3 is the unique root in (0,A) of
  r(A-T3)(1-T3)-s*T3^2=0. Every q<1/2 improves over fully erased memory.
  The quantum one-qubit optimum is exactly the same at q=epsilon/2, for every
  allowed noise pair. A complete symbolic Bernstein sign certificate proves
  this uniform equality; it is not inferred from sampled tests.
- **Four messages:** put qc=A/[2(A+1)]. The exact optimum is A/2 for q>=qc.
  For q<qc it is the unique root IN (A/2,A/(A+1)) of
  [A-(A+1)T4][r-(r-s)T4]-2*A*p*s*T4=0. The interval matters: the quadratic
  has another root outside the relevant probability interval.
- **Any finite message count M, classical memory:** grouping the four deterministic encoder types
  gives exactly binomial(M+3,3) multiplicity cases with at most 16 decoder
  variables each. This is a complete finite-dimensional feasibility reduction,
  not a closed formula for all M or an asymptotic channel-use theorem.
- **A forward qubit can strictly beat the dimension-matched classical bit** in
  the stated FOUR-message task. With p=1/10 and a qubit depolarizing parameter
  epsilon=1/10, an explicit rational protocol has worst success 12/25=.48.
  The classical embedded memory has q=epsilon/2 and exact optimum about .4620623.
  The same fixed quantum matrices attain .48 throughout
  0<=epsilon<=547/5172. These fixed witnesses are achievable lower bounds; the
  general M4 theorem below separately determines the optimum. Together with the
  binary and M3 equality theorems, this makes FOUR the smallest message count
  with strict qubit advantage in this model (random guessing would give 1/4).
- **Closed algebraic quantum special case:** at p=1/10, epsilon=0 and M=4, the complete
  global optimum is the unique root in (1/2,51/100) of
  19600*t^3-27720*t^2+10449*t-729=0, approximately .506054427104890543.
  A piecewise concave Bloch-vector bound covers every allowed binary POVM
  and decoder, and an algebraic construction attains the bound. This closed-form special
  case is consistent with the general characterization below.

- **All four-message noise pairs:** for every 0<p<1/2 and 0<=epsilon<=1, the
  exact global one-qubit optimum is characterized by a finite scalar test: the
  matched classical baseline plus three quadratic maximizations over specified
  intervals. Full necessity and constructive sufficiency are supplied. Exact
  rational arithmetic gives certified brackets without a nonlinear optimizer;
  at p=.1 the optima are about .482246970649385 for epsilon=.1 and
  .461345288519521 for epsilon=.2. This is not an all-message-count or
  asymptotic-capacity theorem.

- **Every finite alphabet with one forward qubit:** a complete constructive
  characterization covers every finite M>=1 and all declared noise parameters.
  At most (M+1)(M+2)/2 encoder-count classes require constant-size exact rational
  tests: a closed row-mass allocation, a one-projector triangle test, or a
  scalar quadratic maximum. No LP or nonlinear optimizer is needed by this
  decision oracle. The O(M^2) operation count is in numerical M, not log M;
  arithmetic bit cost and requested bisection precision are separate. At complete
  erasure, exact success is A/k for M=2k, or A/(k+A) for M=2k+1.

The quantum comparison changes only the two-dimensional forward carrier from a
classical bit to a qubit. The backward channel remains classical. The encoder
gets the message and the designated carrier only; earlier decoder labels and
input bits do not travel to it as free side memory.

The normalized loop objective can be simulated by ordinary forward operations
and a later rejection flag. The simulator retains a private bit for its trusted
heralding verifier, NOT for the encoder. This extra simulation bookkeeping must
be charged and excluded from encoder access in both classical and quantum
comparators. Before selecting the future flag, the earlier output marginal is
independent of the future message. The witness is not a physical device for
sending messages to the past.

## Bounded connection to coding rates

Independent product uses with deterministic codewords give an exact induced
DMC after normalization. The three tested minimax-optimal/witness gadgets have
numerical capacities about .458555, .298690 and .298575 bits/use, below the
p=.1 direct BSC baseline .531004. Those are evaluations of rounded transition
matrices, not exact algebraic-channel certificates.

A **different rate-oriented classical protocol** does improve on direct BSC
coding with its assisting memory charged: the exact 3-by-3 channel and input
law in `noisy_memory/rate_witness.md` have mutual information greater than .55
bits per hypothetical backward BSC(.1) use, with one noiseless forward bit per
use. Exact rational logarithm-series bounds certify a gain greater than .02
bits/use over direct BSC coding. Its three raw early outputs are not a final
hard guess of its three input symbols; block decoding uses the whole record.
Only c is forwarded, never the raw (b,c) record as a second side channel.

This beats only the ignore-memory baseline. The published classical block
Strategy 2 plus time sharing already approaches 1.16385046338 bits/use at the
same AVERAGE forward-bit budget 1. The compact witness imposes the stronger
hard cap of one bit for every independent inner use; it does not improve the
known broader asymptotic frontier. Both comparisons are detailed in the notes.

Constant-composition codes make all codeword normalizers equal. For an identity
forward qubit resource, separately charged Bell-half distribution yields the
achievable point (forward uses,returned qubits)=(1.275,.275) per backward use.
That quantum-rate point is already implied by Ji–Lloyd–Wilde's published
Supplemental Strategy 1; it is not a distinct quantum-rate contribution.
This is not a quantum-over-classical rate separation, a globally optimized
capacity, or a solution of the general noisy-memory quantum frontier. An
ordinary forward simulator would accept only a fraction
(5/9)^n*(3/5)^(n/6) of attempted constant-composition n-use blocks, exponentially
small; its later herald cannot be read in the past. The reported rate is per
stipulated hypothetical channel use, not per laboratory trial or unit time.

Full normalization, maximum-error and resource details are in
`noisy_memory/asymptotic_bridge.md` and `noisy_memory/rate_witness.md`.

## Contents

- `proofs/extended_notebook.tex`: editable public source corresponding to the
  separately delivered notebook PDF. It contains full definitions, constructions,
  upper bounds and encoder-class coverage, not only numerical summaries.
- `noisy_memory/`: classical solver helpers, public M3/M4/multiplicity proofs,
  exact rational certificates and independent verification code.
- `quantum_memory/`: explicit rational qubit witnesses, exact SymPy and independent
  standard-library matrix checks, interval and heralding certificates; exploratory
  nonlinear search is separately identified as non-global. The special-point
  global theorem has its own complete public proof and symbolic verifier. The
  general-noise scalar theorem, rational oracle and seven exact certificates
  are also included. The M3 scalar corollary and exact no-advantage theorem
  include the full Bernstein certificate and two exact symbolic verifiers.
  `finite_alphabet_theorem.md` and its rational oracle close the full stated
  one-qubit finite-alphabet problem, with an independent standard-library checker.
- `quantum_sensor/`: conventional sensor-inclusive quantum-instrument example.
  The analytic trace-preservation proof forbids an unconditional earlier signal;
  selected correlations remain possible.
- `final_state/`: source-faithful four-qubit Lloyd-Preskill final-state replication,
  including meter circuits and the complete success/failure ledger. The conditional
  dependence is reproduced, not refuted; all final outcomes restore invariance.
- `reference_results/`: saved numerical outputs and check summaries from the
  tested environment. Exact certificate inputs remain beside their verifiers.
- `requirements.txt`, `environment.json`, `SHA256SUMS`: tested versions and package
  integrity metadata. No software license is assigned by this bundle.

Private task notes, audit correspondence, old manuscripts, cache files and
third-party paper copies are excluded. Public mathematical proof notes have been
edited to stand alone; they are not the private audit records.

## Fast exact verification without an optimizer

From the extracted directory, optionally check the packaged inputs first with
`sha256sum -c SHA256SUMS` on systems providing that command. Do this before
regeneration, since some scripts intentionally rewrite their output files. Then:

```sh
python run_checks.py --certificates-only
```

This uses only Python's standard library. It independently verifies:

- 2,688 rational upper certificates covering all encoder tuples at 24 tested
  parameter/message-count cases;
- 24 exact feasible decoder witnesses, with the largest interval width below
  1.1e-6;
- 656 rational upper certificates and seven lower witnesses, covering every
  encoder multiplicity in the saved M=2,3,4,5,6,8,10 examples;
- seven exact general-noise quantum optimum brackets (widths below 4e-22),
  including four explicit algebraic lower-witness specifications, plus seven
  M3 brackets (widths below 5e-22), using a separate standard-library code path;
- the general finite-alphabet oracle through 100 exact row-allocation vertex
  enumerations, 1,000 comparisons with the separate M3/M4 oracles, 80 erased-memory
  endpoints and 1,021 accepted-class witness checks. These are finite regression
  checks supplementing the universal proof, not its logical foundation;
- the rate-oriented classical witness through exact Fraction channel
  contraction and 160-term rational log-series remainder bounds, proving
  mutual information >.55 and gain >.02 bits/use over direct BSC coding.

Finite certificate sets do not prove the continuous-parameter theorems. The
algebraic proofs do that; the certificates independently test implementation and
supply rigorous intervals at their declared rational parameter points.

## Reproduce all packaged checks

Tested with Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0 and mpmath 1.3.0. Use a virtual
environment and run from the package root:

```sh
python -m venv .venv
# macOS/Linux
. .venv/bin/activate
# Windows PowerShell alternative: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run_checks.py
python run_checks.py --full
```

The default run adds the direct three-message construction checks, 28,917 sensor
cases and 3,000 generic trace identities, source-faithful final-state calculations,
exact quantum witnesses, the noise interval, late-heralding ledger and
verified special-point global quantum bound, and exact general-noise scalar
certificates, both exact M3 Bernstein sign verifiers, and regeneration of all 19
finite-alphabet certificate cases (11 rational brackets and 8 exact values),
plus the bounded numerical rate check and exact rate-witness certificate. It compares
regenerated branch JSON against saved outputs within stated floating-point
tolerances (relative 1e-8, absolute 1e-9). Exact rational certificate strings
remain exact comparisons. Only the bridge's numerical decimal strings are
compared numerically, and optimizer iteration counts there are not required to
match. SymPy/standard-library certificates use exact rational arithmetic.

`--full` additionally proposes and verifies 1,024 M3 and 4,608 M4 rational dual
certificates using fresh LP solutions, and repeats four-message construction and
all-multiset numerical checks. LP solvers propose these certificates; exact
Fraction arithmetic verifies their inequalities. A different compatible solver
can produce different valid dual weights; byte-for-byte identity of solver
outputs is not required. These runs may take minutes.

The runner writes fresh output and logs beside the extracted scripts, under
`generated_checks/` for its summary. All script paths resolve relative to their
own location, so the runner itself can be invoked from another working directory.
Do not run Python with `-O`: that disables the mathematical assertions.

## Optional regeneration and exploration

The default/full runner does NOT repeat the original long exhaustive search or
nonconvex optimization. To regenerate the initial classical LP proposals and
certificates, run these in order:

```sh
python noisy_memory/solve.py
python noisy_memory/certify.py
python noisy_memory/certify_lower.py
python noisy_memory/verify_certificates.py
python noisy_memory/verify_lower_witnesses.py
python noisy_memory/multiplicity_solver.py
python noisy_memory/verify_multiplicity_certificates.py
```

These overwrite solver outputs in the extracted copy. Recomputed dual choices
may differ while remaining valid. `python quantum_memory/search.py` repeats the
seeded bounded nonlinear exploration; feasibility tolerances and local search do
not certify exact matrix feasibility, a quantum optimum, or the absence of a gap.
Tiny determinant residuals can hide negative eigenvalues near zero-trace states.
The special-point global proof and general-noise scalar characterization are
analytic, not certifications of local optimizer convergence. Exact witnesses do not
depend on that search succeeding.

To rebuild the typeset notebook, use a standard LaTeX installation with the
packages declared at the top of `proofs/extended_notebook.tex`, and compile that
source twice for references, for example from the extracted package root:

```sh
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=proofs proofs/extended_notebook.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=proofs proofs/extended_notebook.tex
```

PDF generation is not needed to verify the math.

## Primary context and priority boundary

- Ji, Lloyd and Wilde, *Retrocausal Capacity of a Quantum Channel: Communicating
  Through Noisy Closed Timelike Curves* (2026 version):
  https://arxiv.org/html/2509.08965v3 . Its noisy-forward-memory discussion motivates
  the restricted task; the general quantum/asymptotic rate frontier is not solved.
- Ji, Regula and Wilde, *Postselected communication over quantum channels*:
  https://arxiv.org/html/2308.02583v3#S3.E20 . Eq.20 gives the minimax
  conditional-error objective (one minus our success). Its assistance
  conventions are not silently interchangeable with the charged architecture here.
- Carney, *Tracing the Loop: Non-Causal Computation, Partial Traces, & Postselected
  Entanglement* (2026 v2): https://arxiv.org/html/2609.08716v2 . Input-independent
  normalization in that framework differs from the message-dependent ratios here.
- Preskill, *Quantum Information*, Chapter 3:
  https://www.preskill.caltech.edu/ph219/chap3_15.pdf .
- Gammelmark, Julsgaard and Molmer, *Past quantum states* (2013):
  https://arxiv.org/abs/1305.0681 .
- Lloyd and Preskill, *Unitarity of black hole evaporation in final-state projection
  models* (2014): https://preskill.caltech.edu/pubs/preskill-2014-final-state.pdf .
- Gallego et al., *Device-independent tests of classical and quantum dimensions*
  (2010): https://arxiv.org/abs/1010.5064 .
- Bowles, Quintino and Brunner, *Certifying the dimension of classical and quantum
  systems in a prepare-and-measure scenario with independent devices* (2014):
  https://arxiv.org/abs/1311.1525 .

- Shannon, *A Mathematical Theory of Communication* (1948):
  https://onlinelibrary.wiley.com/doi/10.1002/j.1538-7305.1948.tb01338.x .
  Classical coding foundation for the explicitly product-use bridge.
- Bennett et al., *Teleporting an Unknown Quantum State via Dual Classical and
  Einstein-Podolsky-Rosen Channels* (1993):
  https://doi.org/10.1103/PhysRevLett.70.1895 . Standard teleportation, with all
  Bell-half forward uses separately charged in the bridge.

- Csiszár, *The Method of Types* (1998), Section IV:
  https://doi.org/10.1109/18.720546 . Constant-composition coding foundation;
  the common-normalizer and simulator-cost calculations are model-specific.

This is a bounded literature comparison, not a priority guarantee. No claim is
made that the exact formulas or prepare-and-measure advantage are first in the
literature. The rigorous progress is the explicitly scoped mathematical analysis
and reproducible verification, not evidence that nature provides the stipulated
backward or final-boundary resource.
