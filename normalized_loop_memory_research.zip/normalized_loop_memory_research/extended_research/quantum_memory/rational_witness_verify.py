"""Exact prepare-measure witness verification using SymPy, no optimizer."""
import sympy as S
import json
from pathlib import Path
R=S.Rational; I=S.eye(2); O=S.zeros(2)

def verify(eps,x,nx,nz):
 p=R(1,10); A=1-p
 E=[I,O,(I+S.Matrix([[nz,nx],[nx,-nz]]))/2,(I+S.Matrix([[nz,-nx],[-nx,-nz]]))/2]
 tau=[[O,O] for _ in range(4)]
 tau[0][0]=x*S.diag(0,1);tau[1][1]=x*S.diag(1,0)
 for m,sgn in [(2,1),(3,-1)]:
  for b in range(2):
   s=sgn*(-1)**b
   tau[m][b]=(1-x)/4*S.Matrix([[1,s],[s,1]])
 def psd(H):
  assert H==H.T
  assert H[0,0]>=0 and H[1,1]>=0 and H.det()>=0
 for m in range(4):
  psd(E[m]);psd(I-E[m])
  for b in range(2):psd(tau[m][b])
 for b in range(2):assert sum(S.trace(tau[y][b]) for y in range(4))==1
 W=[]
 for m in range(4):
  row=[]
  for y in range(4):
   w=0
   for b in range(2):
    T=(1-eps)*tau[y][b]+eps*S.trace(tau[y][b])*I/2
    for a in range(2):
     effect=E[m] if a==0 else I-E[m]
     w+=(A if a==b else p)*S.trace(effect*T)
   row.append(S.factor(w))
  W.append(row)
 Z=[sum(row) for row in W]
 succ=[S.factor(W[m][m]/Z[m]) for m in range(4)]
 t=min(succ);q=eps/2;s=p+q-2*p*q;r=1-s
 F=S.factor((A-(A+1)*t)*(r-(r-s)*t)-2*A*p*s*t)
 assert F<0 and t>A/2
 return {'p':str(p),'epsilon':str(eps),'q':str(q),'x':str(x),'nx':str(nx),'nz':str(nz),'weights':[[str(w) for w in row] for row in W],'normalizations':list(map(str,Z)),'successes':list(map(str,succ)),'worst_success':str(t),'worst_float':float(t),'classical_polynomial_at_witness':str(F),'all_psd_and_complete':True}
if __name__=='__main__':
 results=[verify(R(0),R(9,16),R(3,5),R(4,5)),verify(R(1,10),R(8,15),R(3,5),R(4,5)),verify(R(1,5),R(23,45),R(20,29),R(21,29))]
 out=Path(__file__).with_name('rational_witness_certificates.json');out.write_text(json.dumps(results,indent=2)+'\n')
 print(out);print(json.dumps(results,indent=2))
