# Complete finite-alphabet characterization for one forward qubit

**Exact theorem; independently checked within this AI-assisted research process.** This closes the declared one-use model for every finite message count M≥1, 0<p<1/2 and 0≤epsilon≤1. It does not address higher-dimensional memory, many channel uses, entanglement assistance, side registers, or physical backward communication. No novelty claim is made.

For rational parameters and a rational threshold, feasibility is decidable by O(M²) constant-size exact rational arithmetic tests. **No nonlinear optimizer or linear-programming solver is required.** The theorem is a complete global characterization and constructive decision procedure, not a single elementary formula for all M. M3 has the simpler exact classical-equality theorem; M4 at p=1/10, epsilon=0 has the separately proved cubic optimum.

The arithmetic-operation count is polynomial in the numerical alphabet size M, not necessarily in its bit length log M. Rational arithmetic bit costs and the requested bisection precision are separate. No independent human review or novelty determination is claimed.

## Model reduction

Set A=1−p, h=(1−2p)(1−epsilon)/2 and a=1/2+h. Write τ_mb=(t_mb I+v_mb·sigma)/2, and define T_m=t_m0+t_m1, u_m=t_m0−t_m1, d_m=v_m0−v_m1. Decoder feasibility is exactly

    ΣT_m=2, Σu_m=0, |u_m|≤T_m, |d_m|≤T_m.

Conversely set t_mb=(T_m+(-1)^b u_m)/2 and v_mb=(-1)^b t_mb d_m/T_m, taking zero states for T_m=0. Thus the Bloch-difference choice is independent of the allowed trace imbalance u.

By positive-denominator linear-fractional extremality, each message's binary effect can be chosen to be I, 0, or a rank-one projector. Enumerate counts n0,n1,N with n0+n1+N=M. Messages are distinct; equal-count grouping is only a symmetry reduction, not a shared random resource. A constant I succeeds with A t_m0+p t_m1; a constant 0 succeeds with p t_m0+A t_m1. A projector reaches threshold t iff

    T_m/2+h|d_m−tD|≥t,  D=Σd_m.                          (1)

Only 0<t≤1 needs testing. Nonpositive thresholds are trivial and thresholds above 1 impossible.

## Exact minimal trace needed by the constant labels

Let d0=n0t, d1=n1t. Denote aggregate row-0 masses of the constant groups by x0,x1, and row-1 masses by y0,y1. They obey

    A x0+p y0≥d0,  p x1+A y1≥d1,
    x0+x1≤1, y0+y1≤1, all masses nonnegative.

The minimum total constant trace C is:

1. If d0≤A and d1≤A: C=(d0+d1)/A, attained by x0=d0/A, y1=d1/A, x1=y0=0.
2. If d0>A and d1≤A: C=1+(d0−A)/p+d1/A, attained by x0=1, x1=0, y0=(d0−A)/p, y1=d1/A. It is feasible iff C≤2.
3. If d1>A and d0≤A: interchange the groups and rows in case 2.
4. If both demands exceed A, the class is infeasible.

The first lower bound is C≥(d0+d1)/A because every coefficient is at most A. For case 2, the exact lower bound is

    C≥d0/p+d1/A+1−A/p.

Indeed subtracting the corresponding weighted actual group successes from C, and then adding A/p−1, gives

    (A/p−1)(1−x0)+(1−p/A)x1≥0.

This also proves infeasibility when the stated minimum exceeds 2. Case 3 is symmetric. Case 4 would require summed group successes greater than 2A, whereas they are at most AC≤2A. These arguments allow arbitrary stochastic decoders. Split each nonempty constant group's minimizing row masses equally among its labels; then each constant succeeds exactly at threshold t.

## Zero or one projector

For N=0, feasibility is exactly feasibility of the constant allocation. Fill any unused row mass into any existing constant label. This only increases some correct numerators, and all constant denominators remain 1.

For N=1, put T=2−C. Exact feasibility is

    T/2+h[(1−t)T+tC]≥t.                                  (2)

Necessity follows from |d−tD|=|(1−t)d−tD_constant|≤(1−t)T+tC. Equality is achieved by d=+T zhat and all constant Bloch differences pointing along −zhat with norm equal to their trace. Their u values impose no additional constraint by the exact decoder reduction. For any larger constant trace, the left side minus t has derivative −1/2+h(2t−1)<0, so the minimum C is optimal. The residual projector row masses are nonnegative by the minimizing constant allocation. If the optimized encoder direction is zero, choose any unit vector; this includes the trivial M=1 perfect-success endpoint.

## Two or more projectors

For N≥2 set T=(2−C)/N. Let the residual row masses after the minimizing constant allocation be R0,R1. Give every projector row masses R0/N,R1/N, hence common trace T and common u=(R0−R1)/N. Automatically |u|≤T; there is no further row-balance restriction for any M or counts.

If aT≥t, the class is feasible. Set every constant Bloch difference to zero, and arrange the N projector differences of norm T as a regular N-gon in a plane. They sum to zero (N=2 means opposite vectors), so D=0 and every projector succeeds with aT.

Otherwise aT<t. If h=0 the class is infeasible. If h>0 define

    r_min=(1−aT/t)/h>0,
    P_N(r,t)=t(Nt−2)r²+2tCr+NT²−N(t−T/2)²/h².

The class is feasible **if and only if**

    r_min≤2 and max_{r∈[r_min,2]} P_N(r,t)≥0.               (3)

The exact maximum requires the two endpoints and, if the quadratic is concave and its vertex lies in the interval, the vertex. Every input and computed quantity is rational for rational p, epsilon, t.

### Necessity of (3)

For r=|D|>0, each projector's maximal longitudinal coordinate z=d·D/r as a function of its trace is the concave cap

    L=t(1−hr)/a, H=t(1+hr)/a,
    g(S)=[S²+t²r²−(t−S/2)²/h²]/(2tr), L≤S≤H,
    g(S)=S, S≥H.

Its derivative is at least 1, and g′(H)−1=(2−r)/(2hr)≥0. It is feasible only for S≥L. These claims follow from |d|≤S and (1), as detailed in `general_scalar_bound.md`.

If an arbitrary feasible decoder assigns actual constant trace C_actual≥C, Jensen and the cap slope give

    r≤C_actual+N g((2−C_actual)/N)≤C+N g(T).

The last inequality uses that adding trace to projectors instead of constants cannot decrease this bound. The average remains in the feasible domain when C is reduced. Since aT<t, one has T<t/a≤H, so the quadratic cap applies. Its domain is exactly r≥r_min; rearranging the last inequality is P_N≥0. The r=0 case cannot help when aT<t, including any larger C_actual.

### Sufficiency of (3)

Choose r satisfying (3). Give every projector the common trace and u already specified. Choose a constant aggregate Bloch difference B zhat with B∈[−C,C], and a common projector longitudinal coordinate z∈[−T,g(T)]. Give their transverse components length sqrt(T²−z²), arranged as a regular N-gon so they sum to zero. The possible total longitudinal sum B+Nz fills [−2,C+Ng(T)], which contains r. Thus choose B,z giving D=r zhat. If C>0, split B among the constant labels proportionately to their traces. If C=0, there are no positive-trace constants, B=0, and this proportional split is skipped. All Bloch vectors obey their trace constraints.

Each projector now has |d|=T and z≤g(T), so (1) holds. Choose its encoder direction along d−tD. The exact decoder reconstruction supplies valid states, and the constant-label successes remain exactly t. This proves sufficiency without side memory, shared randomness, or extra communication.

## Complete decision procedure and endpoint formula

A threshold is globally feasible iff at least one count triple passes its corresponding test. The count triples number (M+1)(M+2)/2. The proof covers every extreme-encoder class and constructs a valid protocol for each accepted threshold. Compactness and denominators bounded below by 2p ensure an attained optimum. Exact bisection yields arbitrary-width rational enclosures.

M=1 has optimum 1. At complete depolarization epsilon=1, memory is erased and the exact optimum is

    M=2k: A/k;        M=2k+1: A/(k+A).

For constant-group sizes j≥l, j+l=M, the row-allocation formula gives optimum A/(jA+lp). This denominator is minimized by the most balanced split, yielding the displayed formulas. Effects on fully mixed memory are equivalent to classical stochastic encoders, whose extremes are constants, so no omitted projector class can improve them.

`finite_alphabet_oracle.py` implements all branches with Python Fraction arithmetic, returns exact accepted-class data or complete rejected-class certificates, and writes illustrative optimum brackets to `finite_alphabet_certificates.json`. For M≥2 it initializes a strictly infeasible upper bound above U_M=A/[A+(M−1)p]; this universal upper bound follows from the correct/failure-weight argument with a label of trace at most 2/M. M=1 and complete erasure are handled exactly.

**Stopping boundary:** this is the full fixed-dimension, one-use, finite-alphabet problem stated here. No extension to many-use capacity, larger memory dimensions, or operational backward signalling is asserted.
