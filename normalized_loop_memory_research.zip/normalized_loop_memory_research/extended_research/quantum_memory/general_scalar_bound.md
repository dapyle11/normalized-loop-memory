# Exact scalar feasibility characterization for all M4 noise parameters

AI-generated mathematical proof note. Verification described here is computational and AI-assisted, not independent human peer review. No novelty or physical-device claim is made.

**Scope:** the README operational model, 0<p<1/2 and 0≤epsilon≤1. This extends `global_quantum_optimum.md`. This is a proof-derived finite scalar characterization, not a numerical nonconvex search. The proof and exact oracle have been independently checked by a separate AI-assisted verification pass; no independent human review or novelty claim is asserted.

Put A=1−p, h=(1−2p)(1−epsilon)/2, a=1/2+h. Let K be the exact classical M4 optimum at q=epsilon/2 from `../noisy_memory/four_message.md`, so K≥A/2. Let U=A/(A+3p)<A.

If h=0, the global optimum is K=A/2: all quantum preparations become fully mixed, so the memory is erased. Otherwise the following test is exact for any threshold **K<t≤U**.

For each N=2,3,4, define

    C=(4−N)t/A,  T=(2−C)/N,
    r_min=(1−a T/t)/h,
    P_N(r,t)=t(Nt−2)r²+2tCr+N T²−N(t−T/2)²/h².

There is a valid quantum protocol with worst success at least t if and only if, for at least one N,

    r_min≤2  and  max_{r∈[r_min,2]} P_N(r,t)≥0.                 (★)

The maximum of this quadratic needs only its two endpoints and, when its leading coefficient is negative, its vertex if in the interval. Thus exact rational inputs and a rational threshold give an exact finite arithmetic decision. The optimum is K if no improvement passes, otherwise it is the largest threshold satisfying (★). It can be specified by a finite set of polynomial equations and inequalities; rigorous rational lower/upper certificates can be obtained by bisection with exact arithmetic. Decimal calculations are illustrations, not the proof.

## Proof

Use reduced decoder variables T_m,u_m,d_m from `global_quantum_optimum.md`. The necessary and sufficient decoder constraints remain ΣT=2, Σu=0, |u_m|≤T_m, |d_m|≤T_m, with D=Σd. Constants have success T/2±(A−1/2)u. Projectors reach t iff

    T/2+h|d−tD|≥t.                                             (1)

Encoder extremality holds as before. If there are zero or one projectors, all effects commute. Dephasing every preparation in their common basis preserves all contractions and implements exactly a classical BSC(epsilon/2) forward-memory protocol. Those classes cannot beat K.

Consider N≥2 projector labels and 4−N constant labels, with arbitrary constant multiplicities. Their aggregate trace C_actual must be at least C because each constant success is at most A T_m. The reduced variables also give a universal bound U: each correct weight is at most A T_m and its incorrect weight at least p(2−T_m), so S_m≤A T_m/[A T_m+p(2−T_m)]. Some label has T_m≤1/2, yielding min S_m≤U. Hence thresholds considered satisfy t<A.

Write r=|D|≤2. At r=0, each projector success is at most aT_m and each constant success at most AT_m, so a threshold greater than A/2 is impossible. For r>0, the exact maximum longitudinal component z=d·D/r of a projector with trace T is the concave function

    L=t(1−hr)/a, H=t(1+hr)/a,
    g(T)=[T²+t²r²−(t−T/2)²/h²]/(2tr),  L≤T≤H,
    g(T)=T,                                      T≥H.

No projector is feasible if T<L. Here H≤2t, g(L)=−L, g(H)=H, g″=(1−1/(4h²))/(tr)<0, and g′(H)−1=(2−r)/(2hr)≥0. Thus g is globally concave on its feasible domain and has slope at least 1. The quadratic bound follows by squaring (1) where T≤H≤2t. Its attainable vectors have |d|=T; the linear branch is attainable by d=T D/r.

Jensen and the slope bound give

    r≤C_actual+N g((2−C_actual)/N)≤C+N g(T).                    (2)

At t>A/2, T<t/A≤t/a, so T<H and the quadratic branch applies. Its domain condition T≥L is exactly r≥r_min. Multiplying (2) by 2tr gives P_N≥0. This proves necessity, including classes with repeated constant types.

For sufficiency, fix r satisfying (★) and use the trace C on constants. For N=2 take one constant of each type, trace C/2 each, with u=±C/2. For N=3 take one constant with trace and u both C, and assign each projector u=−C/N. This is feasible because C=t/A<1 implies C/N≤T. For N=4 there are no constants and set all u=0. Every projector has trace T.

Choose a constant aggregate Bloch difference B zhat, with B∈[−C,C]. Every projector can have a common longitudinal coordinate z∈[−T,g(T)], and transverse length sqrt(T²−z²). Arrange their transverse vectors as a regular N-gon (opposite vectors for N=2), so they sum to zero. The achievable total longitudinal sum B+Nz fills the whole interval [−C−NT,C+Ng(T)]=[−2,C+Ng(T)], which contains r by (2). Thus choose B,z giving D=r zhat. For N=2 or 3, split B among constants proportionately to their traces, ensuring every |d_m|≤T_m. For N=4 there are no constants, so B=0 and no division by C is performed. For each projector |d|=T and z≤g(T), so (1) holds. Choose its encoder direction along d−tD. The reduced-variable state construction produces valid decoder states with no extra memory. Constant success is exactly t. This establishes sufficiency.

The decoder/effect parameter space is compact, and all normalizers have the uniform positive lower bound 2p. The global optimum is therefore attained; threshold feasibility is downward closed. These facts justify the largest-feasible-threshold statement and exact bisection.

The use of opposite constants in the sufficient construction is allowed even if necessity began with a repeated-constant class: the characterization is of the global optimum, not of each fixed multiset separately.

## Reproducibility

`general_scalar_bound.py` implements the finite arithmetic test using Python Fraction for rational p, epsilon, and threshold. It supplies rigorous rational brackets on the global optimum by bisection, with the classical bound evaluated by its exact polynomial sign test. The seven saved brackets have widths below 4e-22. It does not invoke a nonlinear optimizer.
