"""Exact acceptance arithmetic checked against direct matrix certificates."""
import json
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).parent
rows=json.loads((root/'rational_witness_certificates.json').read_text())
expected=[F(16,45),F(433,1125),F(8299,19575)]
results=[]
for row,want in zip(rows,expected):
 A=1-F(row['p']);z=list(map(F,row['normalizations']));rates=[v/(2*A) for v in z]
 assert rates==[F(5,9),F(5,9),want,want]
 # Summing accepted weights yields acceptance; dividing by it recovers normalized successes.
 for m in range(4):
  W=list(map(F,row['weights'][m]));assert sum(w/(2*A) for w in W)==rates[m]
  assert (W[m]/(2*A))/rates[m]==F(row['successes'][m])
 results.append({'epsilon':row['epsilon'],'acceptance_rates':list(map(str,rates)),'conditional_distribution_identity':True})
assert F(5,9)*(1-F(32,75)*F(4,5))==F(247,675)
assert F(5,9)*(1-F(32,75)*F(925,1293))==F(13475,34911)
(root/'heralding_certificates.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
