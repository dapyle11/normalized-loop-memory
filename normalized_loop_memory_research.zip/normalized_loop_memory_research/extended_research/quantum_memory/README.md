# One noisy forward qubit: complete finite-alphabet characterization

## Status
There **is** an achievable quantum-memory advantage in the declared one-use, worst-case classical-message model, with the same backward classical BSC and the dimension-matched forward depolarizing channel. This is an explicit finite-dimensional construction, not a claim about physical time travel or asymptotic capacity. The complete proof in `global_quantum_optimum.md` gives a closed cubic-root optimum at p=1/10, epsilon=0. The general-noise theorem in `general_scalar_bound.md` additionally characterizes the global M4 optimum throughout the stated noise domain. The simple noisy witnesses below remain useful achievable lower bounds, not the exact optima. See `rational_witness.md` and its verifier for exact certificates. Novelty remains unverified.

## Operational model
Let m,y∈{0,…,M−1}; backward input/output are classical bits a,b. For each b the early decoder prepares an instrument with classical outcome y and subnormalized qubit states τ_yb≥0 satisfying Σ_y Tr τ_yb=1. Its sole forward resource is this qubit through

L_epsilon(τ)=(1−epsilon)τ+epsilon Tr(τ) I/2, 0≤epsilon≤1.

The future encoder, knowing m, uses a binary qubit POVM E_0^m,E_1^m≥0 with E_0^m+E_1^m=I, producing classical a. There is no retained side memory, shared random seed, shared entanglement, quantum backward channel, or access to y or b except through the one qubit. Local private randomness is allowed. The declared hypothetical P-CTC contraction is

w_m(y)=Σ_ab N_p(b|a) Tr[E_a^m L_epsilon(τ_yb)],
Z_m=Σ_y w_m(y), S=min_m w_m(m)/Z_m.

For 0<p<1/2, 2p≤Z_m≤2(1−p); all ratios are well-defined. A commuting preparation/measurement restriction embeds exactly the previous one-bit forward BSC model with q=epsilon/2: computational-basis preparations followed by depolarization and computational-basis readout have crossover epsilon/2. Arbitrary diagonal τ and diagonal effects represent arbitrary stochastic classical decoders/encoders. Thus the comparison is against the proved global optimum for *all* allowed stochastic one-bit protocols, not merely one particular baseline.

## Numerical exploration (not a global certificate)
`search.py` uses bounded joint SLSQP, analytic constraint Jacobians, Bloch-coordinate PSD constraints, and independent projective/constant effect choices. Every extreme binary effect is 0, I, or a rank-one projector. For a fixed decoder, each encoder's ratio is linear-fractional with positive denominator, so an extreme effect is at least as good as any mixed effect. This justifies the type classification, but **does not make the remaining joint nonconvex optimization globally solvable**.

The exploratory run used three random starts for each nonzero-projector type count, the five (p,epsilon) pairs below, and M=3,4. All-constant protocols are already included analytically through the classical baseline (they were not included in the initial numerical loops). Results are stored in `search_results.json`; Tiny apparent M3 gaps around 10^−10 are numerical tolerance, not certified advantages.

| M | p | epsilon | best found (including classical baseline) | exact classical optimum |
|---|---|---|---|---|
|3|.1|0|.7085742616|.7085742616|
|3|.1|.2|.6441077410|.6441077410|
|3|.1|.6|.5512200403|.5512200403|
|3|.25|0|.5394176952|.5394176952|
|3|.25|.4|.4925571567|.4925571567|
|4|.1|0|.5060544273|.4653307872|
|4|.1|.2|.4613452886|.4588195769|
|4|.1|.6|.4500000000|.4500000000|
|4|.25|0|.3955007644|.3908196476|
|4|.25|.4|.3760658831|.3760658831|

The nonclassical entries are approximate local-search candidates, not certified maxima or exact feasibility certificates. In near-zero-trace matrix blocks, determinant tolerances can conceal tiny negative eigenvalues, so solver success alone is insufficient. The exact rational witnesses below carry the separation claim independently. The local searches themselves prove nothing globally. The separate exact theorem in `m3_no_advantage.md` now establishes uniform M3 equality with the classical optimum, by symbolic sign certificates rather than these numerical searches.

## Relation to primary literature
Ji, Lloyd, Wilde, *Retrocausal Capacity of a Quantum Channel: Communicating Through Noisy Closed Timelike Curves*, [arXiv:2509.08965v3](https://arxiv.org/html/2509.08965v3), 2026 version, motivates studying noisy forward memory. The paper's decoder–memory–encoder framework and open noisy-memory discussion motivate, but do not by themselves specify, all restrictions above. This note studies one fixed classical backward channel, one forward qubit, and one-use minimax classical-message success. It neither settles their general noisy-memory rate frontier nor establishes scientific priority. The primary page was checked in this session.

## Prior conceptual context (not a priority determination)
The general fact that dimension-matched quantum and classical prepare-and-measure systems can behave differently predates this calculation. For example, Gallego, Brunner, Hadley, Acín, [*Device-independent tests of classical and quantum dimensions*](https://arxiv.org/abs/1010.5064) (2010), develops dimension witnesses, and Bowles, Quintino, Brunner, [*Certifying the dimension of classical and quantum systems in a prepare-and-measure scenario with independent devices*](https://arxiv.org/abs/1311.1525) (2014), explicitly treats an independent-device nonconvex setting. The present normalized loop objective is not established here to be equivalent to those witnesses, and this limited contextual search is not a novelty review.

## Reproduce certified results
Run `python rational_witness_verify.py` (SymPy) for direct matrix certificates, and `python verify_interval.py` (SymPy) for the exact fixed-protocol interval endpoint and monotonicity identities. The interval certificate uses the separately proved classical M4 bound. `python audit_exact.py` is an independent standard-library Fraction check of an additional witness. Exploratory numerical reruns use `OPENBLAS_NUM_THREADS=1 python search.py` (NumPy/SciPy); its outputs must not be interpreted as global quantum optimality certificates.

`forward_heralded_simulation.md` provides an ordinary forward rejection-sampling realization of the **late-selected** statistics, with explicit acceptance costs and a trusted-verifier resource ledger. It proves no signalling to the earlier unconditioned record. `python verify_heralding.py` (standard library only) checks acceptance arithmetic against the direct matrix certificates. This simulator requires privately retaining b for the later verifier, never giving the protocol encoder that side information; this apparatus resource is disclosed and must be identical for the classical comparator.

## Exact general-noise four-message characterization

The later result in `general_scalar_bound.md` gives an exact global characterization
for all 0<p<1/2 and 0<=epsilon<=1 in this declared M4 model. It combines the
matched classical optimum with three scalar quadratic interval tests and a
constructive decoder. `general_scalar_bound.py` uses exact Fraction arithmetic,
not an optimizer, to emit rigorous brackets and algebraic-state specifications.
No result here establishes scientific priority, general asymptotic capacity or a
physical backward channel.

## Three-message equality and minimum message count

`m3_scalar_bound.md` gives the exact scalar corollary; `m3_no_advantage.md` proves
uniform equality of the M3 quantum and matched classical optima, using a complete
10-by-4 Bernstein sign certificate. Two separate symbolic derivations and full
polynomial reconstructions are reproducible. Along with the binary-message
trace bound and four-message witness, this makes four the smallest message count
with strict qubit advantage in this restricted one-use model. It is not a
universal statement about all classical/quantum communication tasks.

## Complete finite-alphabet theorem

`finite_alphabet_theorem.md` and `finite_alphabet_oracle.py` give a complete
constructive exact characterization for every finite M>=1 in the declared
one-use model. The oracle enumerates at most (M+1)(M+2)/2 encoder-count classes
and uses only rational arithmetic and scalar quadratic tests; it calls neither
a nonlinear optimizer nor an LP solver. Complexity is counted in numerical M,
with arithmetic bit cost and requested precision separate. The independent
standard-library verifier checks exact row-allocation vertices, specialized
M3/M4 decisions, erased-memory endpoints and reconstructed witnesses.
No claim extends to higher memory dimensions, additional uses, entanglement
assistance, hidden side memory or physical backward communication.

The minimax conditional-success objective itself is not new: it is one minus
the conditional-error quantity in Ji, Regula and Wilde (2024), Eq.20,
https://arxiv.org/html/2308.02583v3#S3.E20 . The present mathematical restrictions
concern the allowed architecture and charged finite-dimensional noisy memory.
