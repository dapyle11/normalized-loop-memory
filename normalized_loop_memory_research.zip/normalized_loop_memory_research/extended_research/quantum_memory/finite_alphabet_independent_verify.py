"""Independent exact regression of the finite-alphabet oracle.
Standard library only. Rational vertex enumeration checks the row-allocation LP;
separate previously proved M3/M4 oracles and exact reconstructed witness
constraints cross-check the general decision procedure. These finite tests
supplement the symbolic theorem; they do not replace its universal proof.
"""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json
import random
import finite_alphabet_oracle as general
import m3_scalar_bound as three
import general_scalar_bound as four

def solve(rows, rhs):
    a=[list(row)+[b] for row,b in zip(rows,rhs)]
    for k in range(4):
        pivot=next((i for i in range(k,4) if a[i][k]),None)
        if pivot is None:return None
        a[k],a[pivot]=a[pivot],a[k]
        z=a[k][k];a[k]=[v/z for v in a[k]]
        for i in range(4):
            if i!=k:
                z=a[i][k];a[i]=[u-z*v for u,v in zip(a[i],a[k])]
    return tuple(a[i][4] for i in range(4))

def row_lp(p,n0,n1,t):
    A=1-p
    rows=[[-1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,-1],
          [1,1,0,0],[0,0,1,1],[-A,0,-p,0],[0,-p,0,-A]]
    rhs=[0,0,0,0,1,1,-n0*t,-n1*t]
    rows=[[F(x) for x in row] for row in rows];rhs=list(map(F,rhs))
    vertices=[]
    for ix in combinations(range(8),4):
        point=solve([rows[i] for i in ix],[rhs[i] for i in ix])
        if point is not None and all(sum(c*x for c,x in zip(row,point))<=b for row,b in zip(rows,rhs)):
            vertices.append(point)
    return min(map(sum,vertices)) if vertices else None

def check_witness(M,p,e,t,c):
    n0,n1,N=c['n0'],c['n1'],c['N'];A=1-p;h=(1-2*p)*(1-e)/2
    al=c['constant_allocation'];x0,x1=al['row0'];y0,y1=al['row1'];C=al['C']
    assert min(x0,x1,y0,y1)>=0 and x0+x1<=1 and y0+y1<=1
    assert A*x0+p*y0==n0*t and p*x1+A*y1==n1*t
    assert C==x0+x1+y0+y1
    if not N:return
    T=c['projector_trace'];u=c['projector_u']
    assert N*T+C==2 and N*u+x0+x1-y0-y1==0 and abs(u)<=T
    B=c['constant_aggregate_z'];z=c['projector_z']
    assert -C<=B<=C and -T<=z<=T
    if N==1:
        assert z==T and B==-C
        assert T/2+h*((1-t)*T+t*C)>=t
    elif c['r']==0:
        assert B+N*z==0 and z==0
        assert (F(1,2)+h)*T>=t
    else:
        r=c['r'];assert B+N*z==r and 0<r<=2
        norm2=T*T-2*t*r*z+t*t*r*r
        assert norm2>0 and norm2==c['encoder_direction_norm_squared']
        assert t-T/2>0 and h*h*norm2>=(t-T/2)**2
    if N>=2:assert c['projector_transverse_squared']==T*T-z*z>=0
    for n,x,y in [(n0,x0,y0),(n1,x1,y1)]:
        if n:
            trace=(x+y)/n;imbalance=(x-y)/n
            assert abs(imbalance)<=trace
            dz=trace*B/C if C else F(0)
            assert abs(dz)<=trace

rng=random.Random(275);lp_cases=100
for _ in range(lp_cases):
    p=F(rng.randrange(1,50),100);n0=rng.randrange(7);n1=rng.randrange(7);t=F(rng.randrange(1,101),100)
    expected=row_lp(p,n0,n1,t);actual=general.constant_allocation(p,n0,n1,t)
    assert expected==(actual['C'] if actual is not None else None)
comparisons=0
for _ in range(500):
    p=F(rng.randrange(1,50),100);e=F(rng.randrange(11),10);t=F(rng.randrange(1,101),100)
    for M,other in [(3,three),(4,four)]:
        assert general.decision(M,p,e,t)['feasible']==other.feasible(p,e,t)
        comparisons+=1
witnesses=0;branches=set()
for _ in range(150):
    M=rng.randrange(1,13);p=F(rng.randrange(1,50),100);e=F(rng.randrange(11),10);t=F(rng.randrange(1,101),100)
    for c in general.decision(M,p,e,t,True)['classes']:
        if c['feasible']:
            check_witness(M,p,e,t,c);witnesses+=1;branches.add(c['reason'])
erased=0
for M in range(1,21):
    for p in [F(1,100),F(1,10),F(1,4),F(49,100)]:
        k=general.erased_value(M,p)
        assert general.decision(M,p,F(1),k)['feasible']
        assert not general.decision(M,p,F(1),k+F(1,1000000))['feasible']
        erased+=1
# Ensure a nontrivial curved-branch algebraic witness is tested.
for c in general.decision(4,F(1,10),F(0),F(101,200),True)['classes']:
    if c['feasible']:
        check_witness(4,F(1,10),F(0),F(101,200),c)
        witnesses+=1;branches.add(c['reason'])
assert 'exact quadratic maximum' in branches
out={'status':'PASS','exact_row_lp_vertex_enumerations':lp_cases,'exact_specialized_oracle_comparisons':comparisons,'exact_erased_memory_endpoint_pairs':erased,'accepted_class_witness_checks':witnesses,'accepted_branches':sorted(branches),'scope':'Independent finite regressions supplement the universal symbolic proof.'}
Path(__file__).with_name('finite_alphabet_independent_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
