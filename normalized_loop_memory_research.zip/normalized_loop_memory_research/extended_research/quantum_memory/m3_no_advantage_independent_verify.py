import sympy as S
from math import comb
p,v,w,x=S.symbols('p v w x'); A=1-p;t=A*v/(1+A*v)
a=S.factor(t*t/(A-(A+1)*t+2*t*t));h=a-S.Rational(1,2)
C=t/A;T=1-C/2
Pmax=S.factor(2*T*T-2*(t-T/2)**2/h**2+t*C*C/(2*(1-t)))
print('a=',a)
num,den=S.fraction(Pmax);print('num factors:',S.factor(num));print('den:',S.factor(den))
H=S.cancel(Pmax*2*(v-1)**2*(p*v-v-1)**4/(v*A))
assert S.denom(H)==1
H=S.expand(H)
print('H=',H)
R,denR=S.fraction(S.cancel(H.subs(p,w/(v*(v+1)))))
print('denR=',S.factor(denR))
P=S.Poly(S.expand(R.subs(v,1+3*x)),x,w);nx,nw=P.degree(x),P.degree(w)
B={}
for i in range(nx+1):
 for j in range(nw+1):
  B[i,j]=sum(P.coeff_monomial(x**aa*w**bb)*S.Rational(comb(i,aa),comb(nx,aa))*S.Rational(comb(j,bb),comb(nw,bb)) for aa in range(i+1) for bb in range(j+1))
assert all(b<=0 for b in B.values())
# Reconstruct polynomial from Bernstein basis as an independent normalization check.
reconstructed=sum(b*comb(nx,i)*x**i*(1-x)**(nx-i)*comb(nw,j)*w**j*(1-w)**(nw-j) for (i,j),b in B.items())
assert S.expand(reconstructed-P.as_expr())==0
print('degree=',nx,nw)
print('zeros=',[k for k,z in B.items() if z==0])
for i in range(nx+1): print(i,[str(B[i,j]) for j in range(nw+1)])
print('edges at x1:',S.factor(P.as_expr().subs(x,1)),'w1:',S.factor(P.as_expr().subs(w,1)))
# Domain relations and scalar maximum identities, checked independently.
assert S.factor(a-S.Rational(1,2)-(v-1)*(A*v+1)/(2*(A*v*v-p*v+1)))==0
assert S.factor(a-A-A*(p*v*(v+1)-1)/(A*v*v-p*v+1))==0
assert S.factor(C/(2*(1-t))-v/2)==0
rho,tt,hh,NN,TT=S.symbols('rho tt hh NN TT')
CC=2-NN*TT
PN=tt*(NN*tt-2)*rho**2+2*tt*CC*rho+NN*TT**2-NN*(tt-TT/2)**2/hh**2
assert S.factor(PN.subs(rho,2)-NN*(4-1/hh**2)*(tt-TT/2)**2)==0
assert B[9,3]==-147456
import json
from pathlib import Path
Path(__file__).with_name('m3_no_advantage_independent_certificate.json').write_text(json.dumps({'status':'PASS','H':str(H),'cleared_denominator':str(S.factor(denR)),'degrees':[nx,nw],'bernstein_coefficients':[[str(B[i,j]) for j in range(nw+1)] for i in range(nx+1)],'zero_coefficients':[list(k) for k,z in B.items() if z==0],'strict_coefficient':{'index':[9,3],'value':str(B[9,3])},'identities':'Exact symbolic vertex derivation, parameter constraints, endpoint formula, and full Bernstein reconstruction verified.'},indent=2)+'\n')
print('PASS: independent full symbolic certificate')
