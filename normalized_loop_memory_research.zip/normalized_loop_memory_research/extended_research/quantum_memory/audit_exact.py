#!/usr/bin/env python3
"""Independent rational 2x2-matrix audit; standard library only; no optimizer."""
from fractions import Fraction as F
import json
from pathlib import Path
Z=((F(0),F(0)),(F(0),F(0)))
I=((F(1),F(0)),(F(0),F(1)))
def add(A,B):return tuple(tuple(A[i][j]+B[i][j] for j in range(2)) for i in range(2))
def scale(a,A):return tuple(tuple(a*A[i][j] for j in range(2)) for i in range(2))
def tr(A):return A[0][0]+A[1][1]
def multrace(A,B):return sum(A[i][j]*B[j][i] for i in range(2) for j in range(2))
def psd(A):return A[0][1]==A[1][0] and A[0][0]>=0 and A[1][1]>=0 and A[0][0]*A[1][1]>=A[0][1]*A[1][0]
def bloch(t,x,z):return ((F(t+z)/2,F(x)/2),(F(x)/2,F(t-z)/2))
tau=[
 [Z,bloch(F(14,25),0,-F(14,25)),bloch(F(1,4),F(1,4),0),bloch(F(19,100),-F(19,100),0)],
 [bloch(F(14,25),0,F(14,25)),Z,bloch(F(19,100),-F(19,100),0),bloch(F(1,4),F(1,4),0)]
]
E0=[Z,I,bloch(1,F(3,5),F(4,5)),bloch(1,-F(3,5),F(4,5))]
E=[[e,add(I,scale(-1,e))] for e in E0]
assert all(psd(t) for row in tau for t in row)
assert all(sum(map(tr,row))==1 for row in tau)
assert all(psd(e) for row in E for e in row)
assert all(add(*row)==I for row in E)
p=F(1,10)
w=[[sum((1-p if b==a else p)*multrace(tau[b][h],E[m][a]) for a in range(2) for b in range(2)) for h in range(4)] for m in range(4)]
normalizers=[sum(row) for row in w]
assert all(2*p<=z<=2*(1-p) for z in normalizers)
s=[w[m][m]/normalizers[m] for m in range(4)]
assert s==[F(63,125),F(63,125),F(407,802),F(407,802)]
assert min(s)==F(63,125)>F(1,2)>F(9,19)
# Exact classical root: (A-(A+1)T)(A-(A-p)T)=2 A p^2 T.
A=1-p
def classical_poly(t):return (A-(A+1)*t)*(A-(A-p)*t)-2*A*p*p*t
assert classical_poly(F(465330787,10**9))>0
assert classical_poly(F(465330788,10**9))<0
out={'method':'exact Fraction arithmetic on real 2x2 matrices','decoder_psd':True,'decoder_row_trace_one':True,'encoder_povm_psd_complete':True,'weights':[[str(v) for v in row] for row in w],'normalizers':list(map(str,normalizers)),'per_message_success':list(map(str,s)),'worst_success':str(min(s)),'classical_optimum_bracket':['465330787/1000000000','465330788/1000000000'],'all_assertions_pass':True}
# Independently verify the author's symmetric noisy witnesses, without SymPy.
def verify_symmetric(epsilon,x,nx,nz):
    es=[I,Z,bloch(1,nx,nz),bloch(1,-nx,nz)]
    ts=[[bloch(x,0,-x),Z,bloch((1-x)/2,(1-x)/2,0),bloch((1-x)/2,-(1-x)/2,0)],
        [Z,bloch(x,0,x),bloch((1-x)/2,-(1-x)/2,0),bloch((1-x)/2,(1-x)/2,0)]]
    assert nx*nx+nz*nz==1
    assert all(psd(e) and psd(add(I,scale(-1,e))) for e in es)
    assert all(psd(t) for row in ts for t in row)
    assert all(sum(map(tr,row))==1 for row in ts)
    noisy=[[add(scale(1-epsilon,t),scale(epsilon*tr(t)/2,I)) for t in row] for row in ts]
    ww=[[sum((1-p if b==a else p)*multrace(noisy[b][h],es[m] if a==0 else add(I,scale(-1,es[m]))) for a in range(2) for b in range(2)) for h in range(4)] for m in range(4)]
    zz=[sum(row) for row in ww]
    assert all(2*p<=z<=2*(1-p) for z in zz)
    ss=[ww[m][m]/zz[m] for m in range(4)]
    q=epsilon/2; rr=1-p-q+2*p*q; ssnoise=1-rr; t=min(ss)
    poly=(A-(A+1)*t)*(rr-(rr-ssnoise)*t)-2*A*p*ssnoise*t
    assert poly<0 and t>A/2
    return {'epsilon':str(epsilon),'x':str(x),'nx':str(nx),'nz':str(nz),'successes':list(map(str,ss)),'minimum':str(t),'normalizers':list(map(str,zz)),'classical_polynomial_at_minimum':str(poly)}
authors=[verify_symmetric(F(0),F(9,16),F(3,5),F(4,5)),verify_symmetric(F(1,10),F(8,15),F(3,5),F(4,5)),verify_symmetric(F(1,5),F(23,45),F(20,29),F(21,29))]
assert [a['minimum'] for a in authors]==['259/512','12/25','23/50']
out['independent_author_family_checks']=authors
Path(__file__).with_name('audit_exact_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
