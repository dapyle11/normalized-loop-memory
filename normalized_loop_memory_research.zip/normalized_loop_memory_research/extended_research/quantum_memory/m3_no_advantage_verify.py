"""Exact symbolic + Bernstein certificate for M3 quantum=classical.
Derives the sign polynomial from the scalar upper bound, rather than taking it
from a numerical search. No floating-point calculations are used.
"""
import sympy as S
from math import comb
import json
from pathlib import Path
p,v,w,x=S.symbols('p v w x');A=1-p
t=A*v/(1+A*v)
a=S.factor(t*t/(2*t*t-(A+1)*t+A));h=a-S.Rational(1,2)
C=t/A;T=1-C/2
Q=S.factor(2*(T*T-(t-T/2)**2/h**2)+t*C*C/(2*(1-t)))
H=S.factor(Q*2*(v-1)**2*(1+A*v)**4/(A*v))
assert S.denom(H)==1
assert S.simplify(a-A*v*v/(v*v+1-p*v*(v+1)))==0
assert S.simplify(C/(2*(1-t))-v/2)==0
expr=S.cancel(H.subs(p,w/(v*(v+1))))
R=S.expand(expr*(v+1)**3)
R=S.cancel(R)
assert S.denom(R)==1
P=S.Poly(S.expand(R.subs(v,1+3*x)),x,w)
nx,nw=P.degree(x),P.degree(w)
assert (nx,nw)==(9,3)
coeff=[]
for i in range(nx+1):
 row=[]
 for j in range(nw+1):
  z=sum(P.coeff_monomial(x**aa*w**bb)*S.Rational(comb(i,aa),comb(nx,aa))*S.Rational(comb(j,bb),comb(nw,bb)) for aa in range(i+1) for bb in range(j+1))
  assert z<=0
  row.append(z)
 coeff.append(row)
assert all(z<0 for z in coeff[-1])
reconstruction=sum(coeff[i][j]*comb(nx,i)*x**i*(1-x)**(nx-i)*comb(nw,j)*w**j*(1-w)**(nw-j) for i in range(nx+1) for j in range(nw+1))
assert S.Poly(S.expand(reconstruction-P.as_expr()),x,w).is_zero
# Endpoint identity for arbitrary N,C,T obeying C+NT=2.
s,r,Hh,N,TT=S.symbols('s r h N T')
CC=2-N*TT
Pn=s*(N*s-2)*r*r+2*s*CC*r+N*TT*TT-N*(s-TT/2)**2/Hh**2
assert S.simplify(Pn.subs(r,2)-N*(4-1/Hh**2)*(s-TT/2)**2)==0
result={'status':'PASS: exact symbolic derivation, coefficient signs and Bernstein reconstruction', 'H':str(S.expand(H)), 'R':str(S.expand(R)), 'bernstein_degrees':[nx,nw], 'bernstein_coefficients':[[str(z) for z in row] for row in coeff], 'strictness':'For x>0 the last Bernstein row contributes x^9 times a strictly negative convex combination; all other contributions are nonpositive.', 'scope':'0<p<1/2, 0<=epsilon<=1; h=0 handled by erased-memory classical theorem.'}
Path(__file__).with_name('m3_no_advantage_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status']);print('Bernstein degrees:',nx,nw,'; all',sum(map(len,coeff)),'coefficients nonpositive; last row strictly negative.')
