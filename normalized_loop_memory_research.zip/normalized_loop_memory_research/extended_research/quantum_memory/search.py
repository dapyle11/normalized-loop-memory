"""Bounded nonconvex exploration only, not a global or exact-feasibility certificate.
Small determinant residuals may conceal negative eigenvalues near zero trace.
Use the separate exact witnesses and symbolic global proof for certified claims.
"""
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from itertools import product
import json,sys
# tau=(t I+v.sigma)/2; projective effect E0=(I+n.sigma)/2
# constant types 0=E0=0,1=E0=I,2=projective

def classical(M,p,eps):
 A=1-p;s=p+eps/2-p*eps;r=1-s
 if M==3:return 2*A*r/(r*(A+1)+np.sqrt(r*r*(A+1)**2-4*A*r*(r-s)))
 if eps/2>=A/(2*(A+1)):return A/2
 B=(A+1)*(r-s);C=A*(r-s)+(A+1)*r+2*A*p*s
 return 2*A*r/(C+np.sqrt(C*C-4*B*A*r))

def run(M,p,eps,types,seed=0):
 rng=np.random.default_rng(seed);k=types.count(2);nv=8*M+3*k+1
 e=np.zeros((M,));u=np.zeros((M,3));ix=[];j=0
 for m,typ in enumerate(types):
  e[m]=typ if typ<2 else .5
  if typ==2:ix.append(m)
 def unpack(x):
  tv=x[:8*M].reshape(2,M,4);n=x[8*M:-1].reshape(k,3);return tv,n,x[-1]
 def calc(x,jac=False):
  tv,n,z=unpack(x);u[:]=0;u[ix]=n/2
  kb=np.stack([p+(1-2*p)*e,1-p-(1-2*p)*e])
  vb=np.stack([(1-2*p)*(1-eps)*u,-(1-2*p)*(1-eps)*u])
  w=np.einsum('bm,by->my',kb,tv[:,:,0])+np.einsum('bmi,byi->my',vb,tv[:,:,1:])
  Z=w.sum(1);s=np.diag(w)-z*Z
  if not jac:return s
  J=np.zeros((M,nv))
  for m in range(M):
   for b in range(2):
    for y in range(M):J[m,(b*M+y)*4:(b*M+y+1)*4]=(float(m==y)-z)*np.r_[kb[b,m],vb[b,m]]
   if m in ix:
    j=ix.index(m);J[m,8*M+3*j:8*M+3*j+3]=(1-2*p)*(1-eps)/2*(tv[0,m,1:]-tv[1,m,1:]-z*(tv[0,:,1:].sum(0)-tv[1,:,1:].sum(0)))
  J[:,-1]=-Z;return J
 def eq(x):
  tv,n,z=unpack(x);return np.r_[tv[:,:,0].sum(1)-1,np.sum(n*n,axis=1)-1]
 def eqj(x):
  tv,n,z=unpack(x);J=np.zeros((2+k,nv));J[0,np.arange(M)*4]=1;J[1,4*M+np.arange(M)*4]=1
  for j in range(k):J[2+j,8*M+3*j:8*M+3*j+3]=2*n[j]
  return J
 def psd(x):
  tv,n,z=unpack(x);return (tv[:,:,0]**2-(tv[:,:,1:]**2).sum(2)).ravel()
 def psdj(x):
  tv,n,z=unpack(x);J=np.zeros((2*M,nv))
  for j,t in enumerate(tv.reshape(-1,4)):J[j,4*j:4*j+4]=2*t*np.array([1,-1,-1,-1])
  return J
 tv=np.zeros((2,M,4));tv[:,:,0]=rng.dirichlet(np.ones(M),2);v=rng.normal(size=(2,M,3));v/=np.linalg.norm(v,axis=2,keepdims=True);tv[:,:,1:]=tv[:,:,0,None]*v*.8
 n=rng.normal(size=(k,3));n/=np.linalg.norm(n,axis=1,keepdims=True)
 x=np.r_[tv.ravel(),n.ravel(),1/M];bounds=[(0,1) if j%4==0 else (-1,1) for j in range(8*M)]+[(-1,1)]*(3*k)+[(0,1)]
 grad=np.zeros(nv);grad[-1]=-1
 res=minimize(lambda x:-x[-1],x,jac=lambda x:grad,method='SLSQP',bounds=bounds,constraints=[{'type':'eq','fun':eq,'jac':eqj},{'type':'ineq','fun':psd,'jac':psdj},{'type':'ineq','fun':calc,'jac':lambda x:calc(x,True)}],options={'maxiter':800,'ftol':2e-11})
 err=max(abs(eq(res.x)).max(),-psd(res.x).min(),-calc(res.x).min())
 return dict(M=M,p=p,eps=eps,types=types,seed=seed,value=res.x[-1],classical=classical(M,p,eps),violation=err,success=res.success,x=res.x.tolist())
if __name__=='__main__':
 out=[]
 for M in [3,4]:
  for p,eps in [(.1,0),(.1,.2),(.25,0),(.25,.4),(.1,.6)]:
   for k in range(1,M+1):
    for c in range(M-k+1):
     types=[0]*c+[1]*(M-k-c)+[2]*k
     for seed in range(3):
      r=run(M,p,eps,types,seed);out.append(r)
      if r['violation']<1e-6:print(M,p,eps,types,seed,round(r['value'],10),round(r['value']-r['classical'],10),flush=True)
      json.dump(out,open(Path(__file__).with_name('search_results.json'),'w'),indent=2)
