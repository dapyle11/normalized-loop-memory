# Exact M3 scalar feasibility characterization

AI-generated mathematical proof note. Verification described here is computational and AI-assisted, not independent human peer review. No novelty or physical-device claim is made.

For 0<p<1/2, 0≤epsilon≤1 put A=1−p, h=(1−2p)(1−epsilon)/2, a=1/2+h. Let K3 be the exact classical three-message optimum, the smaller root of

    (2a−1)t²−a(A+1)t+Aa=0,

with the linear interpretation when a=1/2. The global qubit optimum has the following exact finite characterization. This finite criterion is complemented by `m3_no_advantage.md`, which proves that the optimum equals K3 throughout the stated domain. The scalar criterion remains valid and independently reproducible.

For h>0 and thresholds K3<t≤U3=A/(A+2p), test N=2,3 with

    C=(3−N)t/A, T=(2−C)/N,
    r_min=(1−aT/t)/h,
    P_N(r,t)=t(Nt−2)r²+2tCr+NT²−N(t−T/2)²/h².

Threshold t is feasible iff some N has r_min≤2 and max P_N over [r_min,2] nonnegative. Endpoints and an interior concave vertex suffice for the maximum. This is the exact M4 criterion with the number of constants changed from 4−N to 3−N. Its constructive proof carries over, with the trace-domain justification below.

When h=0, the memory is erased and the exact optimum is K3=A/(A+1), not A/2. Thresholds ≤K3 are always feasible by the classical theorem. Thresholds >U3 are impossible by the same correct-weight/failure-weight bound, now choosing a label of trace at most 2/3. In particular U3<A, which ensures the one-constant construction's u-balance.

## Necessary additional domain proof

The classical model includes one constant label and two opposite-bijection labels achieving

    L3=2Aa/(2A+a).

For an explicit reduced construction, assign the constant trace C=L3/A and u=C, with d=0. Give each of two projectors trace T=1−C/2 and u=−C/2, and take d vectors ±T along a fixed axis, with matching opposite projectors. Then D=0, constant success AC=L3, and projector success aT=L3. All encoder effects commute, and |u|≤T since C<1. Therefore K3≥L3. Also L3≥2a/3 since A≥a.

For N=2, t>K3≥L3 implies T=1−t/(2A)<t/a. For N=3, t>K3≥2a/3 implies T=2/3<t/a. Thus in both classes T<H=t(1+hr)/a, and r_min>0 exactly as required for the quadratic branch. The r=0 case cannot exceed L3 for N=2 or 2a/3 for N=3, so it cannot beat K3.

With N≤1 all effects commute and the classical theorem bounds them by K3. With N=2 there is one constant: C=t/A<1 and projector u=−C/2 is feasible. With N=3 there are no constants and choose all u=0. The cap-concavity upper bound and regular-polygon construction are otherwise identical to `general_scalar_bound.md`. Hence the criterion covers every admissible protocol and constructs a protocol whenever it passes.

## Limits and certificates

`m3_scalar_bound.py` uses only Fraction arithmetic and produces rigorous rational brackets, with exact classical sign tests and quadratic maxima. At the tested parameter pairs these agree with the classical values to the certified bracket widths. Such numerical agreement, even rigorously bounded, is not a proof of a uniform no-advantage identity. The finite scalar characterization itself is exact for every parameter in its declared domain.

The exact uniform equality is separately proved in `m3_no_advantage.md` by a symbolic Bernstein sign certificate. It is not inferred from these finite numerical brackets.
