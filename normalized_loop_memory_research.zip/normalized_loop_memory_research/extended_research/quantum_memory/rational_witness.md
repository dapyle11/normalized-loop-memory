# Exact rational four-message quantum-memory advantage

AI-generated mathematical proof note. Verification described here is computational and AI-assisted, not independent human peer review. No novelty or physical-device claim is made.

This is an achievable construction, not a global optimum theorem. The comparison uses the already proved exact classical M4 bound in `../noisy_memory/four_message.md`. The physical scenario is the stipulated hypothetical P-CTC contraction; it does not assert operational time travel. There is no retained side register, shared randomness, or entanglement.

## Model and family

Let the backward channel be BSC(p), with A=1-p. The one-qubit forward channel is

L_epsilon(T)=(1-epsilon)T+epsilon Tr(T)I/2.

For a fixed basis, its classical embedding is BSC(q) with q=epsilon/2. Labels are 0,1,+,-. The future encoder chooses binary POVMs with

E_0^0=I, E_0^1=0, E_0^±=[I±n_x sigma_x+n_z sigma_z]/2,

and E_1^m=I-E_0^m. Here n_x²+n_z²=1, n_x,n_z≥0.

The decoder's subnormalized states are

τ_(0,0)=x|1><1|, τ_(1,1)=x|0><0|, τ_(0,1)=τ_(1,0)=0,

τ_(±,b)=(1-x)[I±(-1)^b sigma_x]/4.

Each b row has total trace 1; every matrix is positive semidefinite. These maps are physically valid prepare-and-measure operations independent of the hypothetical backward contraction. In particular the decoder discards its classical b and label y after producing the single designated forward qubit; y is the earlier declared output, not an extra retained input available to the encoder.

Writing k=(1-2p)(1-epsilon), direct contraction gives constant-message denominators 1, constant successes Ax, and identical projective-message denominators

Z_±=1-k n_z x,

with identical projective-message successes

S_±=(1-x)(1+k n_x)/[2(1-k n_z x)].

The projectors E_0^+ and E_0^- do not commute when n_x n_z≠0. The signal preparations include both z-axis and x-axis states. Thus this is not a classical basis-diagonal encoding in disguise.

## Main noisy example: entirely rational

Set p=1/10, epsilon=1/10 (hence classical comparison q=1/20), x=8/15, n_x=3/5, n_z=4/5. The two nontrivial effects are

E_0^+=[[9,3],[3,1]]/10,
E_0^-=[[9,-3],[-3,1]]/10.

The nonzero decoder states are

τ_(0,0)=diag(0,8/15), τ_(1,1)=diag(8/15,0),
τ_(+,0)=τ_(-,1)=7[[1,1],[1,1]]/60,
τ_(-,0)=τ_(+,1)=7[[1,-1],[-1,1]]/60.

The four normalized successes are exactly

(12/25, 12/25, 1253/2598, 1253/2598).

Hence the worst-case success is **12/25=0.48**. The exact classical four-message optimum is strictly below 9/19≈0.473684 for p=1/10 and all q in the improvement phase, and at most A/2 outside it. Therefore this witness already proves strict quantum advantage without a numerical classical computation. At the specific matched noise q=1/20, the exact classical value is approximately 0.4620623076.

## Rigorous interval of noisy-memory advantage

Keep **the same fixed matrices** in the main example while varying epsilon. The projector success is strictly increasing in k because its derivative has the sign of n_x+n_z x>0. Solving S_proj≥12/25 gives k≥925/1293. With p=1/10 this is exactly

**0≤epsilon≤547/5172≈0.105762**.

Throughout this entire interval the worst-case success is exactly 12/25=.48, since the constant messages fix that value. For every matched classical q=epsilon/2 the exact classical theorem bounds its optimum strictly below 9/19<12/25. Therefore this is an analytically certified interval of strict quantum-memory advantage, including nonzero depolarizing noise, with no reoptimization or shared resource. The simpler interval [0,1/10] is an immediate subset.

## Additional exact examples

| epsilon | q | x | (n_x,n_z) | quantum worst success | classical optimum |
|---|---|---|---|---|---|
| 0 | 0 | 9/16 | (3/5,4/5) | 259/512 = .505859375 | .4653307872 |
| 1/10 | 1/20 | 8/15 | (3/5,4/5) | 12/25 = .48 | .4620623076 |
| 1/5 | 1/10 | 23/45 | (20/29,21/29) | 23/50 = .46 | .4588195769 |

For the last example the exact classical root polynomial

F(t)=(A-(A+1)t)[r-(r-s)t]-2Aps t,

where s=p+q-2pq and r=1-s, evaluates at t=23/50 to -387/312500. On the relevant interval [A/2,A/(A+1)], its first product has two nonnegative decreasing factors and the subtracted term strictly increases; thus F is strictly decreasing, proving the classical root is below 23/50.

`rational_witness_verify.py` computes the full matrix contraction in exact SymPy arithmetic, checks every effect and subnormalized state's PSD through principal minors, checks POVM complements and trace normalizations, and writes `rational_witness_certificates.json`. The verifier does not rely on the family formula or a nonlinear optimizer for the displayed probabilities. It also evaluates F exactly. All three certificates passed.

## Symmetric continuous family for further search

More generally replace the projective-label decoder states by

τ_(±,b)=(1-x)[I+(-1)^b(±sin(phi) sigma_x+cos(phi) sigma_z)]/4,

and choose n_x=sin(theta), n_z=cos(theta). Then

S_const=Ax,
S_proj=(1-x)[1+k cos(theta-phi)]/{2[1+k cos(theta)(-x+(1-x)cos(phi))]}.

A bounded three-variable numerical optimization at p=.1, epsilon=0 obtains .5060544271 with x=.5622827, theta=.6555173, phi=1.5865430. This is a numerical candidate within a restricted family, not a certified global quantum optimum or an exact matrix-feasibility certificate. The exact witnesses above establish advantage regardless of the status of this optimization.

Novelty is not verified. Separate complete results establish M3 quantum/classical equality in `m3_no_advantage.md`, the general-noise M4 scalar characterization in `general_scalar_bound.md`, and the closed algebraic M4 optimum at p=1/10, epsilon=0 in `global_quantum_optimum.md`. The rational witnesses here remain useful simpler explicit protocols. None of those global conclusions follows from the numerical search in this section.
