# Three messages: no quantum-memory advantage at any allowed noise

AI-generated mathematical proof note. Verification described here is computational and AI-assisted, not independent human peer review. No novelty or physical-device claim is made.

**Exact theorem; independently audited.** In the README one-use model, for every 0<p<1/2 and 0≤epsilon≤1, the global worst-case success with one forward qubit equals the exact one-forward-classical-bit optimum at q=epsilon/2.

Put A=1−p, a=[1+(1−2p)(1−epsilon)]/2. The common value K is the smaller root of

    (2a−1)K²−a(A+1)K+Aa=0,

or, stably,

    K=2Aa/[a(A+1)+sqrt(a²(A+1)²−4Aa(2a−1))].

This theorem concerns M=3; the audited M4 construction still gives strict quantum advantage. There is no claim of scientific priority or physically realizable backward signalling.

## Reduction and encoder classes

The exact decoder reduction, encoder extremality, and scalar cap argument are proved in `m3_scalar_bound.md` and `general_scalar_bound.md`. Write h=a−1/2. When h=0 the memory is erased and the classical theorem gives K=A/(A+1), so suppose h>0. Then 1/2<a≤A<1.

Every encoder can be taken to be a constant binary effect or a rank-one projector. With at most one projector all effects commute, and dephasing the preparations realizes exactly the classical model; those protocols have success at most K.

The commuting construction in `m3_scalar_bound.md` gives

    K≥L=2Aa/(2A+a)≥2a/3.

For any proposed threshold t>K, the remaining N=2 or N=3 projector classes satisfy the necessary scalar inequality

    P_N(r,t)=t(Nt−2)r²+2tCr+NT²−N(t−T/2)²/h² ≥0,
    0≤r≤2,  C=(3−N)t/A, T=(2−C)/N.               (1)

The stronger r_min restriction may safely be dropped for an upper bound.

## Three-projector class

Here C=0 and T=2/3. For t>2a/3, P_N(0,t)<0. If t≤2/3, its quadratic coefficient is nonpositive and this is already its maximum over r≥0. If t>2/3, its maximum over [0,2] is at an endpoint. The other endpoint satisfies the general identity

    P_N(2,t)=N(4−1/h²)(t−T/2)²<0.                (2)

Thus every all-projector protocol has success at most 2a/3≤K.

## Two-projector class: exact sign certificate

Evaluate (1) at t=K, with C=t/A and T=1−t/(2A). Its leading coefficient is 2t(t−1)<0. Its unconstrained maximum and vertex are

    Q=2[T²−(t−T/2)²/h²]+tC²/[2(1−t)],
    r_vertex=C/[2(1−t)].

Introduce the exact variables

    v=t/[A(1−t)],  w=pv(v+1).

The classical root equation gives

    t=Av/(1+Av),  a=Av²/[v²+1−w],  r_vertex=v/2.

Since a>1/2 and a≤A, respectively, v>1 and 0<w≤1. If v>4, the vertex lies above r=2, so the constrained maximum is the strictly negative endpoint (2).

For 1<v≤4, direct algebra yields

    Q=Av H(p,v)/[2(v−1)²(1+Av)^4],

where

    H=16p³v⁴+p²v⁶−10p²v⁵−15p²v⁴−24p²v³+16p²v²
      −2pv⁶+18pv⁵−10pv⁴+14pv³+32pv²−32pv
      +v⁶−8v⁵+14v⁴−20v³+17v²−24v+16.

Substitute p=w/[v(v+1)]. The resulting expression is R(v,w)/(v+1)³. Set v=1+3x, so 0<x≤1 and 0<w≤1. The polynomial R(1+3x,w) has tensor Bernstein degree (9,3), and **all 40 Bernstein coefficients are nonpositive**. Its entire last row is strictly negative:

    (−200000, −544000/3, −163840, −147456).

Bernstein basis functions are nonnegative on the unit square. The last row contributes x⁹ times a strictly negative convex combination, while all other rows contribute nonpositive values. Hence R<0 for every x>0, including w=1 and x=1. Consequently H<0 and Q<0 throughout the remaining physical parameter domain.

Thus max_{r∈[0,2]}P_2(r,K)<0 in every case. A protocol with success strictly above K would satisfy (1) at every sufficiently close threshold t>K. Letting t decrease to K, continuity of the maximum of this quadratic on the fixed compact interval [0,2] would force its maximum at K to be nonnegative, a contradiction.

All encoder classes are now excluded above K, and the known classical protocol attains K. This proves the theorem globally, including arbitrary local stochastic choices, without a numerical optimizer.

## Exact reproducibility

`m3_no_advantage_verify.py` derives H directly from the quadratic maximum and classical-root substitution, checks the parameter identities and endpoint identity, computes every Bernstein coefficient in exact SymPy rational arithmetic, and reconstructs the polynomial from its Bernstein expansion exactly. It writes `m3_no_advantage_certificate.json`, including the full 10-by-4 coefficient table. No floating-point signs, numerical optimization, or sampling establish this result.

The preceding `m3_scalar_bound.md` and rational oracle remain valid. Their earlier statement that uniform equality was unproved is superseded by this exact Bernstein certificate, as independently verified by `m3_no_advantage_independent_verify.py` and its certificate.
