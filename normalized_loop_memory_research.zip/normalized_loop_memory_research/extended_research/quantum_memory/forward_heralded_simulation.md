# Ordinary forward, late-heralded simulation and resource ledger

AI-generated mathematical proof note. Verification described here is computational and AI-assisted, not independent human peer review. No novelty or physical-device claim is made.

This is standard rejection sampling of the stipulated normalized contraction, **not a new physical communication mechanism**. It supplies an ordinary forward laboratory simulation of the selected statistics, not an implementation of a backward channel.

## Procedure
1. Before the later message m is chosen, a simulator samples b uniformly from {0,1}.
2. The early decoder samples y with probability Tr τ_yb and prepares τ_yb/Tr τ_yb (zero-probability branches are omitted). It records y locally and sends only the designated qubit through L_epsilon.
3. The later message m is selected independently of the earlier random variables. The future encoder applies {E_a^m}, obtaining a.
4. A **later trusted heralding verifier**, not the encoder, has b and a. It accepts with probability N_p(b|a)/A, where A=1-p. Equivalently, matching bits are always accepted and mismatches are accepted with probability p/A. The flag is generated only now.

The unconditioned joint probability before the acceptance coin is

P(y,b,a|m)=1/2 Tr[E_a^m L_epsilon(τ_yb)].

Therefore

P(y,accept|m)=w_m(y)/(2A),
P(accept|m)=Z_m/(2A),
P(y|m,accept)=w_m(y)/Z_m.

This exactly reproduces the stipulated loop-model distribution **after conditioning on the late flag**. Since 2p≤Z_m≤2A, acceptance is between p/A and 1. There is no zero-success-probability singularity for p>0.

## Why this sends nothing into the past
Summing over all outcomes of the later complete POVM, without selecting successes, gives

P_early(y|m)=1/2 Σ_b Tr τ_yb,

which is independent of m. Failed trials must remain in this full earlier record. A later choice of m or a cannot make the accepted subset available to the past: identifying it requires the later flag (and, for message-conditioned analysis, the later message labels). The earlier observer cannot condition on a flag not yet produced. Consequently selected statistical dependence is not earlier access to the future message.

## Explicit resource ledger
- Protocol resource: one forward qubit through L_epsilon (or, for the fair classical comparator, one forward bit through BSC(epsilon/2)). The encoder sees m and this system only.
- Early output: classical y, stored as the laboratory outcome record, never exposed to the future encoder.
- Simulator/heralding apparatus: an initial random bit b, **retained privately by a trusted later verifier**, a future output a supplied to that verifier, and private randomness for the acceptance coin. Retaining b is an additional simulator-side bookkeeping resource; it is **not** free side memory available to the protocol encoder. If the encoder could inspect this register, the original resource restriction would be violated.
- Analysis resources: later acceptance flags and trial identifiers must eventually be communicated forward to combine records and select the accepted data. These are not available at the earlier decoding time. No shared seed or entanglement is provided to decoder and encoder.
- The same simulator/heralding resources, rejection rule, late postselection, and excluded encoder access must be used in the classical comparator. Otherwise the comparison is not the declared dimension-matched task.

Thus an ordinary laboratory experiment could compare quantum and classical *late-conditioned* success under these restrictions. It would need to report acceptance rates and all failed trials, and would demonstrate a conditional prepare-and-measure advantage, not retrocausal signalling. No hardware implementation or experimental validation was performed here.

## Acceptance rates for the rational witnesses
All canonical examples have p=1/10, so 2A=9/5. Constant-message denominators are 1, hence acceptance 5/9. The two projective-message denominators coincide:

| epsilon | x | projective Z | projective acceptance Z/(2A) | constant acceptance |
|---|---|---|---|---|
|0|9/16|16/25|16/45 ≈ .355556|5/9|
|1/10|8/15|433/625|433/1125 ≈ .384889|5/9|
|1/5|23/45|8299/10875|8299/19575 ≈ .423959|5/9|

For the fixed interval witness x=8/15,n_z=4/5, projective acceptance is

(5/9)[1−(32/75)k],  k=(4/5)(1−epsilon).

At epsilon=0 it is 247/675; at epsilon=547/5172 it is 13475/34911. These endpoints concern the fixed x=8/15 family, not the different x=9/16 noise-free optimized witness.
