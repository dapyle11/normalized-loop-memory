"""Check saved M3/M4 scalar certificates using a separate exact code path.

This verifies arithmetic and algebraic witness specifications, not the theorem
by numerical sampling. Its mathematical premise is general_scalar_bound.md.
Only Python's standard library is used; do not run Python with -O.
"""
from fractions import Fraction as F
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent


def classical(p, e, t, m=4):
    A, q = 1-p, e/2
    if m == 3:
        a = F(1, 2)+(1-2*p)*(1-e)/2
        if t <= A/(A+1):
            return True
        return t <= A and (2*a-1)*t*t-a*(A+1)*t+A*a >= 0
    if t <= A/2:
        return True
    if q >= A/(2*(A+1)) or t > A/(A+1):
        return False
    s = p+q-2*p*q
    return (A-(A+1)*t)*(1-s-(1-2*s)*t) >= 2*A*p*s*t


def scalar_cases(p, e, t, m=4):
    A, h = 1-p, (1-2*p)*(1-e)/2
    if not h:
        return {}
    out = {}
    for n in range(2, m+1):
        C = (m-n)*t/A
        T = (2-C)/n
        lower = (1-(F(1, 2)+h)*T/t)/h
        if lower > 2:
            out[n] = None
            continue
        assert lower > 0
        coeff = (t*(n*t-2), 2*t*C,
                 n*(T*T-(t-T/2)**2/(h*h)))
        def polynomial(x):
            return (coeff[0]*x+coeff[1])*x+coeff[2]
        points = [lower, F(2)]
        if coeff[0] < 0:
            v = -coeff[1]/(2*coeff[0])
            if lower <= v <= 2:
                points.append(v)
        out[n] = max(map(polynomial, points))
    return out


def decision(p, e, t, m=4):
    A = 1-p
    if m == 4 and t <= A/2:
        return True
    if t > A/(A+(m-1)*p):
        return False
    return classical(p, e, t, m) or any(
        x is not None and x >= 0 for x in scalar_cases(p, e, t, m).values())


def witness(p, e, t, data):
    n = data['N']
    C = sum(map(F, data['constant_traces']))
    us = list(map(F, data['constant_u']))
    T, u, z, B, r = (F(data[key]) for key in (
        'projector_trace', 'projector_u', 'projector_z',
        'constant_aggregate_z', 'r'))
    A, h = 1-p, (1-2*p)*(1-e)/2
    assert n in (2, 3, 4) and 0 < r <= 2
    assert C == (4-n)*t/A and C+n*T == 2
    assert sum(us)+n*u == 0 and abs(u) <= T
    assert -C <= B <= C and B+n*z == r
    assert -T <= z <= T
    assert T*T-z*z == F(data['projector_transverse_squared']) >= 0
    norm = T*T-2*t*r*z+t*t*r*r
    assert norm == F(data['encoder_direction_norm_squared']) > 0
    # Positive RHS makes this squaring equivalent to the encoder threshold.
    assert t-T/2 > 0
    margin = norm-(t-T/2)**2/(h*h)
    assert margin == F(data['squared_threshold_margin']) >= 0
    traces = list(map(F, data['constant_traces']))
    assert len(traces) == len(us) == 4-n
    for trace, uu in zip(traces, us):
        assert abs(uu) <= trace
        assert trace/2+(A-F(1, 2))*abs(uu) == t
        assert C > 0 and abs(trace*B/C) <= trace
    # The exact decoder reconstruction has row traces (sum T +/- sum u)/2=1,
    # and Bloch norm <= trace. Regular polygons cancel transverse components.
    assert (C+n*T+sum(us)+n*u)/2 == 1
    assert (C+n*T-sum(us)-n*u)/2 == 1


def main():
    rows = json.loads((ROOT/'general_scalar_certificates.json').read_text())
    largest = F(0)
    witnesses = 0
    for row in rows:
        p, e, lo, hi = (F(row[k]) for k in ('p', 'epsilon', 'lower', 'upper'))
        assert 0 < p < F(1, 2) and 0 <= e <= 1
        assert lo < hi and hi-lo == F(row['width']) < F(4, 10**22)
        assert decision(p, e, lo) and not decision(p, e, hi)
        assert classical(p, e, lo) == row['lower_uses_classical']
        upper = scalar_cases(p, e, hi)
        for test in row['upper_quantum_tests']:
            val = upper[test['N']]
            assert test['feasible'] == (val is not None and val >= 0)
            if val is not None:
                assert val == F(test['P_max'])
        if row['lower_quantum_witness'] is not None:
            witness(p, e, lo, row['lower_quantum_witness'])
            witnesses += 1
        else:
            assert classical(p, e, lo)
        if p == F(1, 10) and e == 0:
            def cubic(t):
                return ((19600*t-27720)*t+10449)*t-729
            assert cubic(lo) > 0 > cubic(hi)
        largest = max(largest, hi-lo)
    print(f'PASS: {len(rows)} exact optimum brackets, {witnesses} algebraic witnesses;')
    print(f'maximum width {largest} (approximately {float(largest):.12g}).')
    rows3 = json.loads((ROOT/'m3_scalar_certificates.json').read_text())
    largest3 = F(0)
    for row in rows3:
        p, e, lo, hi = (F(row[k]) for k in ('p', 'epsilon', 'lower', 'upper'))
        assert 0 < p < F(1, 2) and 0 <= e <= 1
        assert lo < hi and hi-lo == F(row['width']) < F(5, 10**22)
        assert decision(p, e, lo, 3) and not decision(p, e, hi, 3)
        assert classical(p, e, lo, 3) == row['lower_classical_feasible']
        assert classical(p, e, hi, 3) == row['upper_classical_feasible']
        if row['upper_quantum_tests']:
            upper = scalar_cases(p, e, hi, 3)
            for test in row['upper_quantum_tests']:
                val = upper[test['N']]
                assert test['feasible'] == (val is not None and val >= 0)
                if val is not None:
                    assert val == F(test['P_max'])
        largest3 = max(largest3, hi-lo)
    print(f'PASS: {len(rows3)} exact M3 brackets; maximum width {float(largest3):.12g}.')


if __name__ == '__main__':
    main()
