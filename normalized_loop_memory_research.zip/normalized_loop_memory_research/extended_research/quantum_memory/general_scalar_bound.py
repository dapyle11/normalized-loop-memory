"""Exact rational decisions for the global four-message qubit optimum.
The characterization is proved in general_scalar_bound.md.
"""
from fractions import Fraction as F
import json
from pathlib import Path

def classical_feasible(p,eps,t):
    A=1-p;q=eps/2
    if t<=A/2:return True
    if q>=A/(2*(A+1)) or t>A/(A+1):return False
    s=p+q-2*p*q;r=1-s
    return (A-(A+1)*t)*(r-(r-s)*t)-2*A*p*s*t>=0

def quadratic_tests(p,eps,t):
    A=1-p;h=(1-2*p)*(1-eps)/2;a=F(1,2)+h
    if h==0:return []
    tests=[]
    for N in (2,3,4):
        C=(4-N)*t/A;T=(2-C)/N;lo=(1-a*T/t)/h
        if lo>2:
            tests.append({'N':N,'r_min':lo,'feasible':False});continue
        # This function is used only at t>A/2, so lo>0.
        assert lo>0
        aa=t*(N*t-2);bb=2*t*C;cc=N*T*T-N*(t-T/2)**2/(h*h)
        candidates=[lo,F(2)]
        if aa<0:
            vertex=-bb/(2*aa)
            if lo<=vertex<=2:candidates.append(vertex)
        rr=max(candidates,key=lambda r:aa*r*r+bb*r+cc)
        value=aa*rr*rr+bb*rr+cc
        tests.append({'N':N,'r_min':lo,'r_maximizer':rr,'P_max':value,'feasible':value>=0})
    return tests

def feasible(p,eps,t):
    assert 0<p<F(1,2) and 0<=eps<=1
    A=1-p
    if t<=A/2:return True
    if t>A/(A+3*p):return False
    if classical_feasible(p,eps,t):return True
    return any(v['feasible'] for v in quadratic_tests(p,eps,t))

def reduced_witness(p,eps,t,test):
    """Exact algebraic-state specification; square roots need not be rounded."""
    N=test['N'];r=test['r_maximizer'];A=1-p;h=(1-2*p)*(1-eps)/2
    C=(4-N)*t/A;T=(2-C)/N
    g=(T*T+t*t*r*r-(t-T/2)**2/(h*h))/(2*t*r)
    z=max(-T,(r-C)/N);B=r-N*z
    assert -C<=B<=C and -T<=z<=g<=T
    transverse_squared=T*T-z*z
    norm_squared=T*T-2*t*r*z+t*t*r*r
    threshold_margin=norm_squared-(t-T/2)**2/(h*h)
    assert transverse_squared>=0 and threshold_margin>=0
    if N==2:constant_traces=[C/2,C/2];constant_u=[C/2,-C/2];projector_u=F(0)
    elif N==3:constant_traces=[C];constant_u=[C];projector_u=-C/N
    else:constant_traces=[];constant_u=[];projector_u=F(0)
    assert abs(projector_u)<=T and sum(constant_u)+N*projector_u==0
    return {'N':N,'r':r,'constant_aggregate_z':B,'constant_traces':constant_traces,'constant_u':constant_u,'projector_trace':T,'projector_u':projector_u,'projector_z':z,'projector_transverse_squared':transverse_squared,'encoder_direction_norm_squared':norm_squared,'squared_threshold_margin':threshold_margin,'construction':'Regular N-gon transverse vectors of indicated squared length; constant d_z=trace*B/C. Encoder n=(d-t*r*zhat)/sqrt(norm_squared). Decoder t_b=(T+(-1)^b*u)/2, v_b=(-1)^b*t_b*d/T.'}

def bracket(p,eps,steps=70):
    A=1-p;lo=A/2;U=A/(A+3*p);hi=(1+U)/2
    assert feasible(p,eps,lo)
    # hi>U is strictly infeasible; this also covers a hypothetically attainable U.
    for _ in range(steps):
        mid=(lo+hi)/2
        if feasible(p,eps,mid):lo=mid
        else:hi=mid
    assert feasible(p,eps,lo) and not feasible(p,eps,hi)
    tests=[v for v in quadratic_tests(p,eps,lo) if v['feasible']] if lo>A/2 else []
    active=[v['N'] for v in tests]
    witness=reduced_witness(p,eps,lo,tests[0]) if tests else None
    return {'p':str(p),'epsilon':str(eps),'lower':str(lo),'upper':str(hi),'illustrative_midpoint':float((lo+hi)/2),'width':str(hi-lo),'lower_uses_classical':classical_feasible(p,eps,lo),'lower_feasible_projector_counts':active,'lower_quantum_witness':witness,'upper_exceeds_universal_bound':hi>U,'upper_classical_feasible':classical_feasible(p,eps,hi),'upper_quantum_tests':quadratic_tests(p,eps,hi)}

if __name__=='__main__':
    cases=[(F(1,10),F(0)),(F(1,10),F(1,10)),(F(1,10),F(1,5)),(F(1,10),F(3,5)),(F(1,10),F(1)),(F(1,4),F(0)),(F(1,4),F(2,5))]
    out=[bracket(p,e) for p,e in cases]
    dest=Path(__file__).with_name('general_scalar_certificates.json')
    dest.write_text(json.dumps(out,indent=2,default=str)+'\n')
    for row in out:print(row['p'],row['epsilon'],format(row['illustrative_midpoint'],'.15f'),row['lower_uses_classical'],row['lower_feasible_projector_counts'])
    print('All decisions use Fraction arithmetic; exact brackets saved to',dest)
