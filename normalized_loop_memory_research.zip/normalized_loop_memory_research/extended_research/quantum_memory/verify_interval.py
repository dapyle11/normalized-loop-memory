"""Exact symbolic certificate for one fixed noisy-qubit advantage interval."""
import sympy as S
import json
from pathlib import Path
R=S.Rational
k=S.symbols('k', nonnegative=True)
x=R(8,15);nx=R(3,5);nz=R(4,5)
f=(1-x)*(1+k*nx)/(2*(1-k*nz*x))
threshold=R(925,1293);epsilon_max=R(547,5172)
assert S.factor(f-R(12,25))==S.factor((1293*k-925)/(50*(75-32*k)))
assert S.simplify(f.subs(k,threshold)-R(12,25))==0
assert S.simplify(R(4,5)*(1-epsilon_max)-threshold)==0
# Positive derivative and denominator throughout physically relevant k in [0,4/5].
assert S.factor(S.diff(f,k))==R(2695,1)/(2*(32*k-75)**2)
assert 75-32*R(4,5)>0
assert R(9,19)<R(12,25)
report={'epsilon_interval':['0',str(epsilon_max)],'fixed_quantum_success':'12/25','strict_classical_upper_bound':'9/19','classical_upper_bound_source':'../noisy_memory/four_message.md','verified':True}
Path(__file__).with_name('interval_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
