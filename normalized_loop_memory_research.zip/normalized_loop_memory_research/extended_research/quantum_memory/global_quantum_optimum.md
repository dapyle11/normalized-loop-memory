# Global M4 optimum at p=1/10, epsilon=0: algebraic certificate

AI-generated mathematical proof note. Verification described here is computational and AI-assisted, not independent human peer review. No novelty or physical-device claim is made.

**Exact result; independently proof-audited:** the global optimum in the exact operational model of README.md equals the unique root in (1/2,51/100) of

    f(s)=19600 s^3−27720 s^2+10449 s−729,

namely s*=0.506054427104891… . This is not inferred from optimizer convergence. Below is a global upper bound and matching algebraic construction. No external literature or novelty claim is used.

## 1. Exact reduced variables and encoder extremality

In this standalone proof, s denotes a success threshold and r the aggregate Bloch-vector norm, not the classical-channel symbols used in other files. The first index of τ_mb labels the decoder's earlier guessed output; it is not access to the future true message.

Write τ_mb=(t_mb I+v_mb·σ)/2. Put T_m=t_m0+t_m1, u_m=t_m0−t_m1, d_m=v_m0−v_m1, and D=Σ_m d_m. The decoder constraints imply

    ΣT_m=2, Σu_m=0, |u_m|≤T_m, |d_m|≤T_m.

Conversely these conditions are sufficient: set t_m0=(T_m+u_m)/2, t_m1=(T_m−u_m)/2, v_m0=t_m0 d_m/T_m, v_m1=−t_m1 d_m/T_m, with zero states if T_m=0.

For each fixed decoder the success ratio is linear-fractional in its binary effect, with strictly positive denominator. Its value at a convex combination is a denominator-weighted mean of component values. Hence an extreme binary effect can independently be chosen for every message: E0=I, E0=0, or E0=(I+n·σ)/2 with |n|=1. This does not require simultaneous optimization or convexity of the joint problem.

Constants have denominator 1 and numerator T/2±(2/5)u. A projector has numerator T/2+(2/5)n·d and denominator 1+(2/5)n·D. Thus it reaches threshold s iff

    T/2+(2/5)|d−sD|≥s.                       (1)

A repeated constant effect has sum of its messages' successes at most 1. Consequently any protocol with worst success >1/2 has at most one of each constant type. There are k=2,3,4 projectors.

## 2. One-dimensional concave bound

Let r=|D|≤2, rotate D=r zhat, and write z=d·zhat. At r=0 every message success is at most (9/10)T, including constants, so the worst success is at most 9/20. Hence take r>0.

For a projector (1) and |d|≤T imply T≥L, where

    L=s(1−2r/5)/(9/10),  H=s(1+2r/5)/(9/10).

For T∈[L,H], necessarily T≤H≤2s, so squaring (1) is legitimate. It yields z≤g(T), where

    g(T)=[T²+s²r²−(25/4)(s−T/2)²]/(2sr).

For T≥H use z≤g(T)=T. These pieces give the exact maximal permitted z: the first piece is attainable by |d|=T, and the second by d=T zhat. In the first piece g is concave, g(L)=−L and g(H)=H. Its second derivative is −9/(16sr), and its derivative at H is 1+5(2−r)/(4r)≥1 (equality only at r=2), so the piecewise function is concave everywhere on [L,∞), with derivative ≥1. The first-piece derivative decreases, and switching at H to slope 1 preserves concavity.

Let C be the total trace allocated to the 4−k constant messages. Their threshold requires C≥C0=(4−k)s/(9/10). Their total z is at most C. Jensen therefore gives

    r≤C+k g((2−C)/k)≤C0+k g((2−C0)/k).       (2)

The second inequality follows from g having slope at least 1. If a feasible C exists, the average projector trace is ≥L; decreasing C to C0 keeps the average in the domain. For s≥1/2 and k=2,3,4, T=(2−C0)/k≤1/2<H, so (2) uses the quadratic branch whenever feasible. Rearranging gives the necessary inequality

    P_k(r,s)=s(ks−2)r²+2sC0r+kT²−(25k/4)(s−T/2)² ≥0.   (3)

This is a relaxation: transverse closure was dropped. It still supplies an upper bound.

## 3. Excluding all larger successes

To exclude k=3 and k=4 protocols above 1/2, test feasibility at s=1/2 (any better protocol also reaches this threshold). For k=3 the quadratic in (3) is concave and its unconstrained maximum over r is −83/324. For k=4 it is the negative constant −9/16. Thus neither case can attain even 1/2.

For k=2 and 1/2<s<51/100, the quadratic is strictly concave, with maximum at

    r*=10s/[9(1−s)] ∈(0,2),
    max_r P_2(r,s)= f(s)/[648(1−s)].

The polynomial f is strictly decreasing on [1/2,51/100] (f″>0 there and f′(51/100)<0), with f(1/2)=31/2>0 and f(51/100)=−6264/625<0. Therefore there is a unique s* in that interval, and every threshold in (s*,51/100) is impossible. Threshold feasibility is downward closed, which also excludes every success ≥51/100. This establishes the global bound s≤s*.

## 4. Matching decoder and encoder

All quantities below are exact real algebraic numbers defined by the root s*. Set

    x=10s*/9, T=1−x, r=10s*/[9(1−s*)], z=(r−2x)/2,
    a=sqrt(T²−z²).

Take four labels 0,1,+,− with reduced variables

    (T_0,u_0,d_0)=(x,x,x zhat),
    (T_1,u_1,d_1)=(x,−x,x zhat),
    (T_±,u_±,d_±)=(T,0,(±a,0,z)).

Then ΣT=2, Σu=0, D=r zhat, and every |d_m|=T_m. The construction in Section 1 gives valid rank-one or zero decoder states. For labels 0,1 choose E0=I,0 respectively. Their success is (9/10)x=s*. For labels ± choose

    n_±=(d_±−s*D)/|d_±−s*D|.

The identity f(s*)=0 is precisely P_2(r,s*)=0, so z=g(T), hence

    |d_±−s*D|=(5/2)(s*−T/2).

Equation (1) is equality, proving both projective successes are exactly s*. Here 0<z<T and all denominators are positive (universally ≥1/5). Thus the upper bound is attained without a shared seed or side register.

## 5. Certificate and limits

`global_bound_verify.py` verifies the polynomial reductions, endpoint signs, derivative sign, k=3/4 exclusions, concavity identities, and exact matching-construction identity using SymPy. It does not use floating-point search as proof. The result is specific to p=1/10, epsilon=0, M=4. No general-noise optimum or scientific-priority claim is implied.
