"""Exact symbolic checks for the p=.1, eps=0, M4 global optimum theorem."""
import sympy as S
import json
from pathlib import Path
s,r,t=S.symbols('s r t', positive=True)
A=S.Rational(9,10)
f=19600*s**3-27720*s**2+10449*s-729
L=s*(1-S.Rational(2,5)*r)/A
H=s*(1+S.Rational(2,5)*r)/A
g=(t*t+s*s*r*r-S.Rational(25,4)*(s-t/2)**2)/(2*s*r)
assert S.simplify(g.subs(t,L)+L)==0
assert S.simplify(g.subs(t,H)-H)==0
assert S.simplify(S.diff(g,t,2)+S.Rational(9,16)/(s*r))==0
assert S.simplify(S.diff(g,t).subs(t,H)-1-5*(2-r)/(4*r))==0
P={}
for k in (2,3,4):
 C=(4-k)*s/A; T=(2-C)/k
 P[k]=S.factor(s*(k*s-2)*r*r+2*s*C*r+k*T*T-S.Rational(25,4)*k*(s-T/2)**2)
 assert S.simplify(2*s*r*(C+k*g.subs(t,T)-r)-P[k])==0
rstar=10*s/(9*(1-s))
assert S.simplify(S.diff(P[2],r).subs(r,rstar))==0
assert S.simplify(P[2].subs(r,rstar)-f/(648*(1-s)))==0
P3=S.factor(P[3].subs(s,S.Rational(1,2)))
r3=S.solve(S.diff(P3,r),r)[0]
assert P3.subs(r,r3)==-S.Rational(83,324)
assert P[4].subs(s,S.Rational(1,2))==-S.Rational(9,16)
lo=S.Rational(1,2); hi=S.Rational(51,100)
assert f.subs(s,lo)>0 and f.subs(s,hi)<0
# f''>0 throughout this interval, and f'(hi)<0.
assert S.diff(f,s,2).subs(s,lo)>0 and S.diff(f,s).subs(s,hi)<0
x=s/A; T=1-x; z=(rstar-2*x)/2
norm_squared=S.factor(T*T-2*s*rstar*z+s*s*rstar*rstar)
identity=S.factor(norm_squared-S.Rational(25,4)*(s-T/2)**2)
assert S.simplify(identity/f-1/(1296*(1-s)))==0
# On the isolating interval, z>0 and z<T: z=5s*(2s-1)/(9(1-s)).
assert S.simplify(z-5*s*(2*s-1)/(9*(1-s)))==0
assert S.simplify(T-z-(9-14*s)/(9*(1-s)))==0
assert 9-14*hi>0
# Exact rational root isolation, rather than nroots, establishes existence/uniqueness.
intervals=S.polys.polytools.intervals(f,eps=S.Rational(1,10**25))
selected=[(ab,m) for ab,m in intervals if lo<ab[0]<ab[1]<hi]
assert len(selected)==1 and selected[0][1]==1
root_interval=selected[0][0]
result={"status":"symbolic identities and rational interval checks passed", "polynomial":str(f),"root_isolating_interval":[str(q) for q in root_interval],"decimal_illustration":str(S.N(sum(root_interval)/2,18)),"k3_max_at_half":str(P3.subs(r,r3)),"k4_at_half":str(P[4].subs(s,lo)),"f_half":str(f.subs(s,lo)),"f_51_over_100":str(f.subs(s,hi)),"construction_identity":str(identity)}
Path(__file__).with_name('global_bound_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
