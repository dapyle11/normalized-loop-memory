"""Exact M3 threshold oracle; see m3_scalar_bound.md for proof and limits."""
from fractions import Fraction as F
import json
from pathlib import Path

def classical_feasible(p,eps,t):
 A=1-p;a=F(1,2)+(1-2*p)*(1-eps)/2
 if t<=A/(A+1):return True
 if t>A:return False
 return (2*a-1)*t*t-a*(A+1)*t+A*a>=0

def tests(p,eps,t):
 A=1-p;h=(1-2*p)*(1-eps)/2;a=F(1,2)+h
 if h==0:return []
 out=[]
 for N in (2,3):
  C=(3-N)*t/A;T=(2-C)/N;lo=(1-a*T/t)/h
  assert lo>0 # called only above the exact classical optimum
  if lo>2:out.append({'N':N,'r_min':lo,'feasible':False});continue
  aa=t*(N*t-2);bb=2*t*C;cc=N*T*T-N*(t-T/2)**2/h**2
  candidates=[lo,F(2)]
  if aa<0 and lo<=-bb/(2*aa)<=2:candidates.append(-bb/(2*aa))
  r=max(candidates,key=lambda r:aa*r*r+bb*r+cc);v=aa*r*r+bb*r+cc
  out.append({'N':N,'r_min':lo,'r_maximizer':r,'P_max':v,'feasible':v>=0})
 return out

def feasible(p,eps,t):
 assert 0<p<F(1,2) and 0<=eps<=1
 A=1-p
 if t>A/(A+2*p):return False
 if classical_feasible(p,eps,t):return True
 return any(x['feasible'] for x in tests(p,eps,t))

def bracket(p,eps,steps=70):
 A=1-p;U=A/(A+2*p);lo=A/(A+1);hi=(1+U)/2
 for _ in range(steps):
  mid=(lo+hi)/2
  if feasible(p,eps,mid):lo=mid
  else:hi=mid
 assert feasible(p,eps,lo) and not feasible(p,eps,hi)
 return {'p':str(p),'epsilon':str(eps),'lower':str(lo),'upper':str(hi),'width':str(hi-lo),'illustrative_midpoint':float((lo+hi)/2),'lower_classical_feasible':classical_feasible(p,eps,lo),'upper_classical_feasible':classical_feasible(p,eps,hi),'upper_exceeds_universal_bound':hi>U,'upper_quantum_tests':tests(p,eps,hi) if hi<=U else [],'caution':'These interval checks alone are not the equality proof; see the separately audited m3_no_advantage.md theorem.'}

if __name__=='__main__':
 cases=[(F(1,10),F(0)),(F(1,10),F(1,5)),(F(1,10),F(3,5)),(F(1,10),F(1)),(F(1,4),F(0)),(F(1,4),F(2,5)),(F(1,100),F(0))]
 out=[bracket(p,e) for p,e in cases]
 Path(__file__).with_name('m3_scalar_certificates.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
 for x in out:print(x['p'],x['epsilon'],format(x['illustrative_midpoint'],'.15f'),x['lower_classical_feasible'])
