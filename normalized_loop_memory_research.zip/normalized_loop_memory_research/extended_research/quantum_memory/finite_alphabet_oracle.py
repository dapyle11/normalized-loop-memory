"""Complete exact finite-alphabet one-forward-qubit threshold oracle.
Only standard-library rational arithmetic; proof: finite_alphabet_theorem.md.
"""
from fractions import Fraction as F
import json
from pathlib import Path

def constant_allocation(p,n0,n1,t):
 A=1-p;d0=n0*t;d1=n1*t
 if d0>A and d1>A:return None
 if d0<=A and d1<=A:x0=d0/A;x1=F(0);y0=F(0);y1=d1/A
 elif d0>A:x0=F(1);x1=F(0);y0=(d0-A)/p;y1=d1/A
 else:x0=d0/A;x1=(d1-A)/p;y0=F(0);y1=F(1)
 if x0+x1>1 or y0+y1>1:return None
 assert A*x0+p*y0==d0 and p*x1+A*y1==d1
 return {'row0':[x0,x1],'row1':[y0,y1],'C':x0+x1+y0+y1}

def class_test(M,p,eps,t,n0,n1):
 N=M-n0-n1;out={'n0':n0,'n1':n1,'N':N,'feasible':False}
 alloc=constant_allocation(p,n0,n1,t)
 if alloc is None:out['reason']='constant demands infeasible';return out
 out['constant_allocation']=alloc;C=alloc['C'];h=(1-2*p)*(1-eps)/2;a=F(1,2)+h
 if N==0:out.update(feasible=True,reason='constant rows can be filled');return out
 T=(2-C)/N
 out['projector_trace']=T
 out['projector_u']=(alloc['row1'][0]+alloc['row1'][1]-alloc['row0'][0]-alloc['row0'][1])/N
 assert abs(out['projector_u'])<=T
 if N==1:
  margin=T/2+h*((1-t)*T+t*C)-t
  out.update(feasible=margin>=0,reason='one-projector triangle bound',margin=margin,constant_aggregate_z=-C,projector_z=T)
  return out
 if a*T>=t:
  out.update(feasible=True,reason='zero-total-Bloch polygon construction',r=F(0),constant_aggregate_z=F(0),projector_z=F(0),projector_transverse_squared=T*T)
  return out
 if h==0:out['reason']='erased-memory projector trace insufficient';return out
 lo=(1-a*T/t)/h
 assert lo>0
 out['r_min']=lo
 if lo>2:out['reason']='empty Bloch-radius interval';return out
 aa=t*(N*t-2);bb=2*t*C;cc=N*T*T-N*(t-T/2)**2/h**2
 candidates=[lo,F(2)]
 if aa<0 and lo<=-bb/(2*aa)<=2:candidates.append(-bb/(2*aa))
 r=max(candidates,key=lambda r:aa*r*r+bb*r+cc);v=aa*r*r+bb*r+cc
 out.update(feasible=v>=0,reason='exact quadratic maximum',r=r,P_max=v)
 if v>=0:
  g=(T*T+t*t*r*r-(t-T/2)**2/h**2)/(2*t*r)
  z=max(-T,(r-C)/N);B=r-N*z
  assert -C<=B<=C and -T<=z<=g<=T
  norm2=T*T-2*t*r*z+t*t*r*r
  assert norm2>0 and norm2>=(t-T/2)**2/h**2
  out.update(constant_aggregate_z=B,projector_z=z,projector_transverse_squared=T*T-z*z,encoder_direction_norm_squared=norm2)
 return out

def decision(M,p,eps,t,all_classes=False):
 assert isinstance(M,int) and M>=1 and 0<p<F(1,2) and 0<=eps<=1
 p=F(p);eps=F(eps);t=F(t)
 if t<=0:return {'feasible':True,'reason':'nonpositive threshold'}
 if t>1:return {'feasible':False,'reason':'probability exceeds one'}
 cases=[]
 for n0 in range(M+1):
  for n1 in range(M-n0+1):
   c=class_test(M,p,eps,t,n0,n1);cases.append(c)
   if c['feasible'] and not all_classes:return {'feasible':True,'witness':c}
 return {'feasible':any(c['feasible'] for c in cases),'classes':cases}

def erased_value(M,p):
 A=1-p;k=M//2
 return A/k if M%2==0 else A/(k+A)

def bracket(M,p,eps,steps=60):
 if M==1:return {'M':M,'p':str(p),'epsilon':str(eps),'exact':'1'}
 if eps==1:return {'M':M,'p':str(p),'epsilon':str(eps),'exact':str(erased_value(M,p))}
 A=1-p;U=A/(A+(M-1)*p);lo=F(1,M);hi=(1+U)/2
 for _ in range(steps):
  mid=(lo+hi)/2
  if decision(M,p,eps,mid)['feasible']:lo=mid
  else:hi=mid
 lower=decision(M,p,eps,lo);upper=decision(M,p,eps,hi,True)
 assert lower['feasible'] and not upper['feasible']
 return {'M':M,'p':str(p),'epsilon':str(eps),'lower':str(lo),'upper':str(hi),'width':str(hi-lo),'illustrative_midpoint':float((lo+hi)/2),'lower_certificate':lower,'upper_certificate':upper}

if __name__=='__main__':
 cases=[(M,F(1,10),F(0)) for M in range(1,9)]+[(M,F(1,10),F(1,5)) for M in (3,4,5,8)]+[(M,F(1,10),F(1)) for M in range(2,9)]
 out=[bracket(M,p,e) for M,p,e in cases]
 Path(__file__).with_name('finite_alphabet_certificates.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
 for row in out:print(row['M'],row['p'],row['epsilon'],row.get('illustrative_midpoint',row.get('exact')))
