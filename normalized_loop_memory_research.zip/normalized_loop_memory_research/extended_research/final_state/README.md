# Explicit final-state branch replication

## Result

The **conditional** earlier-marginal claim is reproduced, not refuted. The ordinary unconditioned experimental counterpart has no backward channel.

| Later choice | Earlier Bell record conditional on HA final Phi+ | HA herald success | Earlier record with all HA outcomes retained |
|---|---|---|---|
| Do nothing | (1, 0, 0, 0) | 1/4 | (1/4, 1/4, 1/4, 1/4) |
| Measure AB, discard outcome | (1/4, 1/4, 1/4, 1/4) | 1/4 | (1/4, 1/4, 1/4, 1/4) |

Order of Bell labels: Phi+, Phi−, Psi+, Psi−. Conditional total-variation distance is 3/4; unconditioned distance is zero (floating point residual 2.3e−16 or less). The same success rate in both choices does **not** eliminate postselection bias: the success flag's correlation with the earlier record changes.

## Source-to-model mapping (not a substitute protocol)

[Lloyd and Preskill, JHEP 08 (2014) 126, §§6.3–6.5](https://preskill.caltech.edu/pubs/preskill-2014-final-state.pdf) explicitly reduce their old-black-hole discussion to four qubits H,A,B,R, initial Bell pairs HR and AB, and final Phi+ projection on HA. B is late radiation, A its interior partner; R is a decoded early-radiation subsystem and H its partner. Brenda measures BR first; Abby subsequently measures AB, interacting with B outside before A inside. Their meter construction measures ZZ using a zero-initialized target and XX using a plus-initialized control. Our qubits, Bell projector, measurement order, and meter gates follow precisely this reduction. Decoding R, final-state enforcement, and survival/decoding of interior meters are assumptions, not capabilities established here.

## Independent analytic derivation

Let |beta_j> denote the four Bell states, P_j their projectors, and

    rho0 = |Phi+><Phi+|_HR tensor |Phi+><Phi+|_AB.

All operators below are embedded in wire order H,A,B,R. Brenda's outcome-j instrument is M_j(rho)=P_j^BR rho P_j^BR. Its result is copied to a classical register C at the early measurement; it is not a late inferred outcome.

Abby's later intervention is E_0=identity or E_1(rho)=sum_a P_a^AB rho P_a^AB. The latter is the **nonselective full Bell measurement**, not one selected outcome, a single-qubit measurement, or a state preparation.

Let F_k=P_k^HA, all four possible final outcomes. The joint statistics are

    p(j,a,k|1) = Tr[F_k P_a^AB P_j^BR rho0 P_j^BR P_a^AB],
    p(j,k|0)   = Tr[F_k P_j^BR rho0 P_j^BR].

Entanglement swapping gives, up to irrelevant Bell-label phases,

    P_j^BR |Psi0> = (1/2) |beta_j>_HA |beta_j>_BR.

Thus p(j,k|0)=delta_jk/4. For fixed j the Bell measurement of AB has each outcome a with probability 1/4. It leaves Bell pairs AB and HR, with labels/phases determined by j,a; tracing BR leaves HA maximally mixed. Hence every k has probability 1/4:

    p(j,a,k|1)=1/64,  p(j,k|1)=1/16.

This produces the table above. In explicit classical-quantum form, immediately after Brenda,

    rho_C,HABR = sum_j |j><j|_C tensor P_j^BR rho0 P_j^BR.

No later gate acts on C. Summing every final outcome and Abby's outcome therefore gives the same uniform C distribution. Applying only F_0 and renormalizing instead changes the probability assigned to C; treating this conditional law as the law of every run is exactly the additional final-boundary premise.

## Complete flag ledger

All final outcomes k have probability 1/4 in both choices. With no Abby measurement, the final label equals Brenda's earlier label. With Abby's measurement, the two labels are independent.

For the one-bit flag S=(k=0):

- p(S)=1/4 for either choice.
- Without Abby, p(C|not S)=(0,1/3,1/3,1/3).
- With Abby, p(C|not S)=(1/4,1/4,1/4,1/4).
- In both cases, p(C)=p(S)p(C|S)+p(not S)p(C|not S) is uniform.

An ordinary receiver needs the later success record to select the apparent signal; retaining failures removes it. No adaptive choice or message is transmitted before that flag. The fundamental HM interpretation replaces heralded conditioning with an enforced boundary and thus is not ordinary trace-preserving laboratory dynamics.

## Sequential-meter verification and meter teleportation

`replicate.py` computes the density-matrix instruments and independently an eight-qubit meter circuit. Wires are H,A,B,R,Cz,Cx,Dz,Dx. Cz,Dz begin in zero; Cx,Dx begin in plus. Chronological CNOT lists:

    Brenda: B→Cz, R→Cz, Cx→B, Cx→R.
    Abby:   B→Dz, Dx→B, A→Dz, Dx→A.

Brenda reads Cz in Z and Cx in X at the early stage. Deferring those readouts in the independent state-vector calculation is valid because subsequent gates do not act on her meters; the density-matrix calculation explicitly branches on the early record. Abby's outcome is summed. The complete joint distributions agree within 3e−17. Reversing the measurement order is a control: conditioned on HA Phi+, both agents verify Phi+ with certainty, consistent with the source's ordering dependence.

The calculation does not silently destroy Abby's infalling meter. A decoded meter is an isometric output relabelling and tracing it leaves the same marginal. Explicit final-state teleportation of each meter through a fresh Bell pair has Kraus maps K_l=U_l/2 for four Pauli unitaries U_l, so K_l†K_l=I/4, including when the meter is entangled. This identity is checked for all outcomes. Fixing Phi+ teleports the meter identically with amplitude 1/2. If both Abby meter teleportation flags are included in an ordinary heralded realization, requiring HA Phi+ and both meter Phi+ outcomes has success probability (1/4)^3=1/64, while the conditional Brenda distributions are unchanged. All 4^3 outcome combinations are included by the product instruments; summing the meter outcomes is trace preserving. For the do-nothing branch one can retain the same two idle meters for a like-for-like resource ledger.

The source's interior-operation consistency condition is also checked: the entire interior two-CNOT operation on A,Dz,Dx has unitary partial transpose on A (zero numerical error), not merely each CNOT individually. Therefore the replication has not inserted an obvious violation of that stated constraint.

## Scope and stopping condition

This closes the finite-qubit algebraic question for this source protocol. It establishes a conditional backward-record dependence under a specified fundamental final boundary; it does not establish that nature supplies that boundary. No black-hole geometry, feasible radiation decoder, controllable singularity, or experimental final-state-enforcement mechanism is supplied. It neither disproves all final-state models nor proposes hardware. Further capacity or noise optimization would assume the very resource still missing and is not prioritized.

## Reproduce

    python final_state/replicate.py

Requires Python and NumPy. `results.json` records full joint HA-final/earlier-record tables, conditional and unconditioned distributions, reverse-order control, and verification residuals. Assertions fail on probability normalization, wrong expected marginals, meter/instrument mismatch, or failed partial-transpose/teleportation checks.
