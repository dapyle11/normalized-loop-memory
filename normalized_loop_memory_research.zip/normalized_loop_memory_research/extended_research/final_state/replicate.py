"""Finite-qubit replication of Lloyd--Preskill 1308.4209, §§6.3--6.5.
No physical final-state resource is simulated: all outcomes are retained first,
then the conditional HM distribution is explicitly distinguished.
"""
import json
from pathlib import Path
import numpy as np
I=np.eye(2); X=np.array([[0,1],[1,0]]); Z=np.diag([1,-1]); H=(X+Z)/np.sqrt(2)
bells=[np.array(v,dtype=complex)/np.sqrt(2) for v in
       ([1,0,0,1],[1,0,0,-1],[0,1,1,0],[0,1,-1,0])]
labels=['Phi+','Phi-','Psi+','Psi-']
def embed(op, qs, n):
    """Embed arbitrary k-qubit operator with ordered qubit list, MSB convention."""
    out=np.zeros((2**n,2**n),complex)
    for a in range(2**n):
        bits=[(a>>(n-1-q))&1 for q in range(n)]
        col=sum(bits[q]<<(len(qs)-1-i) for i,q in enumerate(qs))
        for row in range(2**len(qs)):
            b=bits.copy()
            for i,q in enumerate(qs): b[q]=(row>>(len(qs)-1-i))&1
            dest=sum(bit<<(n-1-q) for q,bit in enumerate(b))
            out[dest,a]=op[row,col]
    return out
def projs(qs): return [embed(np.outer(b,b.conj()),qs,4) for b in bells]
# H,A,B,R in this exact order. Initial Bell pairs HR and AB.
psi=np.zeros(16,complex)
for h in range(2):
    for a in range(2): psi[(h<<3)+(a<<2)+(a<<1)+h]=.5
rho=np.outer(psi,psi.conj()); PB=projs([2,3]); PA=projs([1,2]); PF=projs([0,1])
def table(setting,reverse=False):
    # j=Brenda Bell outcome, a=Abby Bell outcome (a=0 placeholder if absent),
    # k=complete HA Bell measurement outcome. Actual classical record j kept.
    out=np.zeros((4,4,4))
    for j in range(4):
        for a in range(4 if setting else 1):
            A=PA[a] if setting else np.eye(16)
            K=PB[j]@A if reverse else A@PB[j]
            branch=K@rho@K.conj().T
            for k,F in enumerate(PF): out[j,a,k]=np.trace(F@branch).real
    return out

def cnot(v,c,t,n=8):
    w=np.empty_like(v)
    for i in range(len(v)):
        dest=i^(1<<(n-1-t)) if (i>>(n-1-c))&1 else i
        w[dest]=v[i]
    return w
def one(v,op,q,n=8):
    v=v.reshape([2]*n); v=np.moveaxis(v,q,0)
    v=np.tensordot(op,v,axes=([1],[0]));return np.moveaxis(v,0,q).reshape(-1)
def meter_table(setting,reverse=False):
    # Qubits H A B R Cz Cx Dz Dx. Z meters |0>, X meters |+>.
    zero=np.array([1,0]);plus=np.array([1,1])/np.sqrt(2)
    v=psi
    for s in (zero,plus,zero,plus):v=np.kron(v,s)
    def brenda(v):
        for c,t in [(2,4),(3,4),(5,2),(5,3)]:v=cnot(v,c,t)
        return v
    def abby(v):
        # Outside B interactions first; then inside A interactions.
        for c,t in [(2,6),(7,2),(1,6),(7,1)]:v=cnot(v,c,t)
        return v
    if reverse:
        if setting:v=abby(v)
        v=brenda(v)
    else:
        v=brenda(v)
        if setting:v=abby(v)
    # Read X meters in X basis, Z meters in Z. Readout can be early for C:
    # all subsequent gates act only on the other wires.
    v=one(one(v,H,5),H,7)
    out=np.zeros((4,4,4))
    tensor=v.reshape([2]*8)
    for k,b in enumerate(bells):
        reduced=np.tensordot(b.conj().reshape(2,2),tensor,axes=([0,1],[0,1]))
        # remaining B,R,Cz,Cx,Dz,Dx
        prob=np.abs(reduced)**2
        for cz in range(2):
            for cx in range(2):
                for dz in range(2):
                    for dx in range(2):
                        out[2*cz+cx,2*dz+dx,k]=prob[:,:,cz,cx,dz,dx].sum()
    return out

def summary(t):
    joint=t.sum(axis=1)
    prior=joint.sum(axis=1);success=joint[:,0].sum()
    return dict(joint_earlier_record_final_outcome=joint.tolist(),
                earlier_unconditioned=prior.tolist(),
                final_outcome_probabilities=joint.sum(axis=0).tolist(),
                heralded_success_probability=float(success),
                hm_or_success_conditioned_earlier=(joint[:,0]/success).tolist(),
                failure_conditioned_earlier=(joint[:,1:].sum(axis=1)/(1-success)).tolist(),
                earlier_abby_joint_given_success=(t[:,:,0]/success).tolist())
results={'bell_order':labels,'qubit_order':['H','A','B','R'],'cases':{},'checks':{}}
for setting in (False,True):
    t=table(setting);u=meter_table(setting)
    err=np.max(abs(t-u));assert err<1e-12
    assert abs(t.sum()-1)<1e-12
    if setting: assert np.max(abs(t-1/64))<1e-12
    assert np.max(abs(t.sum(axis=(1,2))-.25))<1e-12
    expected=np.ones(4)/4 if setting else np.array([1,0,0,0])
    assert np.max(abs(t[:,:,0].sum(axis=1)/t[:,:,0].sum()-expected))<1e-12
    results['cases']['later_measure_AB' if setting else 'later_do_nothing']=summary(t)
    results['checks'][f'projector_vs_sequential_meter_maxerror_{setting}']=float(err)
t=table(True,True);u=meter_table(True,True)
assert np.max(abs(t-u))<1e-12
assert abs(t[0,0,0]/t[:,:,0].sum()-1)<1e-12
results['reverse_order_control']=summary(t)
results['checks']['reverse_order_both_verify_given_success']=True
results['checks']['record_before_later_choice_unconditioned_TV']=float(.5*np.abs(table(0).sum(axis=(1,2))-table(1).sum(axis=(1,2))).sum())
c0=table(0)[:,:,0].sum(axis=1)/table(0)[:,:,0].sum()
c1=table(1)[:,:,0].sum(axis=1)/table(1)[:,:,0].sum()
results['checks']['conditional_channel_TV']=float(.5*np.abs(c0-c1).sum())
path=Path(__file__).with_name('results.json');path.write_text(json.dumps(results,indent=2)+'\n')

# Check the source's interior-interaction partial-transpose unitarity criterion.
# Three wires A,Dz,Dx. Each CNOT is real, but check the whole product, not each gate.
U=np.eye(8,dtype=complex)
for c,t in [(0,1),(2,0)]:
    U=np.stack([cnot(U[:,j],c,t,n=3) for j in range(8)],axis=1)
UPT=U.reshape(2,4,2,4).transpose(2,1,0,3).reshape(8,8)
pt_error=float(np.max(abs(UPT.conj().T@UPT-np.eye(8))))
assert pt_error<1e-12
results['checks']['interior_U_partial_transpose_unitarity_error']=pt_error
# Conditional teleportation of a meter, including an entangled reference,
# is identity/2 for Phi+ and Pauli/2 for other Bell outcomes.
tele=[]
for bell in bells:
    # K[out,in] = <bell|_{in,partner} (|in> tensor |Phi+>_{partner,out}).
    K=bell.conj().reshape(2,2).T/np.sqrt(2)
    err=float(np.max(abs(K.conj().T@K-np.eye(2)/4)))
    assert err<1e-12
    tele.append(err)
results['checks']['meter_teleport_all_four_KdagK_equals_I_over_4_errors']=tele
path.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
