import numpy as np,json,itertools
from math import sqrt
out=[]
for p,q in itertools.product([.01,.1,.25,.49],[0,.1,.25,.49,.5]):
 A=1-p;s=p+q-2*p*q;r=1-s
 x=2*r/(r*(A+1)+sqrt(r*r*(A+1)**2-4*A*(r-s)*r))
 D=np.zeros((2,3,2));D[0,0,1]=x;D[0,1,0]=1-x;D[1,2,0]=x;D[1,1,1]=1-x
 E=[[0,0],[0,1],[1,1]];w=np.zeros((3,3))
 for m,h,b,c,d in itertools.product(range(3),range(3),range(2),range(2),range(2)):
  w[m,h]+=D[b,h,c]*(1-q if c==d else q)*(A if b==E[m][d] else p)
 success=w.diagonal()/w.sum(axis=1)
 assert np.max(abs(success-A*x))<1e-12
 assert min(success)>=A/(A+1)-1e-12
 out.append(dict(p=p,q=q,x=x,success=success.tolist(),erased_optimum=A/(A+1)))
print(json.dumps({'checked':len(out),'max_residual_below':1e-12,'examples':out},indent=2))
