"""Verify saved feasible classical decoders exactly; standard library only.
The upper certificate verifier is separate. No numerical solver is imported.
"""
from fractions import Fraction as F
from pathlib import Path
import itertools
import json

root = Path(__file__).resolve().parent
rows = json.loads((root / 'rational_lower_certificates.json').read_text())
upper = json.loads((root / 'rational_upper_certificates.json').read_text())
assert len(rows) == len(upper)
maximum_width = F(0)
for row, bound in zip(rows, upper):
    p, q, k = F(row['p']), F(row['q']), row['k']
    assert 0 < p < F(1, 2) and 0 <= q <= F(1, 2)
    assert (p, q, k) == (F(bound['p']), F(bound['q']), bound['k'])
    enc = row['encoder']
    decoder = [[F(x) for x in v] for v in row['decoder']]
    assert len(enc) == k and len(decoder) == 2
    assert all(len(f) == 2 and all(v in [0, 1] for v in f) for f in enc)
    assert all(len(v) == 2*k and min(v) >= 0 and sum(v) == 1 for v in decoder)
    weights = [[F(0) for _ in range(k)] for _ in range(k)]
    for m, h, b, c, d in itertools.product(range(k), range(k), range(2), range(2), range(2)):
        weights[m][h] += decoder[b][2*h+c] * (1-q if d == c else q) * (1-p if b == enc[m][d] else p)
    den = [sum(w) for w in weights]
    assert all(2*p <= z <= 2*(1-p) for z in den)
    lo = min(weights[m][m]/den[m] for m in range(k))
    hi = F(row['upper'])
    assert lo == F(row['lower'])
    assert hi == F(bound['upper_success'])
    assert hi-lo == F(row['interval_width'])
    assert 0 < hi-lo < F(11, 10**7)
    maximum_width = max(maximum_width, hi-lo)
print(json.dumps({'cases': len(rows), 'exact_feasible_lower_witnesses': len(rows),
                  'maximum_interval_width': float(maximum_width), 'passed': True}, indent=2))
