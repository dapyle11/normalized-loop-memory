"""Exploratory finite classical LP search; exact certificates and proofs are separate.
No physical backward channel or literature-priority claim is asserted.
"""
from pathlib import Path
import numpy as np,itertools,json
from scipy.optimize import linprog

def solve(p,q,k,steps=28):
 nvar=4*k
 # decoder index [b,h,c]
 N=np.array([[1-p,p],[p,1-p]]) # b,a
 L=np.array([[1-q,q],[q,1-q]]) # d,c
 Aeq=np.zeros((2,nvar))
 for b in range(2):Aeq[b,b*2*k:(b+1)*2*k]=1
 best=0; winner=None
 for enc in itertools.product(list(itertools.product(range(2),repeat=2)),repeat=k):
  denom=np.zeros((k,nvar));num=np.zeros((k,nvar))
  for m,b,h,c in itertools.product(range(k),range(2),range(k),range(2)):
   j=(b*k+h)*2+c
   denom[m,j]=sum(L[d,c]*N[b,enc[m][d]] for d in range(2))
   if h==m:num[m,j]=denom[m,j]
  lo=best;hi=1
  feasible=linprog(np.zeros(nvar),A_ub=lo*denom-num,b_ub=np.zeros(k),A_eq=Aeq,b_eq=np.ones(2),bounds=(0,None),method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
  if not feasible.success:continue
  x=feasible.x
  for _ in range(steps):
   t=(lo+hi)/2
   r=linprog(np.zeros(nvar),A_ub=t*denom-num,b_ub=np.zeros(k),A_eq=Aeq,b_eq=np.ones(2),bounds=(0,None),method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
   if r.success:lo=t;x=r.x
   else:hi=t
  # compute actual achieved rather than trusting LP residual tolerance
  x=np.maximum(x,0).reshape(2,-1);x=x/x.sum(axis=1)[:,None];x=x.ravel()
  actual=float(min((num@x)/(denom@x)))
  if actual>best:best=actual;winner={'encoder':enc,'decoder':x.reshape(2,k,2).tolist(),'success_per_message':((num@x)/(denom@x)).tolist()}
 return dict(p=p,q=q,k=k,success=best,winning=winner)
if __name__=='__main__':
 out=[]
 for k in [2,3,4]:
  for p in [.1,.25]:
   for q in [0,.1,.25,.5]:
    r=solve(p,q,k);out.append(r);print(k,p,q,r['success'],flush=True)
 open(Path(__file__).with_name('results.json'),'w').write(json.dumps(out,indent=2))
