"""Exact rational mutual-information separation via a convergent log series.
No numerical optimizer or floating-point transcendental function is needed.
"""
from fractions import Fraction as F
from pathlib import Path
import json
P=[[F(9,10),F(1,20),F(1,20)],[F(1,10),F(9,20),F(9,20)],[F(1,6),F(3,4),F(1,12)]]
pi=[F(1,2),F(1,3),F(1,6)]
# decoder outputs (b,c)=(0,0),(1,0),(1,1), only c is forwarded
outcomes=[(0,0),(1,0),(1,1)];decoder=[F(1),F(1,2),F(1,2)];enc=[(0,0),(1,1),(1,0)];p=F(1,10)
raw=[[decoder[j]*(1-p if b==enc[m][c] else p) for j,(b,c) in enumerate(outcomes)] for m in range(3)]
Z=[sum(row) for row in raw];assert Z==[F(1),F(1),F(3,5)]
assert [[v/Z[i] for v in row] for i,row in enumerate(raw)]==P
q=[sum(pi[i]*P[i][j] for i in range(3)) for j in range(3)];assert q==[F(23,45),F(3,10),F(17,90)]
def log_bounds(x,N=160):
 z=(x-1)/(x+1);term=z;s=F(0)
 for k in range(N):s+=term/(2*k+1);term*=z*z
 s*=2;err=2*abs(term)/((2*N+1)*(1-z*z))
 return s-err,s+err
Ilo=F(0);Ihi=F(0)
for i in range(3):
 for j in range(3):
  lo,hi=log_bounds(P[i][j]/q[j]);coef=pi[i]*P[i][j];Ilo+=coef*lo;Ihi+=coef*hi
l2,u2=log_bounds(F(2));lp,up=log_bounds(p);lA,uA=log_bounds(1-p)
# Binary channel capacity in natural-log units.
B_lo=l2+p*lp+(1-p)*lA;B_hi=u2+p*up+(1-p)*uA
assert Ilo>F(55,100)*u2
assert Ilo-B_hi>F(2,100)*u2
lo=Ilo/u2;hi=Ihi/l2;blo=B_lo/u2;bhi=B_hi/l2
result={'status':'exact rational contraction and log-series bounds passed','channel':[[str(v) for v in row] for row in P],'input_prior':list(map(str,pi)),'output_prior':list(map(str,q)),'normalizers':list(map(str,Z)),'log_terms':160,'information_lower':str(lo),'information_upper':str(hi),'direct_BSC_lower':str(blo),'direct_BSC_upper':str(bhi),'certified_information_gt':'.55','certified_gain_gt':'.02','decimal_information':float(lo),'decimal_direct_BSC':float(blo),'decimal_gain':float(lo-bhi)}
Path(__file__).with_name('rate_witness_certificate.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['information_lower','information_upper','direct_BSC_lower','direct_BSC_upper']},indent=2))
