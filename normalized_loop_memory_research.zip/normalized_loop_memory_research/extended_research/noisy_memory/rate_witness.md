# A certified rate-oriented classical one-bit witness

AI-generated mathematical research note; not independently human reviewed. No novelty, global-capacity or physical-device claim is made.

## Result and scope
For one hypothetical backward BSC(1/10) and one noiseless forward **classical bit per backward use**, an explicit fixed protocol induces a DMC with mutual information

I = .5558516340843477… bits/use

under a stated input law. This exceeds the direct backward BSC capacity

1−H2(1/10)=.5310044064107188…

by .0248472276736289… bits/use. Exact rational log-series bounds certify **I>.55 and the gain>.02**, independently of floating-point optimization. This is an achievable rate witness against the ignore-memory baseline, not the globally optimized capacity and not a quantum-over-classical asymptotic separation. **It does not improve existing broader asymptotic bounds under an average forward-memory budget:** the published block strategy, time-shared with direct coding, already exceeds this rate at average forward rate one. See the precise comparison below.

## Explicit protocol and resource ledger
The backward bit exiting in the past is b. The past decoder chooses c=0 if b=0, and chooses c uniformly if b=1. It records the early raw output h=(b,c), with the three possible values (0,0),(1,0),(1,1), and forwards **only c** through one noiseless classical memory bit. The record h is part of the receiver's output, not a second forward input.

The future sender has three input symbols, using deterministic encoders

C0: a=0, C1: a=1, N: a=1−c.

No shared random seed, extra retained forward register, or access to b is granted to the future sender. The coin used when b=1 is local decoder randomness; its only forward influence is the allowed bit c.

With columns ordered as the three early outputs and rows as C0,C1,N, the exact normalized conditional channel is

    [ 9/10   1/20   1/20 ]
P = [ 1/10   9/20   9/20 ].
    [ 1/6    3/4    1/12 ]

The unnormalized loop normalizers are respectively (1,1,3/5). For example the N row's raw weights are (1/10,9/20,1/20), which sum to 3/5; dividing gives the displayed row.

Use input probabilities (1/2,1/3,1/6). The output probabilities are exactly (23/45,3/10,17/90). Compute

I=Σ_(m,h) pi_m P(h|m) log2[P(h|m)/q_h].

The early raw output need not itself guess the three-symbol input. In a block code, a final past decoder maps the sequence of raw outputs to the code message. This is ordinary channel coding, and requires no extra forward communication. The tensor identity and maximum-error coding justification are in `asymptotic_bridge.md`.

## Exact elementary logarithm certificate
`rate_witness_verify.py` uses only Python's standard library. It first recomputes every raw and normalized channel entry as a Fraction, checks normalizers and input/output laws, and then bounds all logarithms with

ln x = 2 Σ_(k=0)^(N−1) z^(2k+1)/(2k+1) + remainder,
z=(x−1)/(x+1),
|remainder| ≤ 2|z|^(2N+1)/[(2N+1)(1−z²)].

All arithmetic including the remainder is rational. N=160 suffices. The script proves lower information >.55 bits and lower information minus upper direct-BSC capacity >.02 bits, while storing exact rational endpoints in `rate_witness_certificate.json`. The decimals above are only illustrations of these certified bounds. No optimizer or numerical logarithm is used by this certificate.

## Legitimate asymptotic consequence
For every rate strictly below I, independent tensor repetitions plus deterministic classical coding communicate backward classical bits with vanishing maximum conditional error, consuming one forward bit per backward channel use. For this rational input law one can specifically use constant-composition codes with n a multiple of six: every codeword has n/2 symbols C0, n/3 symbols C1, and n/6 symbols N. Fixed-composition channel coding achieves I_pi; expurgating high-error codewords preserves this composition. Every codeword then has exactly the same loop normalizer (3/5)^(n/6), so the code-message prior is not reweighted even before applying the maximum-error argument. In particular the rate **.55 classical bits per backward use is achievable** in the hypothetical resource model, whereas direct BSC coding alone has capacity .5310044… . The assisting forward bit is charged; this is not a violation of the ordinary memoryless BSC theorem.

If the available forward resource is instead a noiseless **qubit** channel, the same classical protocol embeds in a fixed basis. The separately proved postselection-aware teleportation bridge then uses an additional Q forward qubits per backward use to distribute Bell halves, yielding Q<I/2 at R=1+Q. In particular

(R,Q)=(51/40,11/40)=(1.275,.275)

is an explicit achievable quantum-rate point for the identity-forward-memory specialization of Ji–Lloyd–Wilde Eq. (13), since 2Q=.55<I. **This quantum-rate point is already implied by their published construction; it is not a distinct quantum-rate advance.** See the attribution below. This is not achievable from a purely classical forward resource alone: Bell-half distribution explicitly uses the additional qubits. It also is not a comparison against the globally optimal alternative protocol at the same R.

The earlier minimum-error-optimal M3/M4 gadgets had lower Shannon capacity than direct BSC coding. This new example changes the objective and retains more useful raw decoder output. Thus one-shot minimax success and asymptotic information rate must not be conflated.

No claim of scientific novelty, general noisy-memory frontier, global capacity optimum, or physical backward communication is made. The source framework and coding/teleportation references are listed in `asymptotic_bridge.md`.

## Laboratory heralding is not an uncharged channel

An ordinary forward simulator may sample b uniformly and accept the later consistency test with probability N_p(b|a)/A, where A=9/10. Its one-use acceptance is Z_m/(2A), not 1. For the constant-composition code above, the joint acceptance per attempted block is exactly

    (5/9)^n (3/5)^(n/6),

which decays exponentially. No acceptance flag is available to the earlier receiver until ordinary forward communication delivers it. The .55 rate is measured per **assumed hypothetical P-CTC channel use**, not per laboratory trial or per unit time in a heralded simulator. Discarding this success cost would change the physical resource model.

Constant-composition channel coding is standard method-of-types machinery; a primary exposition is Csiszár, [*The Method of Types*, IEEE Transactions on Information Theory 44 (1998), Section IV](https://doi.org/10.1109/18.720546). The coding theorem is prior art, not part of any novelty claim for this example.

## Prior-art correction: the quantum point is already covered

Ji–Lloyd–Wilde's [Supplemental Strategy 1, Eqs. (S76)–(S77)](https://arxiv.org/html/2509.08965v3) explicitly uses L1 isomorphic to the message system M and L2 isomorphic to the backward output B. On n binary backward-channel uses, this requires n+log2(d_M) noiseless forward qubits, hence R=1+Q when d_M≈2^(nQ).

For BSC(.1), the identity and bit-flip loop choices have amplification ratio 9^n. Their published probabilistic-teleportation construction consequently has error bounded by (d_M²−1)/(9^n+d_M²−1), tending to zero for every Q<(1/2)log2(9)≈1.58496 while using R=1+Q. In particular our bookkeeping point (.275,1.275), written as (Q,R), lies in this already-known achieved family.

Our bridge is therefore a consistency/resource-accounting check, not a new quantum-rate contribution or a solution of their open noisy-memory problem. The separately certified classical witness concerns one charged forward **classical** bit per backward use and comparison to direct BSC coding; its scientific priority remains unverified.

## Prior-art correction: average memory cost versus one bit per inner use

The same primary paper's [Supplemental Strategy 2, Eqs. (S149)–(S150)](https://arxiv.org/html/2509.08965v3) stores a copy of the random early guess h in L1 and the backward output in L2. For a block of n classical BSC outputs, both registers can be classical: forward n bits for b^n plus log2(M) bits for h. The future sender applies identity to b^n if h=m and bit-flips every coordinate otherwise.

In the BSC(.1) specialization, correct and incorrect guesses have loop weights proportional to A^n and p^n. Consequently the probability of the correct guess is

    A^n/[A^n+(M−1)p^n].

For M≈2^(nC1), this tends to one whenever C1<log2(9), using forward classical-bit rate 1+C1. This is a resource-accounted specialization of the **published** construction, not a new result attributed to this notebook.

Time-share deterministically between this block construction and direct BSC coding at rate C0=1−H2(.1), which uses no forward memory. With fraction λ=1/(1+C1) of backward uses assigned to the high-assistance construction, the **average** forward-bit rate is one and the achievable classical rate is

    λC1+(1−λ)C0 = C1(1+C0)/(1+C1).

As C1 approaches log2(9) from below, this approaches **1.16385046338… bits per backward use**, far above the .5558516 witness. Deterministic block scheduling needs no shared random seed. The independent subblocks have positive normalizers and can carry separate message parts; maximum error tends to zero by the union bound. Integer rounding vanishes asymptotically.

Therefore our witness is a compact, exactly certified one-bit-per-inner-use example that beats **ignoring memory**, not an improved known asymptotic rate frontier. Requiring at most one forwarded bit for each independent inner use is stricter than charging only the total/average forward memory across an arbitrary block. The published rate tradeoff permits the latter resource accounting. Neither the quantum-rate bookkeeping point nor this classical witness is presented as a new contribution to that broader frontier.
