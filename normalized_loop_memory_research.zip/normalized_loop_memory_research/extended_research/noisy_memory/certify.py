# Exact rational certificates for numerical upper endpoints.
import itertools,json,math
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from pathlib import Path
root=Path(__file__).parent
results=json.loads((root/'results.json').read_text())
allcert=[]
for row in results:
 p,q,k=F(str(row['p'])),F(str(row['q'])),row['k']
 t=F(math.ceil((row['success']+2e-8)*10**6),10**6)
 cert=[];worst=None
 for enc in itertools.product(list(itertools.product(range(2),repeat=2)),repeat=k):
  n=4*k;G=[[F(0) for j in range(n)] for m in range(k)]
  for m,b,h,c in itertools.product(range(k),range(2),range(k),range(2)):
   den=sum((1-q if d==c else q)*(1-p if b==enc[m][d] else p) for d in range(2))
   G[m][(b*k+h)*2+c]=den*((1 if h==m else 0)-t)
  Aeq=np.zeros((2,n+1));Aeq[0,:2*k]=1;Aeq[1,2*k:n]=1
  r=linprog(np.r_[np.zeros(n),-1],A_ub=np.c_[-np.array(G,dtype=float),np.ones(k)],b_ub=np.zeros(k),A_eq=Aeq,b_eq=[1,1],bounds=[(0,None)]*n+[(None,None)],method='highs')
  assert r.success
  raw=[max(0,round(float(-a)*10**12)) for a in r.ineqlin.marginals]
  alpha=[F(a,sum(raw)) for a in raw]
  beta=[max(sum(alpha[m]*G[m][j] for m in range(k)) for j in range(b*2*k,(b+1)*2*k)) for b in range(2)]
  total=sum(beta)
  assert total<0,(p,q,k,t,enc,total)
  worst=total if worst is None else max(worst,total)
  cert.append({'encoder':enc,'alpha':[str(a) for a in alpha],'beta':[str(b) for b in beta]})
 allcert.append({'p':str(p),'q':str(q),'k':k,'upper_success':str(t),'strict_margin':str(-worst),'certificates':cert})
 print(k,str(p),str(q),'upper',float(t),'margin',float(-worst),flush=True)
(root/'rational_upper_certificates.json').write_text(json.dumps(allcert,indent=2))
