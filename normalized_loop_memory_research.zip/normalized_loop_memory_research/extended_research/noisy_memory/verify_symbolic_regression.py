"""Independent numerical proposal / exact-rational verification, not proof by grid."""
from fractions import Fraction as Q
from itertools import product
import random, json
import numpy as np
from scipy.optimize import linprog
from pathlib import Path
P=Path(__file__).parent
rng=random.Random(72031)
params=[(Q(p),Q(q)) for p in ['.0001','.4999'] for q in ['0','.0001','.4999','.5']]
params += [(Q(rng.randrange(1,5000),10000),Q(rng.randrange(5001),10000)) for _ in range(8)]
encoders=list(product(list(product(range(2),repeat=2)),repeat=3))
records=[]
for p,q in params:
 A=1-p;s=p+q-2*p*q;r=1-s
 f=lambda t:r*(A-t)*(1-t)-s*t*t
 lo,hi=Q(0),A
 for _ in range(80):
  mid=(lo+hi)/2
  if f(mid)>0:lo=mid
  else:hi=mid
 # Upper target separated by a rational 1e-6, safely beneath A.
 t=hi+min(Q(1,10**6),(A-hi)/2)
 assert f(lo)>=0 and f(hi)<=0 and f(t)<0
 margins=[]
 for enc in encoders:
  G=[]
  for m in range(3):
   row=[]
   for b,h,c in product(range(2),range(3),range(2)):
    K=sum((1-q if d==c else q)*(1-p if b==enc[m][d] else p) for d in range(2))
    row.append(K*((h==m)-t))
   G.append(row)
  # Direct dual LP: minimize beta0+beta1 with weights summing to one.
  Aub=[]
  for j in range(12):
   Aub.append([float(G[m][j]) for m in range(3)]+[-int(j//6==b) for b in range(2)])
  ans=linprog([0,0,0,1,1],A_ub=Aub,b_ub=[0]*12,A_eq=[[1,1,1,0,0]],b_eq=[1],bounds=[(0,None)]*3+[(None,None)]*2,method='highs')
  assert ans.success
  raw=[Q(max(0,round(x*10**13))) for x in ans.x[:3]]
  weights=[x/sum(raw) for x in raw]
  beta=[max(sum(weights[m]*G[m][j] for m in range(3)) for j in range(6*b,6*b+6)) for b in range(2)]
  assert sum(beta)<0,(p,q,enc,beta)
  margins.append(-sum(beta))
 records.append({'p':str(p),'q':str(q),'root_lower':str(lo),'root_upper':str(hi),'tested_upper':str(t),'encoders_verified':64,'minimum_exact_negative_dual_margin':str(min(margins))})
 print(str(p),str(q),'passed',flush=True)
(P/'symbolic_regression_results.json').write_text(json.dumps(records,indent=2))
print('PASS:',len(params)*64,'exact rational dual verifications')
