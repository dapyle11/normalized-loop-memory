# Exact three-message theorem for one noisy classical forward-memory bit

## Status and relation to the published question
This is a complete mathematical solution of the **explicitly restricted model below**, with analytic proofs and independently implemented numerical and rational checks. It is an AI-generated research notebook, not independently human reviewed; priority is not established.

The motivating source is Ji, Lloyd, Wilde, *Retrocausal Capacity of a Quantum Channel: Communicating Through Noisy Closed Timelike Curves*, [arXiv:2509.08965v3](https://arxiv.org/html/2509.08965v3). Their Eq. (2) gives the decoder–memory–encoder contraction in the hypothetical P-CTC model; the discussion after Eq. (12), and Eq. (13), ask about a noisy forward-memory rate tradeoff. The source does not define all operational details of that extension in that paragraph. We therefore declare our finite classical restriction explicitly. This theorem is not their full quantum/asymptotic tradeoff, a result about physical backward communication, or a laboratory postselection-cost theorem.

## 1. Operational assumptions
There is one backward binary symmetric channel BSC(p), one ordinary forward BSC(q), and three classical messages m∈{0,1,2}. Assume 0<p<1/2 and 0≤q≤1/2. The backward input/output bits are a,b; forward memory bits are c,d. Decoder and encoder are arbitrary classical stochastic maps

D(h,c|b),   E(a|m,d),

where h is the recovered message. Local private randomness is allowed. There is no additional retained memory, shared random variable across the temporal boundary, shared entanglement, coherent quantum processing, or extra communication. In particular, a shared random seed cannot be treated as free: retaining it would supply another forward resource.

Define normalized channels N_p(b|a)=1−p when b=a and p otherwise, and L_q(d|c) analogously. The stipulated postselection contraction is

w_m(h)=Σ_(a,b,c,d) N_p(b|a)D(h,c|b)L_q(d|c)E(a|m,d),
Z_m=Σ_h w_m(h),
S(D,E)=min_m w_m(m)/Z_m.

Common Bell-postselection normalization factors cancel in these ratios. Set A=1−p. Every Z_m lies in [2p,2A], so all probabilities are well defined throughout the stated domain.

## 2. Theorem
Let s=p+q−2pq and r=1−s. Thus 1/2≤r≤A and p≤s≤1/2. The optimum over **all** allowed stochastic encoders and decoders equals

T = 2Ar / {r(A+1)+sqrt[r²(A+1)²−4Ar(r−s)]}.

Equivalently, T is the unique root in (0,A) of

F(t)=r(A−t)(1−t)−st²=0.

This root obeys

A/(A+1)≤T<A,

with equality in the first inequality exactly when q=1/2. In particular, every q<1/2 strictly improves over erased memory, whose exact optimum is A/(A+1)=(1−p)/(2−p).

For comparison, with two messages rather than three, the exact optimum is A for every q: a binary-message test would not reveal this improvement.

## 3. Achievability and properties of the root
Use deterministic encoders C0(d)=0, I(d)=d, C1(d)=1 for messages 0,1,2. Put x=T/A. Choose decoder

* b=0: (h,c)=(0,1) with probability x, or (1,0) with probability 1−x;
* b=1: (h,c)=(2,0) with probability x, or (1,1) with probability 1−x.

Direct contraction gives success Ax for each constant-encoder message, and

r(1−x)/[r(1−x)+sx]

for the identity-encoder message. The former increases and the latter decreases with x; their intersection gives F(T)=0 and the stated stable root formula.

F(0)=rA>0 and F(A)=−sA²<0. On [0,A],

F'(t)=−r(A+1)+2(r−s)t<0,

because 2(r−s)t≤2rA and A<1. Hence the root is unique. At x=1/(A+1), identity-message success is at least Ax, strictly so if r>s. Therefore T≥A/(A+1), strictly for q<1/2. Also T>A/2 throughout the stated domain.

## 4. Why deterministic encoders suffice
Fix a decoder. For each message m, a stochastic encoder E_m is a convex combination of four deterministic functions {C0,C1,I,X}, with X(d)=1−d. Its ratio w_m(m)/Z_m is a **denominator-weighted** average of the ratios for those vertices, because all Z_m>0. Some deterministic vertex is therefore at least as good.

The encoder choices for different messages are independent. Replace them one at a time without decreasing any message's success. Thus it suffices to consider the 4³ deterministic encoder triples. This reduction does not assume joint convexity of decoder/encoder optimization.

## 5. A dual upper-bound rule
For fixed deterministic encoders f_m, write

K_m(b,c)=Σ_d L_q(d|c)N_p(b|f_m(d)).

For target t and positive numbers λ_m, define

G(b,h,c)=Σ_m λ_m K_m(b,c)(1[h=m]−t).

If every column satisfies G(b,h,c)≤β_b and β_0+β_1≤0, then no decoder can have every message success strictly greater than t. Indeed, multiplication by D and summation yields

Σ_m λ_m[w_m(m)−tZ_m]≤β_0+β_1≤0,

whereas all successes greater than t would make the left side positive. Signed β_b are allowed.

## 6. All-distinct encoder triples
BSC-preserving bit relabelings and message permutations reduce these to two classes.

### 6.1 Both constants and one bijection: {C0,I,C1}
At t=T take λ_C0=λ_C1=u and λ_I=1, where

u=sT/(A−T)=r(1−T)/T>0.

In row b=0, the largest C0 column is u(A−T)−sT=0; the largest I column is r(1−T)−uT=0. The C1 columns are no larger than C0 columns because p≤A. Row b=1 is symmetric. Hence β_0=β_1=0 proves global upper bound T for this encoder class, matching the construction.

### 6.2 One constant and both bijections: {C0,I,X}
This class has exact optimum

U=2Ar/(2A+r).

For the upper bound choose λ_C0=z=r/A and λ_I=λ_X=1. Let N_b=A for b=0 and p for b=1. The largest weighted column in row b is

β_b=max{zN_b(1−t)−t, r−t−zN_bt}.

The terms tie in row b=0; the second dominates in row b=1. Thus

β_0+β_1=2r−t(2+r/A),

which vanishes at U.

For completeness, U is attainable. Let y=2r/(2A+r). At b=0 assign probability y/2 each to (C0,0),(C0,1), and probability (1−y)/2 each to (I,0),(X,1). At b=1 assign probability 1/2 each to (I,1),(X,0). All encoder normalizations equal 1; successes are Ay and r(2−y)/2, equal to U.

This class cannot beat T. Direct expansion gives

F(U)=Ar P/(2A+r)²,
P=r²(2r−1)+2r(A−r)(2−r)+4(A−r)²(1−r)≥0.

Since 0<U<A, F decreases on the required interval and F(T)=0, U≤T.

## 7. Encoder triples with repetitions
If all three encoders coincide, their normalized output distributions coincide and worst-case success is at most 1/3≤T.

Otherwise two messages use f and one uses a different g. Their equal encoder kernels permit symmetrizing the decoder labels of the repeated pair without harming worst-case performance. Let G denote the repeated pair's output group, x_b=P(G|b), and X=x_0+x_1. Each repeated message gets half the group success.

A constant encoder has row coefficients A,p and normalization 1. A bijective encoder has coefficients r or s, so group weight lies between sX and rX and complementary weight between s(2−X) and r(2−X). We exhaust the four ordered type pairs below.

### 7.1 Repeated constant, singleton opposite constant
The forward channel is irrelevant because both encoders ignore it. In suitable orientation, successes are

(Ax_0+px_1)/2,  and 1−px_0−Ax_1.

For target t these imply Ax_0+px_1≥2t and px_0+Ax_1≤1−t. Multiplying the first by A and subtracting p times the second gives

(2A+p)t−p≤(A²−p²)x_0≤A−p,

so t≤A/(2A+p)=A/(A+1)≤T. Equality is attained with x_0=1,x_1=A/(A+1).

### 7.2 Repeated constant, singleton bijection
To reach T>A/2, X must exceed 1. The repeated-message success is at most [A+p(X−1)]/2, while singleton success is at most

v(X)=r(2−X)/[sX+r(2−X)].

From F(T)=0,

v(X)≥T ⇒ X≤2r(1−T)/[r(1−T)+sT]=2T/A.

The repeated-message condition requires X≥1+(2T−A)/p>2T/A, since multiplying the difference by Ap gives (A−p)(2T−A)>0. Thus this class cannot reach T.

### 7.3 Repeated bijection, singleton constant
Repeated-message success is at most

u(X)=rX/[2(rX+s(2−X))],

an increasing function bounded by 1/2. For X≤1 it is at most r/2≤A/2<T. For X>1 the singleton's success is at most A(2−X).

If T>1/2 the first bound suffices. Otherwise singleton success≥T requires X≤2−T/A. At this endpoint,

u(2−T/A)=r(2A−T)/[2(r(2A−T)+sT)]<T,

because

2sT²−r(2A−T)(1−2T)=rT(2A−1)>0.

### 7.4 Repeated bijection, singleton opposite bijection
The repeated-message bound is u(X) and singleton bound is v(X). Again T>1/2 is excluded immediately. For T≤1/2, v(X)≥T requires X≤2T/A. At that endpoint u(2T/A)≤T is equivalent to

Δ=2As−r+2(r−s)T≥0.

Indeed,

Δ=2T−1+s(2A+1−4T)
 ≥2T−1+p(2A+1−4T)
 =(2A−1)(2T−A)>0,

using s≥p and 2A+1−4T≥2A−1>0. Thus this final repeated class also cannot reach T.

Together, Sections 6–7 cover every deterministic encoder triple. By Section 4 this also covers every stochastic strategy, completing the theorem.

## 8. Checks, endpoints, and scope
At q=1/2, r=s=1/2 and the formula gives T=A/(A+1). Memory output is then independent of its input, and the model reduces to ordinary BSC transmission. At q=0 the same formula remains valid without taking any singular limit. Boundaries p=0 and p=1/2 were excluded from the proof's stated domain; continuity alone is not a proof about possible zero-normalization strategies at p=0.

For two messages, define d_m=Σ_bc D(m,c|b), so d_0+d_1=2. Some message has d_m≤1. Its correct weight is at most Ad_m and incorrect weight at least p(2−d_m), so its success is at most A. Ordinary direct encoding attains A for every q.

Independent numerical regression checks enumerate every deterministic encoder and solve linear feasibility over all decoders. More strongly, exact rational dual certificates and explicit rational decoder witnesses enclose 24 tested optima (including four-message tests) in intervals narrower than 1.1×10^−6. The standard-library verifier checks 2,688 upper certificates without relying on the LP solver. These checks supplement rather than replace the symbolic proof.

The theorem is a newly worked-out restricted result in this research session, **not a certified novel result**. Focused primary-literature searches did not find this precise formula; absence from that search establishes no priority. General many-use coding, coherent quantum memory, entanglement assistance, shared side resources, adaptive operation conventions, and the asymptotic Q(R) frontier remain outside the theorem.
