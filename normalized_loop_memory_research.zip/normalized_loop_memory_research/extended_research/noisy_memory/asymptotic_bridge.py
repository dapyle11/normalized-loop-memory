"""Numerical induced-DMC capacity checks for the bounded asymptotic bridge.
High-precision arithmetic is on rounded channels, not exact algebraic bounds.
See asymptotic_bridge.md for the separate normalization and resource proof.
"""
import numpy as np, json, mpmath as mp
from pathlib import Path
mp.mp.dps=80
I=np.eye(2);sx=np.array([[0.,1.],[1.,0.]]);sz=np.diag([1.,-1.])
def contraction(E,tau,p=.1):
 w=np.zeros((len(E),len(E)))
 for m,y,b,a in np.ndindex(len(E),len(E),2,2):
  w[m,y]+=(1-p if b==a else p)*np.trace((E[m] if a==0 else I-E[m])@tau[y,b]).real
 z=w.sum(axis=1);return w/z[:,None],z,w

def classical():
 A=.9;r=.9;s=.1
 x=2*r/(r*(A+1)+np.sqrt(r*r*(A+1)**2-4*A*r*(r-s)))
 D=np.zeros((2,3,2));D[0,0,1]=x;D[0,1,0]=1-x;D[1,2,0]=x;D[1,1,1]=1-x
 enc=[[0,0],[0,1],[1,1]];w=np.zeros((3,3))
 for m,y,b,c in np.ndindex(3,3,2,2):w[m,y]+=D[b,y,c]*(A if b==enc[m][c] else .1)
 z=w.sum(1);return w/z[:,None],z,w,{'x':x}
def rational():
 x=9/16;nx=3/5;nz=4/5;E=[I,0*I,(I+nx*sx+nz*sz)/2,(I-nx*sx+nz*sz)/2];tau=np.zeros((4,2,2,2));tau[0,0]=x*(I-sz)/2;tau[1,1]=x*(I+sz)/2
 for y,sign in [(2,1),(3,-1)]:
  for b in range(2):tau[y,b]=(1-x)*(I+sign*(-1)**b*sx)/4
 return (*contraction(E,tau),{'x':x,'nx':nx,'nz':nz})
def global_quantum():
 t=float(mp.findroot(lambda t:19600*t**3-27720*t**2+10449*t-729,(mp.mpf('.5'),mp.mpf('.51'))))
 x=10*t/9;T=1-x;r=10*t/(9*(1-t));z=(r-2*x)/2;a=np.sqrt(T*T-z*z)
 traces=[x,x,T,T];u=[x,-x,0,0];ds=[np.array([0.,x]),np.array([0.,x]),np.array([a,z]),np.array([-a,z])];tau=np.zeros((4,2,2,2));E=[I,0*I]
 for m in range(4):
  for b in range(2):
   tb=(traces[m]+(-1)**b*u[m])/2;v=(-1)**b*tb*ds[m]/traces[m];tau[m,b]=(tb*I+v[0]*sx+v[1]*sz)/2
  if m>=2:
   n=ds[m]-t*np.array([0.,r]);n/=np.linalg.norm(n);E.append((I+n[0]*sx+n[1]*sz)/2)
 return (*contraction(E,tau),{'success_root':t,'x':x,'r':r,'z':z})
def capacity(W):
 p=np.ones(len(W))/len(W)
 for iteration in range(200000):
  q=p@W;D=np.sum(W*np.log(np.maximum(W,1e-300)/q),axis=1);lo=p@D;hi=max(D)
  if hi-lo<1e-13:break
  v=p*np.exp(D-max(D));p=v/v.sum()
 # high precision primal/dual arithmetic on displayed float channel, not rigorous channel interval
 wm=[[mp.mpf(str(v)) for v in row] for row in W];wm=[[v/sum(row) for v in row] for row in wm]
 pm=[mp.mpf(str(v)) for v in p];pm=[v/sum(pm) for v in pm];qm=[sum(pm[i]*wm[i][j] for i in range(len(pm))) for j in range(len(wm[0]))]
 div=[sum(v*mp.log(v/qm[j],2) for j,v in enumerate(row) if v) for row in wm]
 low=sum(pm[i]*div[i] for i in range(len(pm)));high=max(div)
 return {'input_distribution':list(map(float,pm)),'output_distribution':list(map(float,qm)),'mutual_information_lower_bits':str(low),'information_radius_upper_bits':str(high),'gap_bits':str(high-low),'iterations':iteration,'precision_caveat':'80-digit bounds for the rounded channel; numerical evaluation, not interval certificate for original algebraic matrices.'}
results={}
for name,f in [('classical_M3_optimal_minimax',classical),('quantum_M4_rational_witness',rational),('quantum_M4_optimal_minimax',global_quantum)]:
 W,z,w,params=f();assert np.min(W)>0 and np.max(abs(W.sum(1)-1))<1e-14
 # direct two-copy factorization check, every 2-symbol input/output
 residual=0
 for m,n in np.ndindex(len(W),len(W)):
  raw=np.outer(w[m],w[n]);normalized=raw/raw.sum();residual=max(residual,float(np.max(abs(normalized-np.outer(W[m],W[n])))))
 results[name]={'channel_rows_input_columns_output':W.tolist(),'normalizers':z.tolist(),'parameters':params,'two_copy_factorization_max_residual':residual,'capacity':capacity(W)}
p=mp.mpf('.1');C=1+p*mp.log(p,2)+(1-p)*mp.log(1-p,2)
results['direct_BSC_baseline']={'capacity_bits':str(C),'teleportation_quantum_rate_per_backward_use':str(C/2),'forward_identity_uses_needed_per_backward_use':str(C/2)}
Path(__file__).with_name('asymptotic_bridge_results.json').write_text(json.dumps(results,indent=2))
for k,v in results.items():print(k, v.get('capacity',v))
