import json,itertools
from pathlib import Path
from fractions import Fraction as F
root=Path(__file__).parent
results=json.loads((root/'results.json').read_text());upper=json.loads((root/'rational_upper_certificates.json').read_text());out=[]
for row,u in zip(results,upper):
 p,q,k=F(str(row['p'])),F(str(row['q'])),row['k'];enc=row['winning']['encoder']
 D=[]
 for b in range(2):
  v=[max(0,round(x*10**12)) for pair in row['winning']['decoder'][b] for x in pair];D.append([F(x,sum(v)) for x in v])
 w=[[F(0) for h in range(k)] for m in range(k)]
 for m,h,b,c,d in itertools.product(range(k),range(k),range(2),range(2),range(2)):
  w[m][h]+=D[b][2*h+c]*(1-q if d==c else q)*(1-p if b==enc[m][d] else p)
 lower=min(w[m][m]/sum(w[m]) for m in range(k));hi=F(u['upper_success'])
 assert 0<hi-lower<F(2,10**6)
 out.append({'p':str(p),'q':str(q),'k':k,'lower':str(lower),'upper':str(hi),'interval_width':str(hi-lower),'encoder':enc,'decoder':[[str(x) for x in v] for v in D]})
(root/'rational_lower_certificates.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'cases':len(out),'maximum_interval_width':float(max(F(x['interval_width']) for x in out))},indent=2))
