"""Numerical independent contractions; supplementary evidence, not symbolic proof."""
import itertools,json
import numpy as np
from four_message import candidate,solve_class,F

def check_decoder(p,q):
 A=1-p;t=candidate(p,q);D=np.zeros((2,4,2))
 if q<A/(2*(A+1)):
  enc=[F[0],F[0],F[1],F[2]];u=(2*t-A)/p;v=t/A;z=1-u-v
  D[0,0,1]=D[0,1,1]=.5;D[1,0,0]=D[1,1,0]=u/2;D[1,2,0]=v;D[1,3,1]=z
 else:
  enc=[F[0],F[0],F[1],F[1]];D[0,0,0]=D[0,1,0]=D[1,2,0]=D[1,3,0]=.5
 assert D.min()>-1e-12 and np.max(abs(D.sum(axis=(1,2))-1))<1e-12
 values=[]
 for m in range(4):
  w=np.zeros(4)
  for b,h,c,d in itertools.product(range(2),range(4),range(2),range(2)):
   w[h]+=D[b,h,c]*((1-q) if d==c else q)*((1-p) if b==enc[m][d] else p)
  values.append(w[m]/sum(w))
 assert abs(min(values)-t)<1e-11
 return values
if __name__=='__main__':
 checks=[]
 for p,q in [(.03,.01),(.16,.15),(.3,.2),(.37,.05),(.46,.17),(.49,.4)]:
  t=candidate(p,q);v=max(solve_class(p,q,ts)[0] for ts in itertools.combinations_with_replacement(range(4),4))
  assert abs(t-v)<1e-7
  checks.append(dict(p=p,q=q,formula=t,enumerated_lp=v,achieved=check_decoder(p,q)))
 for p in np.linspace(.005,.495,30):
  for q in np.linspace(0,.5,31):check_decoder(p,q)
 print(json.dumps({'all_multiset_checks':checks,'direct_decoder_contractions':930},indent=2))
