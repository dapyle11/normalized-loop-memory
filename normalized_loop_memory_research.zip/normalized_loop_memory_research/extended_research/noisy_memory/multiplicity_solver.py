"""Complete polynomial-size enumeration for fixed one-bit architecture.
Four deterministic encoder types; local stochastic decoders fully included.
"""
import itertools,json,math
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from fractions import Fraction as F
FUNCS=((0,0),(1,1),(0,1),(1,0))
def multiplicities(M):
 for a in range(M+1):
  for b in range(M-a+1):
   for c in range(M-a-b+1):yield (a,b,c,M-a-b-c)
def coeffs(p,q,mult,exact=False):
 ids=[i for i,n in enumerate(mult) if n];k=len(ids)
 zero=F(0) if exact else 0.
 den=[[zero for j in range(4*k)] for i in ids];num=[[zero for j in range(4*k)] for i in ids]
 for i,typ in enumerate(ids):
  for b,h,c in itertools.product(range(2),range(k),range(2)):
   v=sum((1-q if d==c else q)*(1-p if b==FUNCS[typ][d] else p) for d in range(2))
   den[i][(b*k+h)*2+c]=v
   if i==h:num[i][(b*k+h)*2+c]=v/mult[typ]
 return den,num,ids

def solve(p,q,M,steps=25):
 best=0.;winner=None
 for mult in multiplicities(M):
  den,num,ids=coeffs(p,q,mult);den=np.array(den);num=np.array(num);k=len(ids);nv=4*k
  eq=np.zeros((2,nv));eq[0,:2*k]=1;eq[1,2*k:]=1
  def lp(t):return linprog(np.zeros(nv),A_ub=t*den-num,b_ub=np.zeros(k),A_eq=eq,b_eq=[1,1],bounds=(0,None),method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
  r=lp(best)
  if not r.success:continue
  lo=best;hi=1/max(mult);x=r.x
  for _ in range(steps):
   t=(lo+hi)/2;r=lp(t)
   if r.success:lo=t;x=r.x
   else:hi=t
  x=np.maximum(x,0).reshape(2,-1);x/=x.sum(axis=1)[:,None];x=x.ravel()
  val=float(min((num@x)/(den@x)))
  if val>best:best=val;winner={'multiplicities':mult,'decoder':x.reshape(2,k,2).tolist(),'encoder_type_ids':ids}
 return dict(p=p,q=q,M=M,success=best,winning=winner,enumerated_multiplicities=math.comb(M+3,3))

def certify(row):
 p,q,M=F(str(row['p'])),F(str(row['q'])),row['M'];t=F(math.ceil((row['success']+2e-8)*10**6),10**6);cert=[]
 for mult in multiplicities(M):
  den,num,ids=coeffs(p,q,mult,True);k=len(ids);nv=4*k
  G=[[num[i][j]-t*den[i][j] for j in range(nv)] for i in range(k)]
  eq=np.zeros((2,nv+1));eq[0,:2*k]=1;eq[1,2*k:nv]=1
  rr=linprog(np.r_[np.zeros(nv),-1],A_ub=np.c_[-np.array(G,dtype=float),np.ones(k)],b_ub=np.zeros(k),A_eq=eq,b_eq=[1,1],bounds=[(0,None)]*nv+[(None,None)],method='highs')
  assert rr.success
  raw=[max(0,round(float(-v)*10**12)) for v in rr.ineqlin.marginals];alpha=[F(v,sum(raw)) for v in raw]
  beta=[max(sum(alpha[i]*G[i][j] for i in range(k)) for j in range(b*2*k,(b+1)*2*k)) for b in range(2)]
  assert sum(beta)<0,(M,mult,t,sum(beta))
  cert.append(dict(multiplicities=mult,alpha=list(map(str,alpha)),beta=list(map(str,beta))))
 mult=row['winning']['multiplicities'];den,num,ids=coeffs(p,q,mult,True);x=[]
 for b in range(2):
  vals=[max(0,round(v*10**12)) for pair in row['winning']['decoder'][b] for v in pair];x.extend(F(v,sum(vals)) for v in vals)
 lower=min(sum(a*b for a,b in zip(n,x))/sum(a*b for a,b in zip(d,x)) for n,d in zip(num,den))
 assert 0<t-lower<F(2,10**6)
 return dict(p=str(p),q=str(q),M=M,upper=str(t),lower=str(lower),winning_multiplicities=mult,decoder=list(map(str,x)),certificates=cert)
if __name__=='__main__':
 rows=[];certs=[]
 for M in [2,3,4,5,6,8,10]:
  row=solve(.1,.1,M);rows.append(row);certs.append(certify(row));print(M,row['success'],row['winning']['multiplicities'],flush=True)
 root=Path(__file__).parent
 (root/'multiplicity_results.json').write_text(json.dumps(rows,indent=2));(root/'multiplicity_certificates.json').write_text(json.dumps(certs,indent=2))
