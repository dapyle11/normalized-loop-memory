import numpy as np,itertools
from scipy.optimize import linprog
F=[(0,0),(1,1),(0,1),(1,0)]
def solve_class(p,q,types):
 k=len(types);enc=[F[t] for t in types];n=4*k
 N=np.array([[1-p,p],[p,1-p]]);L=np.array([[1-q,q],[q,1-q]])
 den=np.zeros((k,n));num=den.copy();eq=np.zeros((2,n))
 for b in range(2):eq[b,b*2*k:(b+1)*2*k]=1
 for m,b,h,c in itertools.product(range(k),range(2),range(k),range(2)):
  j=(b*k+h)*2+c;den[m,j]=sum(L[d,c]*N[b,enc[m][d]] for d in range(2))
  if h==m:num[m,j]=den[m,j]
 lo=0.;hi=1.;x=None
 for _ in range(40):
  t=(lo+hi)/2;res=linprog(np.zeros(n),A_ub=t*den-num,b_ub=np.zeros(k),A_eq=eq,b_eq=np.ones(2),bounds=(0,None),options={'primal_feasibility_tolerance':1e-9})
  if res.success:lo=t;x=res.x
  else:hi=t
 return lo,x.reshape(2,k,2)
if __name__=='__main__':
 for ts in itertools.combinations_with_replacement(range(4),4):
  v,x=solve_class(.1,0,ts);print(ts,round(v,9))

def candidate(p,q):
 A=1-p;s=p+q-2*p*q;r=1-s
 if q>=A/(2*(A+1)):return A/2
 B=(A+1)*(r-s);C=A*(r-s)+(A+1)*r+2*A*p*s
 return 2*A*r/(C+np.sqrt(C*C-4*B*A*r))
