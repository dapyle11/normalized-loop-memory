# Standalone certificate verifier: Python standard library only; no optimizer.
import json,itertools
from fractions import Fraction as F
from pathlib import Path
rows=json.loads((Path(__file__).parent/'rational_upper_certificates.json').read_text())
count=0
for row in rows:
 p,q,t,k=F(row['p']),F(row['q']),F(row['upper_success']),row['k']
 expected=set(itertools.product(tuple(itertools.product(range(2),repeat=2)),repeat=k))
 seen=set()
 for cert in row['certificates']:
  enc=tuple(tuple(e) for e in cert['encoder']);seen.add(enc)
  alpha=list(map(F,cert['alpha']));beta=list(map(F,cert['beta']))
  assert all(a>=0 for a in alpha) and sum(alpha)==1
  for b,h,c in itertools.product(range(2),range(k),range(2)):
   weighted=F(0)
   for m in range(k):
    den=sum((1-q if d==c else q)*(1-p if b==enc[m][d] else p) for d in range(2))
    weighted+=alpha[m]*den*((1 if h==m else 0)-t)
   assert weighted<=beta[b]
  assert sum(beta)<0
  count+=1
 assert expected==seen
print(json.dumps({'parameter_cases':len(rows),'verified_exact_rational_upper_certificates':count,'all_encoders_covered':True},indent=2))
