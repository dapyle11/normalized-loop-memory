# Bounded bridge from one-use conditional statistics to asymptotic rates

AI-generated mathematical research note; not independently human reviewed. No novelty, global-capacity or physical-device claim is made.

## Conclusion
**There is a valid coding bridge and a certified rate-oriented witness that improves over direct BSC coding when its assisting forward memory is charged.** The three earlier minimum-error-optimal gadgets individually underperform direct BSC coding, but a different classical protocol retaining its raw early output achieves I=.5558516340843477… >.5310044064107188… bits/use. Exact bounds prove I>.55 and gain>.02. See `rate_witness.md` and `rate_witness_verify.py`. For identity forward qubit memory, an explicitly charged teleportation extension also gives a legitimate quantum-rate lower-bound point for the specialization of Ji–Lloyd–Wilde Eq. (13). None of these are global capacity claims. Moreover, the published classical block strategy time-shared with direct coding already approaches 1.16385046 bits/use at the same **average** forward-bit rate one. Our compact witness improves only the ignore-memory baseline under its stricter independent one-bit-per-inner-use architecture, not the known broader asymptotic frontier.

This assessment is restricted to independent repetitions of fixed one-use gadgets followed by ordinary classical coding. It neither optimizes all protocols nor solves the published asymptotic noisy-memory tradeoff.

## 1. Exact tensor-product identity despite message-dependent normalization
Fix a one-use classical-message protocol, classical or quantum internally, with nonnegative loop weights w_m(y) and Z_m=Σ_yw_m(y)>0. Let

P(y|m)=w_m(y)/Z_m.

Run n independent copies, with no inter-copy encoding/decoding beyond choosing an input sequence and later classically processing the early outputs. The prescribed tensor-product P-CTC contraction gives unnormalized weight

w_(m^n)(y^n)=∏_(i=1)^n w_(m_i)(y_i).

Therefore

Z_(m^n)=∏_i Z_(m_i),
P(y^n|m^n)=∏_i P(y_i|m_i).

This is an algebraic identity, not an assumption of input-independent normalizers. Consequently, for each fixed classical codeword the conditional statistics are exactly a DMC. A deterministic encoder selecting codewords and a classical decoder acting on y^n use no additional forward communication.

For a code message j and deterministic codeword f(j), processing the output by g gives normalized success equal to that of the ordinary DMC code. Shannon coding below C(P)=max_pi I_pi(M;Y), followed if necessary by expurgation, gives maximum conditional decoding error tending to zero without asymptotic rate loss. The codebook is fixed in advance and built into the local maps; it is not a retained random seed.

**Important limitation:** averaging over an external random input before globally postselecting generally changes its prior by factors Z_(m^n). We do not claim the nonlinear map preserves arbitrary classical source distributions. The valid coding statement is worst-case conditional error for every fixed message, matching the classical communication criterion used in the motivating P-CTC framework.

Thus the established resource statement is, in the declared product-use model,

<backward N> + <forward L> ≥ C(P)[c←c]

in the usual closure sense (all rates strictly below C(P)). The output is **classical bits**, not qubits. The one-forward-use charge is exact for our fixed gadgets.

## 2. Computed DMC capacities
`asymptotic_bridge.py` directly contracts the full transition matrices, not just their diagonal correct probabilities. It examines:

1. the globally minimax-optimal classical three-message gadget at p=.1,q=0;
2. the rational four-message one-qubit witness at p=.1,epsilon=0, x=9/16, (n_x,n_z)=(3/5,4/5);
3. the globally minimax-optimal four-message one-qubit construction at p=.1,epsilon=0, whose worst-case success is the cubic root s*=.5060544271048905… .

Blahut–Arimoto iteration supplies an input distribution pi. For q_y=Σ_m pi_mP(y|m), the usual primal/dual bounds are

I_pi(M;Y) ≤ C(P) ≤ max_m D(P(.|m)||q).

The upper bound follows for every input law rho from I_rho=Σ_m rho_mD(P_m||q)−D(rho P||q). Thus it does not depend on the optimizer converging to the correct support.

| Fixed one-use gadget | DMC capacity, bits per backward use | Approximate maximizing input law |
|---|---:|---|
| Classical M3 minimax optimum | .458554694020 | (.392651,.214698,.392651) |
| Quantum M4 rational witness | .298689978606 | (.5,.5,0,0) |
| Quantum M4 minimax optimum | .298574589640 | (.5,.5,0,0) |
| Direct BSC(.1), ignoring memory | **.531004406411** | (.5,.5) |

The numerical primal/dual gaps are below 1.5×10^−13 for the represented transition matrices, reevaluated with 80-digit arithmetic. These are **numerical evaluations of rounded algebraic matrices**, not formal interval certificates for the original algebraic channels. Full matrices, normalizers, distributions, gaps, and two-copy factorization checks are saved in `asymptotic_bridge_results.json`. The rate differences from the direct baseline are much larger than numerical errors, but no new exact-capacity theorem is inferred from those decimal values.

A useful diagnostic is that maximizing minimum diagonal success and maximizing Shannon mutual information are different objectives. The globally minimax-optimal four-message quantum gadget has slightly *lower* DMC capacity than the rational witness. Its maximizing classical input distribution effectively discards the two nonconstant quantum-encoder symbols. The one-shot quantum advantage does not establish an asymptotic classical or quantum advantage.

## 3. A valid quantum-rate bridge when the forward channel is identity
Eq. (13) of the motivating paper asks for a quantum output rate Q. Classical coding alone does not establish that. For the specific epsilon=0 case, the forward channel is a noiseless **qubit** identity, so we may explicitly add forward uses to distribute entanglement and then teleport.

Take an n-use maximum-error classical code for the fixed gadget, able to carry 2k Bell-outcome bits with maximum conditional error δ_n→0. In the past, prepare k Bell pairs and send one half of each to the future through **k additional identity-qubit uses**. The future sender Bell-measures the k-qubit input against those halves and encodes the resulting 2k classical bits with the n-use gadget code. The past receiver decodes the Bell outcomes and corrects its retained halves. The gadget's own n forward-memory systems are separate from these k Bell halves; the teleportation quantum input is not silently fed into the classical-message gadget.

Here is why message-dependent Z does not invalidate this particular construction. Let b label the 4^k Bell outcomes, and let W(bhat|b) denote the unnormalized classical block-code weight; Σ_bhat W(bhat|b)=Z_b. The Bell outcomes have probability 1/4^k independent of the teleported input, including any reference entangled with it. Before final normalization, the corrected quantum map is

(1/4^k) Σ_(b,bhat) W(bhat|b) U_(bhat)^†U_b rho U_b^†U_(bhat).

Its trace is (1/4^k)Σ_b Z_b, independent of rho. The normalized map is therefore a genuine mixture of unitary corrections. Since W(b|b)≥(1−δ_n)Z_b for **every** b, its total identity-correction weight is at least 1−δ_n even though the Bell outcomes are postselection-reweighted. Fidelity with every original pure state/reference is at least this identity weight. Thus maximum quantum infidelity tends to zero. More strongly, the normalized channel has diamond-norm distance at most 2δ_n from the identity. The Bell outcomes are uniform before conditioning, not after it; the weighted argument is essential. The algebraic bridge and resource count were separately checked in this AI-assisted research process.

The resource ledger is

n backward BSC uses,
n forward identity-qubit uses for the gadget,
k additional forward identity-qubit uses for Bell halves,
k reliably returned qubits.

Consequently, for every Q<C(P)/2 this yields the legitimate restricted-case quantum resource lower bound at R=1+Q (or any larger available R). **This is not a distinct new quantum-rate result:** Ji–Lloyd–Wilde Supplemental Strategy 1 already uses L1≅M and L2≅B, hence the same R=1+Q memory accounting. For BSC(.1) their construction achieves every Q<(1/2)log2(9) at that charge; the quantum point obtained here is already included. See the explicit attribution in `rate_witness.md`. No free ebits, extra retained classical seed, or late laboratory acceptance flags are assumed.

For a forward resource that is **only a classical bit channel**, these Bell halves cannot be sent. The same argument then establishes only classical communication, not Eq. (13)'s quantum output. Likewise, this note does not replace the identity channel with an arbitrary noisy quantum channel using its ordinary quantum capacity: errors in approximate entanglement distribution can interact with global postselection, and that requires a separate robustness argument. Our quantum bridge is deliberately limited to exact identity forward memory.

## 4. Direct baseline versus minimax gadgets, and a rate-oriented improvement
Ignore the gadget memory and encode directly into the backward BSC. With the encoder independent of the earlier output there is no causal feedback dependence; the normalized classical channel is exactly BSC(p), with capacity

C0=1−H2(p).

At p=.1, C0=.5310044064107188… . Applying the same teleportation construction requires only the forward Bell-half uses, giving

Q<C0/2=.2655022032053594…,
R=Q,

and, more generally, the closure lower bound Q≥min(R,C0/2) for this explicit family of protocols with an identity forward qubit resource. The inequality means the optimal attainable rate is at least that value; strictly smaller rates are operationally attained before taking closure.

By comparison, the gadget bridges yield Q below approximately .2292773470, .1493449893, or .1492872948, while requiring R=1+Q. Hence the direct baseline dominates all three calculated bridges. This comparison applies only to those three fixed minimax gadgets; it is not an upper bound on other classical-memory protocols.

A subsequent bounded search supplied a different explicit classical protocol, with early raw output (b,c) and only c forwarded, achieving I=.5558516340843477… . Its exact matrix, input law, resource ledger, and rational logarithm certificate are in `rate_witness.md`. Constant-composition codes with counts (n/2,n/3,n/6) make every codeword normalizer exactly (3/5)^(n/6), eliminating even the code-message prior-reweighting issue. An ordinary forward heralded simulation instead succeeds only with probability (5/9)^n(3/5)^(n/6) per attempted block; the rate is per hypothetical P-CTC use, not per laboratory attempt, and no earlier-accessible herald is assumed. Thus at one charged forward bit per backward use it achieves a classical rate .55, strictly above direct BSC coding. With identity forward qubits and the additional Bell-half charge, it yields the quantum point (R,Q)=(1.275,.275), because 2Q=.55<I. This point exceeds the direct-BSC-plus-teleportation baseline rate ceiling but uses more forward resources; crucially, it is already implied by Ji–Lloyd–Wilde Supplemental Strategy 1 and is not a distinct quantum-rate contribution. It does not establish optimality or quantum-over-classical memory advantage.

A stronger **known** block construction is already available: Ji–Lloyd–Wilde Supplemental Strategy 2 stores h and b^n, achieving any C1<log2(9) at forward cost 1+C1. Deterministically time-sharing it with zero-forward-memory direct coding yields C1(1+C0)/(1+C1) at average forward rate one, approaching 1.16385046338… bits/use. Thus our .5558516 witness is not an improvement over existing broader asymptotic rate bounds. `rate_witness.md` gives the explicit specialization and resource distinction.

The existence of still stronger block-adaptive, coherent, higher-dimensional, or jointly optimized protocols is not excluded. Nor does this calculation establish an upper bound on the general classical or quantum asymptotic capacity.

## 5. Primary sources and novelty caution
- Ji, Lloyd, Wilde, [*Retrocausal Capacity of a Quantum Channel: Communicating Through Noisy Closed Timelike Curves*, Eq. (2), classical criterion, and Eq. (13)](https://arxiv.org/html/2509.08965v3): the motivating hypothetical-resource framework and noisy-memory question.
- Shannon, [*A Mathematical Theory of Communication* (1948)](https://onlinelibrary.wiley.com/doi/10.1002/j.1538-7305.1948.tb01338.x): discrete-channel capacity/coding foundation. The max-error step here additionally uses elementary expurgation: retain at least half the codewords with error at most twice the average.
- Bennett et al., [*Teleporting an Unknown Quantum State via Dual Classical and Einstein–Podolsky–Rosen Channels* (1993)](https://doi.org/10.1103/PhysRevLett.70.1895): teleportation with an entangled pair and two classical bits.

The product normalization identity and explicit postselection-aware teleportation check above are calculations for our declared model. No novelty or physical backward-signalling claim is made. Ordinary forward laboratory postselection cannot send its later herald to the past; the resource interpretation here continues to assume the hypothetical backward channel.
