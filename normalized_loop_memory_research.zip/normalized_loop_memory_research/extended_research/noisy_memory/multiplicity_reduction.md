# Complete finite-M method using encoder multiplicities

This extends the same explicitly declared one backward BSC(p)/one forward BSC(q), classical local-stochastic architecture. It does not change its free resources or add shared memory.

## Reduction theorem
For M messages, deterministic-encoder sufficiency leaves four encoder functions f_i∈{C0,C1,I,N}. Let n_i≥0 be the number of messages assigned to type i, with Σ_i n_i=M. Up to message relabeling there are exactly binomial(M+3,3) such multiplicity vectors, instead of 4^M labeled encoder tuples.

For fixed multiplicities, symmetrize decoder message labels within each type. Their kernels and denominators are identical, so each becomes the average of their original success probabilities and no group's worst success decreases. The decoder can now be described by aggregate probabilities D(i,c|b), with i restricted to occupied types. Individual messages of group i get 1/n_i of that group's correct loop weight.

Define K_i(b,c)=Σ_d L_q(d|c)N_p(b|f_i(d)). With aggregate decoder,

Z_i=Σ_(b,h,c)D(h,c|b)K_i(b,c),
W_i=Σ_(b,c)D(i,c|b)K_i(b,c),
S_i=W_i/(n_i Z_i).

At target t the complete constraints are

W_i−n_i t Z_i≥0,
D≥0, Σ_(i,c)D(i,c|b)=1.

These are linear. Conversely, any feasible aggregate decoder expands into a valid original decoder by splitting each group's output probability equally among its n_i labels. Therefore this is an exact equivalence, not a relaxation.

There are at most four occupied types and hence at most sixteen decoder variables, independent of M. Enumerating O(M³) multiplicities and bisecting target t yields a complete finite algorithm (polynomial in the numerical value M, not necessarily in log M). This is an application of elementary permutation symmetrization and linear-fractional feasibility, not a novel optimization method claim.

## Exact certificates
`multiplicity_solver.py` implements this reduction. Its constraints divide correct group coefficients by n_i, equivalently using S_i≥t. Rational dual certificates and rationalized feasible decoder witnesses bracket each optimum. `verify_multiplicity_certificates.py` independently recomputes both with standard-library Fraction arithmetic and checks full composition coverage, without importing a numerical solver.

For p=q=.1, the following results are certified within 1.1×10^−6:

| M | Optimal success (rounded) | A winning multiplicity (C0,C1,I,N) |
|---:|---:|---|
|2|.90000000|(1,1,0,0)|
|3|.64410774|(1,1,0,1)|
|4|.45881958|(1,2,0,1)|
|5|.39383212|(2,2,1,0)|
|6|.32205387|(2,2,2,0)|
|8|.24704049|(3,3,0,2)|
|10|.19691606|(4,4,2,0)|

M=2,3,4 agree with the earlier full labeled enumeration. A multiplicity vector listed here is a certified near-optimal witness, not necessarily the unique global maximizer. Exact rational intervals are in `multiplicity_certificates.json`; verification counts and maximum width are in `../reference_results/multiplicity_verification.json`.

This supplies an exact finite-dimensional computational characterization for every finite message count in the declared one-bit architecture. It is not a symbolic closed form for every M, an asymptotic multi-channel-use theorem, or a solution of the published quantum memory-rate tradeoff.
