# No numerical solver or third-party imports.
from fractions import Fraction as F
from pathlib import Path
import json,itertools,math
fun=((0,0),(1,1),(0,1),(1,0))
def coeff(p,q,mult):
 ids=[i for i,n in enumerate(mult) if n];k=len(ids);den=[[F(0) for j in range(4*k)] for i in ids];num=[[F(0) for j in range(4*k)] for i in ids]
 for i,typ in enumerate(ids):
  for b,h,c in itertools.product(range(2),range(k),range(2)):
   v=sum((1-q if d==c else q)*(1-p if b==fun[typ][d] else p) for d in range(2));j=(b*k+h)*2+c
   den[i][j]=v
   if i==h:num[i][j]=v/mult[typ]
 return den,num
rows=json.loads((Path(__file__).parent/'multiplicity_certificates.json').read_text());count=0;maxwidth=F(0)
for row in rows:
 p,q,t,M=F(row['p']),F(row['q']),F(row['upper']),row['M'];seen=set()
 for c in row['certificates']:
  mult=tuple(c['multiplicities']);assert all(n>=0 for n in mult) and sum(mult)==M;seen.add(mult)
  den,num=coeff(p,q,mult);alpha=list(map(F,c['alpha']));beta=list(map(F,c['beta']));k=len(alpha)
  assert sum(alpha)==1 and min(alpha)>=0 and sum(beta)<0
  for b in range(2):
   for j in range(b*2*k,(b+1)*2*k):assert sum(alpha[i]*(num[i][j]-t*den[i][j]) for i in range(k))<=beta[b]
  count+=1
 assert len(seen)==math.comb(M+3,3)
 den,num=coeff(p,q,row['winning_multiplicities']);x=list(map(F,row['decoder']));assert min(x)>=0
 k=len(num);assert sum(x[:2*k])==sum(x[2*k:])==1
 lo=min(sum(a*b for a,b in zip(n,x))/sum(a*b for a,b in zip(d,x)) for n,d in zip(num,den))
 assert lo==F(row['lower']) and 0<t-lo<F(2,10**6);maxwidth=max(maxwidth,t-lo)
print(json.dumps({'cases':len(rows),'exact_upper_certificates':count,'exact_lower_witnesses':len(rows),'all_multiplicities_covered':True,'maximum_interval_width':float(maxwidth)},indent=2))
