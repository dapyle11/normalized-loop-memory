# Four messages with one noisy classical forward bit

Work in the classical one-use model defined in `symbolic_three_message_theorem.md`, with four rather than three messages and no additional resources. Put A=1−p, s=p+q−2pq, r=1−s. Assume 0<p<1/2, 0≤q≤1/2. The four deterministic encoder functions are C0,C1,I,N. A decoder-label group has mass equal to the sum of its probabilities over both b rows, so all groups' masses sum to 2.

## Exact theorem and exceptional encoder class

Define q_c=A/[2(A+1)]. For q<q_c let T be the unique solution in (A/2,A/(A+1)) of

(A−(A+1)T)[r−(r−s)T]=2ApsT.                 (1)

For q≥q_c the global value is A/2. The exclusions below prove this value globally optimal over all allowed stochastic protocols.

Choose encoder multiset {C0,C0,C1,I}, with repeated C0 labels interchangeable. At b=0 output the repeated C0 group with c=1, splitting equally between its two labels. At b=1 use:

* repeated C0 group, c=0, total probability u=(2T−A)/p, split equally;
* C1, c=0, probability v=T/A;
* I, c=1, probability z=1−u−v.

Then each repeated C0 succeeds with (A+pu)/2=T, C1 succeeds with Av=T, and I succeeds with rz/[2s+(r−s)z]=T by (1). All probabilities are nonnegative: the defining intersection is between the decreasing affine function z(t)=[A−(A+1)t]/(Ap), and the positive increasing function 2st/[r−(r−s)t]. At t=A/(A+1) the former is zero. At t=A/2 it is 1/2, and the identity success is r/(r+3s). This exceeds A/2 exactly when q<q_c. Thus there is a unique intersection in (A/2,A/(A+1)), with u,v,z≥0, precisely in the claimed improvement phase. At q=q_c the construction remains valid with u=0,v=z=1/2.

For q≥q_c, direct encoding of two messages as 0 and two as 1, decoded equiprobably within the relevant pair, achieves A/2 while ignoring forward memory.

### Upper bound for the exceptional class

Suppose all four successes are at least t>A/2. Let x_b be repeated-C0 decoder mass in row b, let X=x_0+x_1, Y be C1 total mass, Z be I total mass. The two repeated messages together require A x_0+p x_1≥2t. Since x_0≤1,

X≥1+(2t−A)/p.

C1 success≤AY, giving Y≥t/A. Hence

Z≤2−X−Y≤1−(2t−A)/p−t/A=z(t).

The identity's correct weight is at most rZ and incorrect weight at least s(2−Z). Therefore its success is at most rz(t)/[2s+(r−s)z(t)], and t cannot exceed the intersection T. When q≥q_c the intersection is no greater than A/2, excluding every t>A/2. Bit and message relabelings cover all repeated-constant/opposite-constant/bijection classes.

## Exclusions for other multiplicities

Every encoder loop coefficient is in [p,A]. Thus a label group of total decoder mass X has group success at most

f(X)=AX/[AX+p(2−X)].                      (2)

It is strictly increasing and f(1)=A. Identical-encoder labels have a common denominator, so k such labels each succeeding at least t require group success at least kt.

* **4 identical:** success≤1/4<A/2.
* **2+2:** if t>A/2, each pair needs group success>A and hence mass>1 by (2), impossible.
* **3+1:** if p≤1/6, 3A/2≥1, making t>A/2 impossible for the repeated group. If p>1/6, at even t=A/2 the two groups require masses at least 6p/(6p−1) and 2p/(1+2p). Their sum minus 2 is 2(1−2p)/[(1+2p)(6p−1)]>0, a contradiction. (This inverse bound applies uniformly to all encoder types.)

## Other 2+1+1 classes

* **Repeated constant plus I,N:** t>A/2 implies repeated-constant group mass X>1 by (2). The I and N denominators sum to 2 since their pointwise loop coefficients sum to 1. Their combined correct numerators must therefore be at least 2t>A, whereas those numerators are at most r(2−X)<r≤A. Contradiction.
* **Repeated bijection plus both constants:** its group success is at most rX/[rX+s(2−X)], which at X=1 equals r≤A. Thus t>A/2 forces X>1. Each constant singleton requires mass at least t/A, so the two singletons together require mass>1. Contradiction.
* **Repeated bijection plus opposite bijection and one constant:** it suffices to prove the bound at q=0. Any fixed-encoder protocol at q>0 can be simulated at q=0 by privately flipping the decoder's output memory bit with probability q, without changing its output label or the encoder. Thus this class's optimum cannot increase with q. Canonically the class is {C0,I,I,N}. At q=0 write N_b=A for b=0 and p for b=1, and K=K_I(b,c)∈{p,A}; K_N=1−K. Assign dual weights λ_C0=λ_N=2p and λ_each_I=(1+2p)/2. The weighted denominator sum for each column is 2pN_b+2p+K. At target t=A/2, the maximum weighted success-minus-target column for either an I label or the N label is β_b=pA(1/2−N_b). The maximum C0 column differs from β_b by 2p(N_b−A)≤0. Thus every column is bounded by β_b, while β_0+β_1=0. Summing against normalized decoder rows proves the upper bound. All weights and message denominators are positive, so any simultaneous strict improvement would contradict that bound.

## All four encoder functions distinct

An exact dual bound gives optimum Ar/(A+r)≤A/2. Assign positive weights λ_C0=λ_C1=r/A and λ_I=λ_N=1. For every decoder column, the weighted denominator sum is 1+r/A, and the correct weighted coefficient is at most r. Hence weighted success-minus-target columns are nonpositive at target Ar/(A+r); summing proves the bound. It is attainable by letting x=r/(A+r) and y=A/(A+r): in each row b give total mass x to C_b with c uniformly random, and mass y/2 to each bijection label, choosing c=b for I and c=1−b for N. Every denominator equals 1, constant success is Ax, bijection success ry.

## Stable explicit expression

In the improvement phase put B=(A+1)(r−s) and C=A(r−s)+(A+1)r+2Aps. Then

T=2Ar/[C+sqrt(C²−4BAr)].

For example p=.1 gives T=.4653307872377213 at q=0 and .4588195769439971 at q=.1; the exact threshold is q_c=9/38. For p=.25 it is q_c=3/14.

## Status and scope

Equation (1), its explicit achieving decoder, threshold, exceptional-class upper bound, and stated other-class exclusions are symbolic. `four_message.py` is an LP exploration helper and formula implementation, not a proof. `four_message_check.py` contracts the achieving decoder on a 930-point grid and compares the theorem against all 35 encoder multisets at six additional parameter points; reference results are in `../reference_results/four_message_checks.json`. These floating-point checks supplement, rather than establish, the symbolic proof. Together these cover every multiset of four encoder functions and prove the global theorem. No novelty claim or physical backward-signalling interpretation is intended. This does not address quantum memory or asymptotic capacity.
