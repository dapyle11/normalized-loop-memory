# Sensor-inclusive quantum completion: exact boundary and reproducible checks

**Status (2026-10-30): resolved within standard quantum causal order.** This is an explicit illustrative quantum sensor, not a new theorem, not experimental evidence, and not a physical completion of Schulman's hidden magnetic-action proposal. It closes the question whether simply adding a conventional weak or strong quantum sensor to the earlier spin can produce a full-trial backward channel: it cannot. Selected statistics can and do depend on the later analyzer.

The underlying instrument/channel framework is standard; see John Preskill, [Quantum Information, Chapter 3](https://www.preskill.caltech.edu/ph219/chap3_15.pdf), especially sections 3.1.2 and 3.2. The formulas, implementation and bounded regression checks below are our explicit construction in that framework.

## 1. Timeline and physical scope

1. Prepare spin S in the same state rho=|+x><+x|=(I+X)/2 every trial and pointer P in |0>. Here X,Y,Z are Pauli operators; lower-case x is the later analyzer angle, not a preparation setting.
2. Couple S and P unitarily, measure P, and create the irreversible classical record R. A missing-record category is itself retained. All preparation and sensor controls are independent of the future setting.
3. Only after that record exists, independently intervene on analyzer angle x. Apply optional ordinary noise and the analyzer measurement, retaining both outcomes and no-detection.
4. Never rewrite the historical record or define the original trial list using a future outcome. Later storage corruption would be a different observable, not a change to an immutable earlier readout.

The pointer below measures spin Z with tunable precision. It is **not a measurement of a hidden rotation K, magnetic amplitude B, or integrated field action**. Identifying it with any such quantity requires a separate calibrated Hamiltonian and field/sensor dynamics. This completion cannot supply that missing mapping by notation.

## 2. Explicit spin–pointer unitary and instrument

Choose measurement strength 0<=eta<=1 and beta=arccos(eta). Write Ry(a)=exp(-ia Y/2). On two qubits define

    U = |0><0|_S tensor Ry(beta)_P
      + |1><1|_S tensor Ry(pi-beta)_P.

This is manifestly unitary. One generating, finite-time Hamiltonian is

    H = (hbar/(2 tau)) [beta |0><0| + (pi-beta)|1><1|]_S tensor Y_P,

acting for tau, ignoring other terms by definition of this mathematical model. It is an ordinary controllable conditional rotation, not an asserted laboratory implementation. Measuring pointer Z with outcomes r=+1 for |0> and r=-1 for |1> induces

    M_r = <r|_P U |0>_P = sqrt[(I+r eta Z)/2],
    J_r(rho) = M_r rho M_r^dagger,
    sum_r M_r^dagger M_r = I.

Thus the nonselected sensor map is CPTP. At eta=0 it obtains no spin information and causes no spin disturbance; at eta=1 it is projective Z measurement. Intermediate eta is an unsharp/weak measurement. For general input, the nonselected map multiplies X and Y Bloch components by c=sqrt(1-eta^2), leaving Z unchanged. Therefore nonzero coupling's actual backaction is retained, rather than assuming an unchanged spin trajectory.

For the fixed preparation chosen above,

    J_r(rho) = [I+c X+r eta Z]/4,
    p(r)=1/2,
    rho_{S|r}=[I+c X+r eta Z]/2.

This explains how early records can correlate with later results without their frequencies depending on the later setting.

## 3. Early readout noise, missing outcomes, and later noise

Let e in [0,1/2] be the probability of flipping the classical sensor bit and d in [0,1] the early-record erasure probability. These parameters do not depend on x. For observable records b=+1,-1,? define the subnormalized states

    A_b=(1-d)[(1-e)J_b(rho)+e J_{-b}(rho)], b=+1,-1,
    A_?=d[J_+(rho)+J_-(rho)].

The erasure here means the sensor interacted but its record was unavailable, not that the interaction was omitted. Importantly, these states sum to the same nonselected sensor output. Then apply depolarizing noise

    D_lambda(A)=(1-lambda)A+lambda Tr(A)I/2, 0<=lambda<=1.

This map is linear on subnormalized branches and CPTP. Let analyzer direction n_x=(sin x,0,cos x), visibility 0<=v<=1, and effects E_y(x)=[I+y v n_x dot sigma]/2. With outcome-dependent detection efficiencies k_+,k_- in [0,1], define

    F_+=k_+ E_+, F_-=k_- E_-, F_empty=I-F_+-F_-.

All are positive and sum to I, including for setting-dependent efficiencies. Each has a valid CP operation with Kraus operator sqrt(F), so this is a genuine full quantum instrument rather than just a normalized probability table. The complete joint law is

    p(b,y|do x)=Tr[F_y(x) D_lambda(A_b)], y=+,-,empty.

Exactly,

    sum_y p(b,y|do x)=Tr(A_b)
      = (1-d)/2 for b=+1,-1; d for b=?.

This is independent of x, e, lambda, visibility, and both late efficiencies. Arbitrary additional CPTP dynamics can change the joint law but not this earlier marginal.

## 4. Analytic selected statistics

Without losses/erasures, but retaining bit-flips and depolarization, put a=v(1-lambda). Then

    p(b,y|x) = [1+y a(c sin x+b(1-2e)eta cos x)]/4.

When d>0, multiply these b=+/- entries by 1-d and add the missing branch. When k_y<1, multiply detected outcome entries by k_y and put the balance in the no-detection category.

Set the numerical record T(+)=1, T(-)=-1, T(?)=0. Conditioning on a detected plus outcome, when its probability is nonzero,

    E[T|x,Y=+] = (1-d)(1-2e)a eta cos x / [1+a c sin x].

The efficiency k_+ cancels from this conditional statistic (if nonzero); it does not eliminate selection. At x=0 versus pi this equals plus/minus (1-d)(1-2e)a eta, while the full-trial E[T|do x] stays zero. These settings reverse an oriented analyzer and swap its ideal outcome meanings, illustrating why outcome selection is decisive. Other angles likewise give different conditional means; at pi/2 the mean is zero.

For example eta=.6 and no noise give selected means +.6 and -.6. With e=.1,d=.2,lambda=.25,v=.7 they become +.2016 and -.2016. In both cases the full record marginal is unchanged; in the noisy case it is (.4,.4,.2). For k_+=.8 the plus-selection probability is .4 at x=0 and pi in both examples: **even equal acceptance rates do not remove the selection effect**.

This is retrodictive conditioning, not access to future labels in the past. The related established distinction between forward state estimation and a state estimate incorporating future measurement results is treated by Gammelmark, Julsgaard and Mølmer, [Past quantum states](https://arxiv.org/abs/1305.0681), Phys. Rev. Lett. 111, 160401 (2013). That paper is context, not evidence for backward communication.

## 5. General theorem: arbitrary sensor disturbance and memory

Let rho include every system, environment and quantum memory needed. The early instrument {J_r} is independent of the later intervention, with sum_r J_r trace-preserving; r is stored in an immutable classical register. Allow the later setting x to choose any instrument {E_{y|x,r}}, possibly even controlled by r, with its nonselected sum E_{x,r} trace-preserving on each branch. Then

    p(r|do x)=sum_y Tr[E_{y|x,r}(J_r(rho))]
             =Tr[E_{x,r}(J_r(rho))]
             =Tr[J_r(rho)].

This proves invariance, including arbitrary early backaction, entanglement, losses, discarded outcomes, and multiple later adaptive stages whose total maps remain trace-preserving. A reduced spin-only CP assumption may fail with initially correlated environments; including the environment in the system avoids that unnecessary assumption. The trace identity itself needs only trace preservation; complete positivity ensures the maps are quantum-valid on entangled extensions. An observational association with x chosen adaptively from r is not p(r|do x).

Equivalent Heisenberg statement: E_{x,r}^dagger(I)=I, so the future unselected effect is the identity. In the stored classical-quantum state sum_r |r><r| tensor J_r(rho), every historical label retains its weight. A later operation that physically overwrites the record register does not retroactively alter its historical value and is outside the immutable-readout comparison.

## 6. Exactly what would have to change?

For a selected CP operation G_x whose effect Q_x=G_x^dagger(I) obeys 0<=Q_x<=I, the normalized selected law is

    p(r|x,selected)=Tr[Q_x J_r(rho)] / sum_s Tr[Q_x J_s(rho)].

It can vary with x; ordinary QM includes the complementary rejected operation, restoring the invariant full ensemble. Non-TP selection is not sufficient by itself to produce variation: Q_x proportional to I cancels. Nor is a global boundary law necessarily signaling: it can satisfy no-signaling constraints.

A genuine all-trial dependence, if preparation independence, late intervention, immutable recording and exhaustive trial accounting are all secured, **cannot be represented by the above future CPTP instruments**. A model could stipulate a future-dependent earlier ensemble, a nonstandard global boundary law, or a physically deterministic version of normalized trace-decreasing evolution. Those are additional operational assumptions requiring a consistent intervention and sensor theory; none follows from this pointer construction. In practice selection, setting precursors, drift/common causes, record corruption, and misspecified trial accounting also violate premises without exotic physics. Therefore an apparent deviation does not uniquely imply either non-TP fundamental dynamics or a global boundary theory.

## 7. Numerical verification and stopping boundary

Run `python model.py` (Python 3, NumPy). This writes `results.json`. Checks include:

- Unitarity of the two-qubit dilation and its exact Kraus blocks.
- Sensor strength eta=0,.01,.1,.3,.6,.9,1; bit flips 0,.1,.5; erasure 0,.2,1; depolarization 0,.25,1; analyzer visibility 0,.7,1; 17 analyzer angles; late efficiencies (1,1),(.8,.3),(0,0).
- Full probability positivity, normalization, all three earlier marginal categories, and the analytic selected-mean formula.
- 100 random earlier instruments and ten random later instruments each on a four-dimensional spin+environment with entangled Bell input, checking all 3 early branches (3,000 trace identities). QR-generated isometries enforce Kraus completeness.

**Executed result:** PASS for 28,917 grid cases; maximum full-marginal numerical error 3.3306690738754696e-16. All 3,000 generic trace identities passed, maximum error 4.441136804871019e-16 (NumPy 2.3.5). `py_compile` also passed.

All values are illustrative, not estimates of achievable laboratory parameters. Exact matrix arithmetic here means deterministic floating-point evaluation of finite matrices, not symbolic or infinite-precision arithmetic. The analytic proof, not a grid or random test, covers the continuous parameter ranges and general maps.

**Stopping condition reached:** the standard-QM sensor branch is mathematically closed. More chosen strengths, noise simulations or generic sensors cannot evade trace preservation. The remaining Schulman-specific issue is a justified sensor-inclusive field/history law with calibration and intervention semantics, or relevant calibrated physical data. This toy pointer does not produce it. No equipment or experiment was used or authorized.
