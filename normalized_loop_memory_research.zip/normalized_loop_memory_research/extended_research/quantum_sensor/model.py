"""Exact finite-dimensional instrument checks; no fitted physical parameters."""
import json
from pathlib import Path
import numpy as np
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex); Z=np.diag([1,-1]).astype(complex)
rho=(I+X)/2

def ry(a):
    return np.array([[np.cos(a/2),-np.sin(a/2)],[np.sin(a/2),np.cos(a/2)]],complex)

def early(eta,flip,missing):
    beta=np.arccos(eta)
    U=np.kron(np.diag([1,0]),ry(beta))+np.kron(np.diag([0,1]),ry(np.pi-beta))
    assert np.allclose(U.conj().T@U,np.eye(4))
    blocks=[]
    for r,j in [(1,0),(-1,1)]:
        M=U[j::2,0::2]
        target=np.diag(np.sqrt((1+r*eta*np.array([1,-1]))/2))
        assert np.allclose(M,target)
        blocks.append(M@rho@M.conj().T)
    a,b=blocks
    return [(1-missing)*((1-flip)*a+flip*b),(1-missing)*((1-flip)*b+flip*a),missing*(a+b)]

def joint(eta,flip,missing,depol,visibility,angle,effplus,effminus):
    states=early(eta,flip,missing)
    n=np.sin(angle)*X+np.cos(angle)*Z
    effects=[effplus*(I+visibility*n)/2,effminus*(I-visibility*n)/2]
    effects.append(I-effects[0]-effects[1])
    assert all(np.linalg.eigvalsh(F).min()>-1e-12 for F in effects)
    p=np.array([[np.trace(F@((1-depol)*s+depol*np.trace(s)*I/2)).real for F in effects] for s in states])
    assert p.min()>-1e-12 and abs(p.sum()-1)<1e-12
    return p

maxerr=0.; rows=[]; cases=0
for eta in [0,.01,.1,.3,.6,.9,1]:
 for flip in [0,.1,.5]:
  for missing in [0,.2,1]:
   for depol in [0,.25,1]:
    for visibility in [0,.7,1]:
     for angle in np.linspace(0,2*np.pi,17):
      for ep,em in [(1,1),(.8,.3),(0,0)]:
       p=joint(eta,flip,missing,depol,visibility,angle,ep,em)
       err=np.max(np.abs(p.sum(axis=1)-np.array([(1-missing)/2]*2+[missing])))
       maxerr=max(maxerr,float(err)); cases+=1
for eta in [0,.1,.6,1]:
 for flip,missing,depol,visibility in [(0,0,0,1),(.1,.2,.25,.7)]:
  for angle in [0,np.pi/2,np.pi]:
   p=joint(eta,flip,missing,depol,visibility,angle,.8,.3)
   denom=p[:,0].sum()
   conditional=float((p[0,0]-p[1,0])/denom) if denom>1e-14 else None
   analytic=(1-missing)*(1-2*flip)*(1-depol)*visibility*eta*np.cos(angle)/(1+(1-depol)*visibility*np.sqrt(1-eta**2)*np.sin(angle))
   assert conditional is None or abs(conditional-analytic)<1e-12
   rows.append(dict(eta=eta,flip=flip,missing=missing,depol=depol,visibility=visibility,angle=float(angle),early_marginal=p.sum(axis=1).tolist(),late_plus_probability=float(denom),selected_record_mean=conditional))

# Arbitrary instruments on S+E (dimension four), including entangled input.
# QR isometry gives Kraus operators whose adjoint products sum to identity.
rng=np.random.default_rng(20261030)
def instrument(d,k):
    z=rng.normal(size=(k*d,d))+1j*rng.normal(size=(k*d,d))
    q,_=np.linalg.qr(z)
    ks=list(q.reshape(k,d,d))
    assert np.allclose(sum(K.conj().T@K for K in ks),np.eye(d))
    return ks
bell=np.array([1,0,0,1],complex)/np.sqrt(2); entangled=np.outer(bell,bell.conj())
genericerr=0.
for trial in range(100):
    A=instrument(4,3); states=[K@entangled@K.conj().T for K in A]
    for setting in range(10):
        B=instrument(4,5)
        for s in states:
            after=sum(L@s@L.conj().T for L in B)
            genericerr=max(genericerr,float(abs(np.trace(after)-np.trace(s))))
assert maxerr<1e-12 and genericerr<1e-12
out=dict(status='PASS',numpy_version=np.__version__,grid_cases=cases,max_full_marginal_error=maxerr,generic_cases=3000,max_generic_trace_error=genericerr,representative_cases=rows)
Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='representative_cases'},indent=2))
