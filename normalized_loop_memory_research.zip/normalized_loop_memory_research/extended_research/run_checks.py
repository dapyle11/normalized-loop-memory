"""Reproduce mathematical checks, not a physical time-travel experiment.

Default: exact saved classical certificates, branch simulations and exact
quantum witness checks. --certificates-only needs only Python's standard
library. --full also reruns the independent LP-based adversarial regressions.
Exploratory nonconvex search and original full LP generation are opt-in, manual.
"""
from pathlib import Path
import argparse
import json
import math
import os
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def compare(reference, actual, path='root'):
    if isinstance(reference, bool) or reference is None:
        assert reference == actual, (path, reference, actual)
    elif isinstance(reference, (int, float)):
        assert isinstance(actual, (int, float)), (path, type(actual))
        assert math.isclose(reference, actual, rel_tol=1e-8, abs_tol=1e-9), (path, reference, actual)
    elif isinstance(reference, dict):
        assert reference.keys() == actual.keys(), (path, 'keys differ')
        for key in reference:
            compare(reference[key], actual[key], f'{path}.{key}')
    elif isinstance(reference, list):
        assert len(reference) == len(actual), (path, 'lengths differ')
        for i, (x, y) in enumerate(zip(reference, actual)):
            compare(x, y, f'{path}[{i}]')
    else:
        assert reference == actual, (path, reference, actual)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--certificates-only', action='store_true')
    parser.add_argument('--full', action='store_true')
    args = parser.parse_args()
    if args.certificates_only and args.full:
        parser.error('Choose either --certificates-only or --full, not both.')
    steps = ['noisy_memory/verify_certificates.py',
             'noisy_memory/verify_lower_witnesses.py',
             'noisy_memory/verify_multiplicity_certificates.py',
             'quantum_memory/verify_scalar_certificates.py',
             'quantum_memory/finite_alphabet_independent_verify.py',
             'noisy_memory/rate_witness_verify.py']
    comparisons = []
    if not args.certificates_only:
        steps += ['noisy_memory/family_check.py', 'quantum_sensor/model.py',
                  'final_state/replicate.py', 'quantum_memory/rational_witness_verify.py',
                  'quantum_memory/verify_interval.py', 'quantum_memory/audit_exact.py',
                  'quantum_memory/verify_heralding.py', 'quantum_memory/global_bound_verify.py', 'quantum_memory/general_scalar_bound.py', 'quantum_memory/m3_scalar_bound.py',
                  'quantum_memory/m3_no_advantage_verify.py',
                  'quantum_memory/m3_no_advantage_independent_verify.py',
                  'quantum_memory/finite_alphabet_oracle.py', 'noisy_memory/asymptotic_bridge.py']
        comparisons = [('quantum_sensor/results.json', 'quantum_sensor_results.json'),
                       ('final_state/results.json', 'final_state_results.json'),
                       ('quantum_memory/rational_witness_certificates.json', 'quantum_memory_rational_witness_certificates.json'),
                       ('quantum_memory/interval_certificate.json', 'quantum_memory_interval_certificate.json'),
                       ('quantum_memory/audit_exact_results.json', 'quantum_memory_audit_exact_results.json'),
                       ('quantum_memory/heralding_certificates.json', 'quantum_memory_heralding_certificates.json'),
                       ('quantum_memory/global_bound_certificate.json', 'quantum_memory_global_bound_certificate.json'),
                       ('quantum_memory/general_scalar_certificates.json', 'quantum_memory_general_scalar_certificates.json'),
                       ('quantum_memory/m3_scalar_certificates.json', 'quantum_memory_m3_scalar_certificates.json'),
                       ('quantum_memory/m3_no_advantage_certificate.json', 'quantum_memory_m3_no_advantage_certificate.json'),
                       ('quantum_memory/m3_no_advantage_independent_certificate.json', 'quantum_memory_m3_no_advantage_independent_certificate.json'),
                       ('quantum_memory/finite_alphabet_certificates.json', 'quantum_memory_finite_alphabet_certificates.json'),
                       ('quantum_memory/finite_alphabet_independent_certificate.json', 'quantum_memory_finite_alphabet_independent_certificate.json'),
                       ('noisy_memory/asymptotic_bridge_results.json', 'asymptotic_bridge_results.json'),
                       ('noisy_memory/rate_witness_certificate.json', 'rate_witness_certificate.json')]
    if args.full:
        steps += ['noisy_memory/verify_symbolic_regression.py',
                  'noisy_memory/verify_four_message_regression.py',
                  'noisy_memory/four_message_check.py']
    logs = ROOT / 'generated_checks'
    logs.mkdir(exist_ok=True)
    report = {'physical_experiment': False, 'all_passed': False, 'steps': []}
    for script in steps:
        print(f'Running {script}', flush=True)
        start = time.monotonic()
        result = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                                env={**os.environ, 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'},
                                text=True, capture_output=True)
        log_name = script.replace('/', '__') + '.log'
        (logs / log_name).write_text(result.stdout + '\n' + result.stderr)
        report['steps'].append({'script': script, 'exit_code': result.returncode,
                                'seconds': round(time.monotonic()-start, 3), 'log': log_name})
        (logs / 'run_summary.json').write_text(json.dumps(report, indent=2)+'\n')
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
        print(f'PASS {script}', flush=True)
    for output, reference in comparisons:
        expected = json.loads((ROOT/'reference_results'/reference).read_text())
        actual = json.loads((ROOT/output).read_text())
        if output == 'noisy_memory/asymptotic_bridge_results.json':
            # This branch contains decimal strings from high-precision numerical
            # arithmetic on rounded matrices, not exact rational certificates.
            # Iteration counts can differ across compatible floating-point stacks.
            def numerical(value):
                if isinstance(value, dict):
                    return {k: numerical(v) for k, v in value.items() if k != 'iterations'}
                if isinstance(value, list):
                    return [numerical(v) for v in value]
                if isinstance(value, str) and re.fullmatch(r'[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?', value):
                    return float(value)
                return value
            expected, actual = numerical(expected), numerical(actual)
        compare(expected, actual, output)
        print(f'PASS reference comparison {output}', flush=True)
    report['all_passed'] = True
    report['reference_comparisons'] = [x[0] for x in comparisons]
    (logs / 'run_summary.json').write_text(json.dumps(report, indent=2)+'\n')
    print('All selected checks passed. These are mathematics and simulations, not physical backward communication.')


if __name__ == '__main__':
    main()
