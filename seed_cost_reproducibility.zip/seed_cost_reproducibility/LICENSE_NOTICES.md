# License notices

This package does not create a new software license or alter the license of earlier repository material. No third-party source code is vendored. The author's usual manuscript-license preference is CC BY 4.0; selecting that license for a submission or public deposit remains an author action and does not automatically license the companion software. External literature is cited, not redistributed.
