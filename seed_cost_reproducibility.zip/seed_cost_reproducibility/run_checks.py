#!/usr/bin/env python3
"""Run all included checks; --exact-only avoids third-party dependencies."""
import argparse,hashlib,json,platform,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--exact-only',action='store_true');args=p.parse_args()
checks=['check_constructions_independent.py','verify_finite_k_m3_certificates.py','verify_finite_k_m3_independent.py']
if not args.exact_only:checks.insert(0,'check_seed_resources.py')
(root/'results').mkdir(exist_ok=True)
records=[]
for name in checks:
 r=subprocess.run([sys.executable,str(root/'code'/name)],cwd=root/'code',capture_output=True,text=True)
 (root/'results'/(name+'.stdout.txt')).write_text(r.stdout+r.stderr)
 records.append({'script':name,'returncode':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout.encode()).hexdigest()})
 print(name+(': PASS' if r.returncode==0 else ': FAIL'),flush=True)
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
report={'status':'all passed','exact_only':args.exact_only,'python':sys.version,'platform':platform.platform(),'checks':records}
(root/'results'/('exact_run.json' if args.exact_only else 'full_run.json')).write_text(json.dumps(report,indent=2)+'\n')
print('All requested checks passed.')
