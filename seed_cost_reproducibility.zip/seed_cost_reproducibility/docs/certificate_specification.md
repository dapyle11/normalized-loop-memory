# Exact two-seed classical benchmark: M=3, p=q=1/10

31 October 2026. Computer-assisted finite optimization proof in the stipulated normalized-loop model. This is not a complete finite-K tradeoff, not a quantum two-seed upper bound, and not a physical communication protocol. Originality remains unassessed.

## Result

For M=3 messages, a backward BSC(p) and a classical forward BSC(q), both p=q=1/10, with at most two raw shared-seed values, the optimal worst-message normalized success is exactly

    T2 = (3895-sqrt(1237585))/3776
       = 0.7368993704800834... .

The unrestricted-seed optimum is 45/59=0.7627118644067797..., so the loss from allowing at most two seed values rather than the three required for exact optimality is approximately 0.0258124939266963 (2.5812494 percentage points).

The upper bound uses a complete finite enumeration and exact certificates. The numerical optimization used to discover certificates is not trusted by the verifier. `verify_finite_k_m3_certificates.py` checks the result using only integer/Fraction arithmetic and exact arithmetic in Q(sqrt(1237585)); no numerical optimizer, floating-point arithmetic, NumPy, SciPy, or SymPy is used by this verifier.

## 1. Fixed-K deterministic encoders suffice

Let a_s,m(c) be the encoder's binary response for received forward bit c, message m and seed s. Initially allow stochastic responses e_s,m,c in [0,1]. For any fixed decoder and raw seed probabilities and any target success t, feasibility is the family of inequalities C_m-t Z_m>=0, one for each message. Each surplus is linear in every encoder response coordinate e_s,m,c, and a coordinate for one message appears in no other message's inequality. Choosing each coordinate to maximize its own linear contribution gives a deterministic response in {0,1} and never decreases any surplus. Therefore any feasible target can be achieved with deterministic encoders, without increasing K or changing the decoder.

For three messages, each seed has 4^3=64 deterministic profiles, one of the four functions (a(0),a(1)) per message. Encode the function by 2a(0)+a(1): types 0,1,2,3 are constant zero, identity, bit flip, constant one. Swapping seed names does not affect performance, so all K<=2 protocols are covered by the 64*65/2=2,080 unordered profile pairs, including identical profiles and zero-probability seeds.

## 2. Decoder feasibility as a linear system

For fixed encoder profiles P_s, write

    x_s,b,y,d = pi_s D_s(y,d|b) >=0,

where b is the backward output observed by the decoder, y its guessed message, and d its transmitted forward input bit. The shared raw-seed condition imposes

    sum_y,d x_s,0,y,d = sum_y,d x_s,1,y,d = pi_s,
    sum_s pi_s=1.

Define the exact rational coefficient

    W_s,m,b,d = sum_c BSC_q(c|d) BSC_p(b|a_s,m(c)).

Then C_m=sum_s,b,d x_s,b,m,d W_s,m,b,d and Z_m=sum_s,b,y,d x_s,b,y,d W_s,m,b,d. At a fixed rational t the success constraints C_m-tZ_m>=0 and all decoder constraints are linear with rational coefficients.

A floating LP search found the candidate and useful dual multipliers. The final certificate checks do not assume that the LP solver or its reported feasibility/infeasibility was correct.

## 3. Exact lower construction

Take two seeds with probabilities

    x=(1271-sqrt(1237585))/256,
    y=1-x.

They are strictly between zero and one. The first seed is a pair code on messages 0 and 2. It outputs message0 and forward bit1 when b=0, and message2 and forward bit0 when b=1. Its encoder profile is (0,1,3). The second is a singleton code on message1: it outputs message1 with forward bit1 when b=0 and forward bit0 when b=1. Its encoder profile is (1,2,1).

Set A=9/10, k=4/5, delta=4/5, b=k delta=16/25 and l=1-b=9/25. Pair messages have success A x/(l+b x). The singleton message has success (1+b)y/(l+2b y). Substitution gives both equal to T2. Equivalently T2 is the smaller root of

    1888 T2^2 -3895 T2 +1845=0.

The verifier checks these identities exactly in the quadratic field and checks positivity of the probabilities.

## 4. General upper certificate for a fixed profile pair

Choose nonnegative message multipliers mu_m summing to one. For a target t define

    g_s,b,y,d = sum_m mu_m (t-1[y=m]) W_s,m,b,d.

Then every legal decoder satisfies

    sum_m mu_m(t Z_m-C_m)
      = sum_s,b,y,d g_s,b,y,d x_s,b,y,d
      >= sum_s pi_s [min_y,d g_s,0,y,d + min_y,d g_s,1,y,d]
      >= min_s [min_y,d g_s,0,y,d + min_y,d g_s,1,y,d].

If the final quantity is strictly positive, no decoder for those profiles can attain success at least t for all messages. All these checks use exact Fractions when t and mu are rational.

For the winning profiles ((0,1,3),(1,2,1)), take t=T2 and multipliers (x/2,y,x/2). Exact quadratic-field calculation shows every g_s,b,y,d>=0, so no protocol with these profiles can have success strictly greater than T2 on every message. All mu are positive. Together with Section3, this proves the winner's exact value.

## 5. Complete coverage and exact exclusion of competitors

The BSC contraction is invariant under simultaneous relabeling of the forward bits c,d, simultaneous relabeling of backward bits a,b, a global permutation of the three message labels, and swapping the two seeds. Forward and backward relabelings may be chosen independently for each seed. These transformations map legal protocols bijectively to legal protocols and preserve all message success probabilities up to their relabeling.

Among the 2,080 unordered profile pairs, 24 lie in the winning profile's orbit under these symmetries. The exact winning certificate covers them all. This orbit is explicitly enumerated, not assumed from its size.

For each of the other 2,056 profile pairs, `finite_k_m3_exact_certificates.json` supplies rational multipliers mu whose certificate in Section4 has a strictly positive bound at

    t0=7368993/10000000=0.7368993 < T2.

The standalone verifier independently reconstructs the profile list, orbit, channel coefficients, minima and rational inequalities; checks no pair is duplicated or missing; and verifies all certificates. Thus every nonwinning profile has value strictly below t0, and no omitted randomized encoder can improve the result by Section1. This establishes the stated global classical K<=2 optimum.

## Included verification files

The complete data are in `code/finite_k_m3_exact_certificates.json`. Run `code/verify_finite_k_m3_certificates.py` and `code/verify_finite_k_m3_independent.py`; both use only standard-library exact arithmetic. The optional discovery and generation scripts require the pinned numerical packages. The manuscript gives the same proof with consistent notation and bibliography.

This benchmark concerns classical BSC forward memory only. It does not determine the qubit two-seed value or a general intermediate-seed frontier. Independent human review and originality assessment remain pending.
