# Verification report

31 October 2026. All recorded checks passed. Exact arithmetic establishes the finite certificate inequalities; numerical tests support, but do not establish, the general analytic theorems.

| Check suite | Recorded coverage | Arithmetic |
| --- | --- | --- |
| Main seed-resource constructions | 1434 cases | Exact rational |
| Entropy values of explicit constructions | 114 cases | Floating point |
| Sampled fractional matching vertices | 1000 LP objectives | Numerical |
| Independent construction implementation | 672 cases, M=3 through 30 | Exact rational |
| Independent erasure-channel contraction | 16 cases | Exact rational |
| Classical two-seed finite benchmark | All 2080 unordered deterministic encoder-profile pairs | Exact rational and quadratic field |
| Independent classical finite benchmark | Same 2080 pairs, independently reconstructed orbit and contraction | Exact rational and quadratic field |

The benchmark winner orbit has 24 profile pairs. Its exact upper and lower certificates lie in Q(sqrt(1237585)). Each of the 2056 remaining pairs has a rational strict exclusion certificate below the winning value. The certificate data and checkers are included in full. No optimizer success flag or floating-point tolerance is used by the exact verifiers.

The main analytic results were additionally read in separate AI proof-audit passes, including arbitrary decoder mixing, entropy minima, endpoints and the dimension counterexample. These are not independent human peer review. No originality guarantee or physical implementation claim follows from any check.

The supplied source compiles to a 13-page PDF; all pages were rendered and visually inspected. A clean extraction of the source-only ZIP was also rebuilt. New artifacts do not modify either earlier submitted manuscript.
