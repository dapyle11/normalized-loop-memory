# Shared randomness cost reproducibility package

Companion to **The Shared Randomness Cost of Optimal One Use Loop Communication**, Daniel A. Pyle, 31 October 2026.

This package contains editable LaTeX proofs, deterministic construction tests, exact certificate data and two separately implemented verifiers for the classical two-seed benchmark. It describes a stipulated mathematical loop; it is not a physical backward-communication implementation.

## Quick verification

Python 3.10 or newer is recommended. The exact certificate checks and the independent rational construction checks use only the standard library:

```sh
python3 run_checks.py --exact-only
```

For the complete construction/entropy/graph test suite, install the pinned packages in a virtual environment, then run:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 run_checks.py
```

The full run checks 1434 exact rational construction cases, 114 floating-point entropy values and 1000 numerical fractional-matching vertices. A separate implementation checks 672 rational constructions and 16 original erasure-channel contractions. Both exact finite-K verifiers cover all 2080 deterministic profile pairs: 24 winning symmetry-orbit cases plus 2056 rational exclusions. Repeated runs and two verifiers do not create additional distinct mathematical cases.

Numerical entropy evaluation and sampled LP vertices are consistency checks, not proofs. The general theorems are proved in `source/main.tex`. The finite-K theorem is computer-assisted: exact finite certificates, not numerical optimization, establish its upper bound. It applies only to the classical forward BSC at M=3, K<=2, p=q=1/10. No quantum fixed-K upper bound or complete frontier is claimed.

## Contents

- `source/main.tex`: complete self-contained manuscript with an embedded generated analytic plot and inline bibliography.
- `build_pdf.sh`: portable two-pass pdfLaTeX build; no external figure assets or bibliography program needed.
- `code/check_seed_resources.py`: exact constructions, floating-point entropy checks, sampled matching vertices.
- `code/check_constructions_independent.py`: independently implemented rational constructions and direct erasure contractions.
- `code/finite_k_m3_exact_certificates.json`: complete finite-K certificate data.
- `code/verify_finite_k_m3_certificates.py`: solver-free rational/quadratic-field verifier.
- `code/verify_finite_k_m3_independent.py`: second solver-free implementation, including direct primal contraction and independently enumerated symmetry orbit.
- `code/finite_k_m3.py`, `code/certify_finite_k_m3_exact.py`: optional numerical discovery and certificate-generation tools; not required to trust the supplied certificates.
- `code/make_figure.py`: regenerates and embeds the analytic plot from the stated formulas.
- `docs/certificate_specification.md`: finite-K proof and certificate design.
- `docs/verification_report.md`: scope and recorded check outcomes.
- `results/`: recorded fresh-run output and environment metadata.
- `SHA256SUMS`: hashes of the packaged files, excluding the manifest itself.

The packaged copies use reader-facing script/output names. Their mathematical test logic is unchanged from the checked research implementations. Running scripts creates or refreshes result files; verify the distribution manifest before running if byte-for-byte provenance is needed.

## Building the manuscript

With a standard TeX installation containing the packages named in `source/main.tex`, run:

```sh
bash build_pdf.sh
```

The output is `build/main.pdf`. The separate Hexagon source ZIP contains only `main.tex` and is the submission-source artifact; this larger archive is the reproducibility companion, not the source-only submission ZIP.

## Availability and review

The project repository is https://github.com/dapyle11/normalized-loop-memory and hosts related earlier work. This package is supplied for the author to review and upload; its presence in a public repository is not assumed. Lyra, an OpenAI AI assistant, performed derivation, drafting and verification in a workflow directed by Daniel A. Pyle. Separate AI checking passes are not human peer review. Independent human review and originality assessment remain pending.

No software license is newly granted by this package. See `LICENSE_NOTICES.md`.
