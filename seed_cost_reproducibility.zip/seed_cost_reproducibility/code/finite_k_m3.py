#!/usr/bin/env python3
"""M=3,K=2 classical BSC feasibility: numerical search, exact certificates."""
import itertools as it
from fractions import Fraction as F
from functools import lru_cache
import json, numpy as np
from scipy.optimize import linprog
from pathlib import Path
M=3;K=2;p=q=F(1,10)
# encoder type 2*a(c=0)+a(c=1)
profiles=list(it.product(range(4),repeat=M))
perms=list(it.permutations(range(M)))
# Relabel forward c,d simultaneously and backward a,b simultaneously.
def transform(P,fc,ab):
    out=[]
    for typ in P:
        bits=[typ//2,typ%2]
        b=[bits[c^fc]^ab for c in range(2)]
        out.append(2*b[0]+b[1])
    return tuple(out)
def localcanon(P):return min(transform(P,fc,ab) for fc,ab in it.product(range(2),repeat=2))
def canon(P,Q):
    return min(tuple(sorted([localcanon(tuple(P[i] for i in z)),localcanon(tuple(Q[i] for i in z))])) for z in perms)
allpairs=list(it.combinations_with_replacement(profiles,2))
reps=sorted(set(canon(P,Q) for P,Q in allpairs))
inds=list(it.product(range(K),range(2),range(M),range(2)))

def W(P,m,b,d):
    bits=[P[m]//2,P[m]%2]
    return sum((1-q if c==d else q)*(1-p if b==bits[c] else p) for c in range(2))
@lru_cache(None)
def rawrows(pair):
    return [[W(pair[s],m,b,d) for s,b,y,d in inds] for m in range(M)]
def lp(pair,t):
    rows=rawrows(pair)
    A=np.array([[float((t-(1 if y==m else 0))*rows[m][j]) for j,(s,b,y,d) in enumerate(inds)]+[1.] for m in range(M)])
    eq=np.zeros((3,25))
    for j,(s,b,y,d) in enumerate(inds):
        eq[s,j]=1 if b==0 else -1
        if b==0:eq[2,j]=1
    return linprog([0.]*24+[-1.],A_ub=A,b_ub=np.zeros(3),A_eq=eq,b_eq=[0,0,1],bounds=[(0,None)]*24+[(None,None)],method='highs')
def dual_verify(pair,t,mu):
    assert len(mu)==3 and all(z>=0 for z in mu) and sum(mu)==1
    g={}
    for j,(s,b,y,d) in enumerate(inds):
        g[s,b,y,d]=sum(mu[m]*(t-(1 if y==m else 0))*W(pair[s],m,b,d) for m in range(M))
    h=[min(g[s,1,y,d] for y in range(M) for d in range(2)) for s in range(K)]
    val=min(g[s,0,y,d]+h[s] for s in range(K) for y in range(M) for d in range(2))
    return val

def rational_mu(res,den=10**9):
    mu=[F(float(-v)).limit_denominator(den) for v in res.ineqlin.marginals]
    return [v/sum(mu) for v in mu]

if __name__=='__main__':
    roots=[]
    for pair in reps:
        lo=F(0);hi=F(45,59)
        for i in range(32):
            mid=(lo+hi)/2;res=lp(pair,mid)
            assert res.success
            if -res.fun>=-1e-10:lo=mid
            else:hi=mid
        roots.append((float((lo+hi)/2),pair))
    roots.sort(reverse=True)
    print('profiles',len(profiles),'all pairs',len(allpairs),'symmetry representatives',len(reps))
    print('top',roots[:10])
    best=roots[0][0];guess=F(best).limit_denominator(100000)
    print('best rational guess',guess,float(guess))
    out={'p':str(p),'q':str(q),'representatives':len(reps),'all_profile_pairs':len(allpairs),'best_numeric':best,'rational_guess':str(guess),'top_profiles':[{'value':v,'profiles':pr} for v,pr in roots[:10]]}
    Path(__file__).with_name('finite_k_m3_search.json').write_text(json.dumps(out,indent=2)+'\n')
