from fractions import Fraction as F
import math,json,itertools

def target(M,p,d):return 2*(1-p)/(M-(M-2)*(1-2*p)*d)
def pair_seeds(M):
    if M%2==0:return [(F(2,M),(i,i+1)) for i in range(0,M,2)]
    return [(F(1,M),(0,1)),(F(1,M),(1,2)),(F(1,M),(2,0))]+[(F(2,M),(i,i+1)) for i in range(3,M,2)]
def perfect_seeds(M):
    return [(F(2,M),(i,i+1)) for i in range(0,M-1,2)]+([] if M%2==0 else [(F(1,M),(M-1,))])
def evaluate(M,p,d,seeds):
    out=[]
    for m in range(M):
        numerator=F(0);denominator=F(0)
        for prob,labels in seeds:
            if len(labels)==2:
                n,z=((1-p),F(1)) if m in labels else (F(0),1-(1-2*p)*d)
            else:
                assert d==1
                n,z=(2*(1-p),2*(1-p)) if m in labels else (F(0),2*p)
            numerator+=prob*n;denominator+=prob*z
        out.append(numerator/denominator)
    return out

checks=0
for M in range(3,31):
 for p in [F(1,100),F(1,10),F(1,4),F(49,100)]:
  for d in [F(1,100),F(1,3),F(3,4),F(99,100)]:
   seeds=pair_seeds(M);assert sum(w for w,_ in seeds)==1
   assert all(s==target(M,p,d) for s in evaluate(M,p,d,seeds));checks+=1
  seeds=perfect_seeds(M)
  assert all(s==target(M,p,F(1)) for s in evaluate(M,p,F(1),seeds));checks+=1
  # delta0: explicit a,b distributions; each pair disjoint and each sums1.
  if M%2==0:
   r=M//2;a=[F(1,r) if j<r else F(0) for j in range(M)];b=[F(1,r) if j>=r else F(0) for j in range(M)]
   protocols=[(F(1),a,b)]
  else:
   r=M//2;a=[F(1,r) if j<r else F(0) for j in range(M)]
   b=[F(0) if j<r else F(1,M-1) if j in [r,r+1] else F(2,M-1) for j in range(M)]
   a2=[F(j==r) for j in range(M)];b2=[F(j==r+1) for j in range(M)]
   protocols=[(F(M-1,M),a,b),(F(1,M),a2,b2)]
  for w,a,b in protocols:
   assert sum(a)==sum(b)==1 and all(x*y==0 for x,y in zip(a,b))
  assert all(sum(w*(1-p)*(a[m]+b[m]) for w,a,b in protocols)==target(M,p,F(0)) for m in range(M));checks+=1

# Explicit five-output erasure example: direct contraction, not reduced weights.
extra=0
for p in [F(1,100),F(1,10),F(1,4),F(49,100)]:
 for c in [F(1,100),F(1,3),F(3,4),F(99,100)]:
  es=[[1,1,0,1,1],[1,0,1,1,1],[0,0,0,0,1],[0,0,0,1,0]]
  tau={}
  for y in range(4):
   b=0 if y<2 else 1
   sigma=[(1-c)/2]+[c/2 if x==y else F(0) for x in range(4)]
   tau[(y,b)]=sigma
  for m,E in enumerate(es):
   weights=[]
   for y in range(4):
    weight=F(0)
    for b in [0,1]:
     sigma=tau.get((y,b),[F(0)]*5)
     tr=sum(sigma);et=sum(x*z for x,z in zip(E,sigma))
     weight+=(1-p)*et+p*(tr-et) if b==0 else p*et+(1-p)*(tr-et)
    weights.append(weight)
   assert weights[m]/sum(weights)==target(4,p,c)
  extra+=1
print(json.dumps({'rational_construction_cases':checks,'M_range':[3,30],'direct_erasure_cases':extra,'status':'all passed'},indent=2))
