#!/usr/bin/env python3
"""Exact rational construction checks and graph LP sanity checks, not a proof."""
from fractions import Fraction as F
from math import log2
import json
from pathlib import Path

def weights_protocol(M,p,d,branches):
    # branches: (pi,kind,labels); a pair/loop uses diameter pair, zero lists q0,q1.
    A=1-p;k=1-2*p;l=1-k*d
    C=[F(0)]*M;Z=[F(0)]*M
    for pi,kind,data in branches:
        for m in range(M):
            if kind=='pair':
                active=m in data;c=A if active else F(0);z=F(1) if active else l
            elif kind=='loop':
                active=m==data;c=1+k*d if active else F(0);z=1+k*d if active else l
            elif kind=='zero':
                q0,q1=data;c=A*(q0[m]+q1[m]);z=F(1)
            C[m]+=pi*c;Z[m]+=pi*z
    return [c/z for c,z in zip(C,Z)],Z

def interior(M):
    if M%2==0:return [(F(2,M),'pair',(i,i+1)) for i in range(0,M,2)]
    return [(F(1,M),'pair',e) for e in [(0,1),(1,2),(2,0)]]+[(F(2,M),'pair',(i,i+1)) for i in range(3,M,2)]
def perfect(M):
    return [(F(2,M),'pair',(i,i+1)) for i in range(0,M-1,2)]+([(F(1,M),'loop',M-1)] if M%2 else [])
def zero(M):
    r=M//2;q0=[F(0)]*M;q1=[F(0)]*M
    for i in range(r):q0[i]=F(1,r)
    if M%2==0:
        for i in range(r,M):q1[i]=F(1,r)
        return [(F(1),'zero',(q0,q1))]
    q1[r]=q1[r+1]=F(1,2*r)
    for i in range(r+2,M):q1[i]=F(1,r)
    a=[F(0)]*M;b=[F(0)]*M;a[r]=b[r+1]=1
    return [(F(M-1,M),'zero',(q0,q1)),(F(1,M),'zero',(a,b))]

def entropy(bs):return -sum(float(b[0])*log2(float(b[0])) for b in bs)

checks=0
entropy_checks=0
for M in range(3,41):
    for p in [F(1,10),F(1,4),F(49,100)]:
        for d in [F(0),F(1,100),F(1,2),F(99,100),F(1)]:
            A=1-p;k=1-2*p;D=M-(M-2)*k*d;t=2*A/D
            vals,z=weights_protocol(M,p,d,interior(M));assert all(v==t for v in vals);checks+=1
            vals,z=weights_protocol(M,p,d,zero(M));assert all(v==2*A/M for v in vals)
            assert 1-min(vals)/t==(M-2)*k*d/M;checks+=1
            if M%2:
                vals,z=weights_protocol(M,p,d,perfect(M));assert min(vals)==(1+k*d)/D
                assert len(set(z))==1
                assert 1-min(vals)/t==k*(1-d)/(1+k);checks+=1
    h=log2(M)-1+(3/M if M%2 else 0)
    assert abs(entropy(interior(M))-h)<1e-12
    h=log2(M)-1+(1/M if M%2 else 0)
    assert abs(entropy(perfect(M))-h)<1e-12
    if M%2:
        x=1/M;h=-x*log2(x)-(1-x)*log2(1-x)
        assert abs(entropy(zero(M))-h)<1e-12
    else:assert entropy(zero(M))==0
    entropy_checks+=3

# Explicit M=4 erasure-channel contraction.
E=[[1,1,0,1,1],[1,0,1,1,1],[0,0,0,0,1],[0,0,0,1,0]]
for p in [F(1,10),F(1,4),F(49,100)]:
    for d in [F(1,100),F(1,2),F(99,100)]:
        C=[];Z=[]
        for m in range(4):
            weights=[]
            for y in range(4):
                b=0 if y<2 else 1
                e=(1-d)*E[m][0]+d*E[m][y+1]
                w=(p+(1-2*p)*e)/2 if b==0 else ((1-p)-(1-2*p)*e)/2
                weights.append(w)
            C.append(weights[m]);Z.append(sum(weights))
        assert all(c/z==2*(1-p)/(4-2*(1-2*p)*d) for c,z in zip(C,Z));checks+=1

# Numerically sample fractional matching vertices using linear objectives.
import numpy as np
from scipy.optimize import linprog
rng=np.random.default_rng(1977);lp_checks=0
for M in range(3,13):
    edges=[(i,j) for i in range(M) for j in range(i+1,M)]
    B=np.zeros((M,len(edges)))
    for e,(i,j) in enumerate(edges):B[i,e]=B[j,e]=1
    hmin=log2(M)-1+(3/M if M%2 else 0)
    kmin=M//2 if M%2==0 else (M+3)//2
    for _ in range(100):
        res=linprog(rng.normal(size=len(edges)),A_eq=B,b_eq=np.ones(M),bounds=(0,None),method='highs')
        assert res.success
        x=res.x[res.x>1e-8]
        assert np.max(np.minimum(abs(x-1),abs(x-.5)))<1e-7
        pi=2*x/M;h=-sum(pi*np.log2(pi))
        assert h>=hmin-1e-8 and len(x)>=kmin
        lp_checks+=1
out={'exact_construction_checks':checks,'floating_point_entropy_checks':entropy_checks,'fractional_matching_lp_vertex_checks':lp_checks,'status':'passed','scope':'Construction identities and graph numerical sanity, not independent proof or novelty review.'}
Path(__file__).with_name('seed_cost_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
