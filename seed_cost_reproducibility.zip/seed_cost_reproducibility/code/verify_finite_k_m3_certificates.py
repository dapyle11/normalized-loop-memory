#!/usr/bin/env python3
"""Standalone exact verifier: no NumPy, SciPy, LP, floating point or SymPy."""
from fractions import Fraction as F
from pathlib import Path
import itertools as it, json
D=1237585
class Q:
    def __init__(self,a=0,b=0):self.a=F(a);self.b=F(b)
    def __add__(self,o):
        if not isinstance(o,Q):o=Q(o)
        return Q(self.a+o.a,self.b+o.b)
    __radd__=__add__
    def __neg__(self):return Q(-self.a,-self.b)
    def __sub__(self,o):return self+-o if isinstance(o,Q) else self+Q(-o)
    def __rsub__(self,o):return Q(o)+-self
    def __mul__(self,o):
        if not isinstance(o,Q):o=Q(o)
        return Q(self.a*o.a+D*self.b*o.b,self.a*o.b+self.b*o.a)
    __rmul__=__mul__
    def sign(self):
        a,b=self.a,self.b
        if b==0:return (a>0)-(a<0)
        if a==0:return (b>0)-(b<0)
        if a>0 and b>0:return 1
        if a<0 and b<0:return -1
        diff=a*a-D*b*b
        assert diff!=0
        return ((diff>0)-(diff<0))*(1 if a>0 else -1)
    def zero(self):return self.a==0 and self.b==0
M=3;p=q=F(1,10)
profiles=list(it.product(range(4),repeat=3));pairs=list(it.combinations_with_replacement(profiles,2))
inds=list(it.product(range(2),range(2),range(3),range(2)))
def W(P,m,b,d):
    a=[P[m]//2,P[m]%2]
    return sum((1-q if c==d else q)*(1-p if b==a[c] else p) for c in range(2))
def transform(P,fc,ab):
    return tuple(2*([t//2,t%2][fc]^ab)+([t//2,t%2][1^fc]^ab) for t in P)
def lc(P):return min(transform(P,fc,ab) for fc,ab in it.product(range(2),repeat=2))
def canon(P,Q):return min(tuple(sorted((lc(tuple(P[i] for i in z)),lc(tuple(Q[i] for i in z))))) for z in it.permutations(range(3)))
best=((0,1,3),(1,2,1));t=Q(F(3895,3776),F(-1,3776));x=Q(F(1271,256),F(-1,256));y=1-x
A=F(9,10);b=F(16,25);l=1-b
assert all(v.sign()>0 for v in [t,1-t,x,y])
assert (A*x-t*(l+b*x)).zero()
assert ((1+b)*y-t*(l+2*b*y)).zero()
mu=[x*F(1,2),y,x*F(1,2)];assert (sum(mu)-1).zero()
assert all(z.sign()>0 for z in mu)
for s,bb,yy,d in inds:
    g=sum(mu[m]*(t-(1 if yy==m else 0))*W(best[s],m,bb,d) for m in range(3))
    assert g.sign()>=0
# Symmetries preserve the BSC contraction: simultaneous relabeling of c,d or a,b,
# a global permutation of messages, and swapping the two seed names.
winners={pair for pair in pairs if canon(*pair)==canon(*best)}
assert len(winners)==24
j=json.loads(Path(__file__).with_name('finite_k_m3_exact_certificates.json').read_text())
threshold=F(j['strict_lower_exclusion_threshold']);assert (t-threshold).sign()>0
seen=set()
for cert in j['rational_exclusions']:
    pair=tuple(tuple(v) for v in cert['profiles']);assert pair not in seen and pair in pairs and pair not in winners
    seen.add(pair);mu=[F(z) for z in cert['mu']]
    assert all(z>=0 for z in mu) and sum(mu)==1
    minima=[]
    for s in range(2):
        minima.append(sum(min(sum(mu[m]*(threshold-(1 if yy==m else 0))*W(pair[s],m,bb,d) for m in range(3)) for yy,d in it.product(range(3),range(2))) for bb in range(2)))
    assert min(minima)>0
assert seen|winners==set(pairs) and len(seen)==2056
print('PASS: exact algebraic primal/dual winner; 24 symmetry-equivalent profiles; 2056 rational exclusions; all 2080 unordered pairs covered. No optimization or floating-point arithmetic used.')
