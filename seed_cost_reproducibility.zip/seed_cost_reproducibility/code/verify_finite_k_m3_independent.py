"""Independent optimizer-free quadratic-field/rational proof checker."""
from fractions import Fraction as F
from itertools import product, permutations, combinations_with_replacement
from pathlib import Path
import json,math
D=1237585
assert math.isqrt(D)**2!=D
class Q:
 def __init__(self,a=0,b=0):self.a=F(a);self.b=F(b)
 def __add__(self,o):
  if not isinstance(o,Q):o=Q(o)
  return Q(self.a+o.a,self.b+o.b)
 __radd__=__add__
 def __neg__(self):return Q(-self.a,-self.b)
 def __sub__(self,o):return self+-o if isinstance(o,Q) else self+Q(-o)
 def __rsub__(self,o):return -self+o
 def __mul__(self,o):
  if not isinstance(o,Q):o=Q(o)
  return Q(self.a*o.a+D*self.b*o.b,self.a*o.b+self.b*o.a)
 __rmul__=__mul__
 def sign(self):
  a,b=self.a,self.b
  if b==0:return (a>0)-(a<0)
  if a==0:return (b>0)-(b<0)
  if a*b>0:return (a>0)-(a<0)
  d=a*a-D*b*b
  assert d!=0
  return ((d>0)-(d<0))*((a>0)-(a<0))
 def zero(self):return self.a==self.b==0
root=Path(__file__).parent
obj=json.loads((root/'finite_k_m3_exact_certificates.json').read_text())
t=Q(F(3895,3776),F(-1,3776));x=Q(F(1271,256),F(-1,256));low=F(7368993,10**7)
assert t.sign()>0 and (1-t).sign()>0 and x.sign()>0 and (1-x).sign()>0 and (t-low).sign()>0
A=F(9,10);b=F(16,25);ell=1-b
assert (A*x-t*(ell+b*x)).zero()
assert ((1+b)*(1-x)-t*(ell+2*b*(1-x))).zero()
mu=[x*F(1,2),1-x,x*F(1,2)]
assert (sum(mu)-1).zero() and all(v.sign()>0 for v in mu)
best=((0,1,3),(1,2,1))
def W(profile,m,b,d):
 a={0:(0,0),1:(0,1),2:(1,0),3:(1,1)}[profile[m]]
 return sum((F(9,10) if c==d else F(1,10))*(F(9,10) if b==a[c] else F(1,10)) for c in [0,1])
# Direct original-contraction primal, with two nonzero decoder blocks per seed.
primal={(0,0,0,1):x,(0,1,2,0):x,(1,0,1,1):1-x,(1,1,1,0):1-x}
for m in range(3):
 C=Q();Z=Q()
 for (s,b0,y,d),v in primal.items():
  term=v*W(best[s],m,b0,d);Z=Z+term
  if y==m:C=C+term
 assert Z.sign()>0 and (C-t*Z).zero()
for s,b0,y,d in product(range(2),range(2),range(3),range(2)):
 g=sum(mu[m]*(t-int(m==y))*W(best[s],m,b0,d) for m in range(3))
 assert g.sign()>=0
# Construct the winner equivalence orbit explicitly, independently of canonicalization.
def change(profile,perm,forwardflip,backwardflip):
 out=[]
 for oldm in perm:
  aa={0:(0,0),1:(0,1),2:(1,0),3:(1,1)}[profile[oldm]]
  new=[aa[c^forwardflip]^backwardflip for c in [0,1]]
  out.append(2*new[0]+new[1])
 return tuple(out)
orbit=set()
for perm in permutations(range(3)):
 for f0,a0,f1,a1 in product(range(2),repeat=4):
  pp=change(best[0],perm,f0,a0);qq=change(best[1],perm,f1,a1)
  orbit.add(tuple(sorted((pp,qq))))
assert len(orbit)==24
stored={tuple(tuple(p) for p in pair) for pair in obj['winner_orbit_profiles']}
assert stored==orbit
allpairs=set(combinations_with_replacement(list(product(range(4),repeat=3)),2))
seen=set()
for cert in obj['rational_exclusions']:
 pair=tuple(tuple(p) for p in cert['profiles']);assert pair in allpairs-orbit and pair not in seen;seen.add(pair)
 u=list(map(F,cert['mu']));assert len(u)==3 and sum(u)==1 and all(z>=0 for z in u)
 margins=[]
 for s in [0,1]:
  margins.append(sum(min(sum(u[m]*(low-int(m==y))*W(pair[s],m,b0,d) for m in range(3)) for y,d in product(range(3),range(2))) for b0 in [0,1]))
 margin=min(margins);assert margin>0 and margin==F(cert['margin'])
assert seen==allpairs-orbit and len(seen)==2056
out={'status':'all independent exact checks passed','optimum':'(3895-sqrt(1237585))/3776','winning_orbit_size':len(orbit),'rationally_excluded_pairs':len(seen),'total_profile_pairs':len(allpairs),'floating_point_used_in_proof':False}
(root/'finite_k_m3_independent_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)
