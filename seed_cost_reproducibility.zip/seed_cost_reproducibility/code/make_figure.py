#!/usr/bin/env python3
"""Generate the manuscript's analytic plot using standard LaTeX picture commands.
No external graphics package or raster image is required by the manuscript.
"""
from pathlib import Path
from fractions import Fraction as F
root=Path(__file__).resolve().parents[1]
x0,y0,w,h=50.,40.,330.,145.
ymin,ymax=.15,.70
xy=lambda x,y:(x0+w*float(x),y0+h*(float(y)-ymin)/(ymax-ymin))
lines=[r'\setlength{\unitlength}{1pt}',r'\begin{picture}(435,205)',r'\small',r'\linethickness{0.4pt}',r'\put(50,40){\line(1,0){330}}',r'\put(50,40){\line(0,1){145}}']
for i in range(6):
 x=F(i,5);a,b=xy(x,ymin)
 lines += [f'\\put({a:.3f},40){{\\line(0,-1){{3}}}}',r'\put(%.3f,25){\makebox(24,10){%.1f}}' % (a-12,float(x))]
for i in range(2,8):
 a,b=xy(0,F(i,10))
 lines += [f'\\put(50,{b:.3f}){{\\line(-1,0){{3}}}}',r'\put(18,%.3f){\makebox(26,10)[r]{%.1f}}' % (b-5,i/10)]
lines += [r'\put(179,5){\makebox(100,12){Forward diameter $\delta$}}',r'\put(17,189){\makebox(60,12)[l]{Success}}']
p=F(1,10);A=1-p;k=1-2*p;M=5
for name,fn in [('raw',lambda d:2*A/(M-(M-2)*k*d)),('single',lambda d:(1+k*d)/(M-(M-2)*k*d))]:
 lines.append(r'\linethickness{0.9pt}' if name=='raw' else r'\linethickness{0.6pt}')
 N=120
 for i in range(N):
  if name=='single' and i%3==2:continue
  x=F(i,N);z=F(i+1,N);a,b=xy(x,fn(x));c,d=xy(z,fn(z))
  lines.append(f'\\qbezier({a:.3f},{b:.3f})({(a+c)/2:.3f},{(b+d)/2:.3f})({c:.3f},{d:.3f})')
a,b=xy(0,2*A/M)
lines += [r'\linethickness{0.5pt}',f'\\multiput(50,{b:.3f})(12,0){{27}}{{\\line(1,0){{7}}}}']
# Legends live in the large clear upper-left interior.
lines += [r'\linethickness{0.9pt}',r'\put(73,172){\line(1,0){23}}',r'\put(103,167){\makebox(180,10)[l]{Unrestricted optimum}}',r'\linethickness{0.6pt}',r'\multiput(73,156)(6,0){4}{\line(1,0){4}}',r'\put(103,151){\makebox(200,10)[l]{Pair plus singleton construction}}',r'\linethickness{0.5pt}',r'\multiput(73,140)(12,0){2}{\line(1,0){7}}',r'\put(103,135){\makebox(200,10)[l]{Ignore the forward channel}}',r'\end{picture}']
fragment='\n'.join(lines)+'\n'
(root/'figures').mkdir(exist_ok=True)
(root/'figures'/'approximate_resources.tex').write_text(fragment)
main=root/'source'/'main.tex'
s=main.read_text();start='% BEGIN GENERATED ANALYTIC FIGURE';end='% END GENERATED ANALYTIC FIGURE'
if start in s:
 a=s.index(start)+len(start);b=s.index(end,a);s=s[:a]+'\n'+fragment+s[b:]
else:
 old=r'\includegraphics[width=0.91\linewidth]{../figures/approximate_resources.pdf}'
 assert old in s
 s=s.replace(old,start+'\n'+fragment+end)
main.write_text(s)
print('Generated analytic figure and embedded it in source/main.tex')
