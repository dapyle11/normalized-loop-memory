#!/usr/bin/env python3
"""Exact algebraic winner + exact rational exclusions of all other profiles."""
from finite_k_m3 import *
import sympy as sp
D=1237585;R=sp.sqrt(D)
tstar=(3895-R)/3776
xstar=(1271-R)/256
u=xstar/2
mu=[u,1-2*u,u]
best=((0,1,3),(1,2,1));winningcanon=canon(*best)

def symrat(x):return sp.Rational(x.numerator,x.denominator)
def norm(expr):return sp.simplify(sp.expand(expr))
def exact_sign(expr):
    expr=norm(expr);a=expr.coeff(R,0);b=expr.coeff(R,1)
    assert norm(expr-a-b*R)==0 and a.is_Rational and b.is_Rational,(expr,a,b)
    if b==0:return 1 if a>0 else -1 if a<0 else 0
    if a==0:return 1 if b>0 else -1
    if a>0 and b>0:return 1
    if a<0 and b<0:return -1
    diff=a*a-b*b*D
    assert diff!=0
    return (1 if diff>0 else -1) if a>0 else (-1 if diff>0 else 1)
assert exact_sign(xstar)>0 and exact_sign(1-xstar)>0
assert exact_sign(tstar)>0 and exact_sign(1-tstar)>0
# Explicit pair/singleton primal.
A=sp.Rational(9,10);b=sp.Rational(16,25);l=1-b
pair_success=A*xstar/(l+b*xstar)
loop_success=(1+b)*(1-xstar)/(l+2*b*(1-xstar))
assert norm(pair_success-tstar)==0 and norm(loop_success-tstar)==0
# Upper certificate for representative. Every decoder coefficient is nonnegative.
g=[]
for s,bb,y,d in inds:
    z=norm(sum(mu[m]*(tstar-(1 if y==m else 0))*symrat(W(best[s],m,bb,d)) for m in range(3)))
    assert exact_sign(z)>=0,(s,bb,y,d,z)
    g.append(str(z))
assert exact_sign(sum(mu)-1)==0 and all(exact_sign(z)>0 for z in mu)
# Rationally rule out all profiles outside the exactly checked winner orbit.
threshold=F(7368993,10**7)
assert exact_sign(tstar-symrat(threshold))>0
rational_certs=[];winner_pairs=[]
for P,Q in allpairs:
    if canon(P,Q)==winningcanon:
        winner_pairs.append((P,Q));continue
    res=lp((P,Q),threshold);assert res.success
    rr=rational_mu(res,10**12);margin=dual_verify((P,Q),threshold,rr)
    assert margin>0,((P,Q),float(margin))
    rational_certs.append({'profiles':[P,Q],'mu':[str(v) for v in rr],'margin':str(margin)})
assert len(winner_pairs)+len(rational_certs)==2080
out={'exact_optimum':'(3895-sqrt(1237585))/3776','decimal':float(tstar),'exact_primal_pair_probability':'(1271-sqrt(1237585))/256','exact_primal_singleton_probability':'1-(1271-sqrt(1237585))/256','winner_profiles':best,'winner_mu':[str(z) for z in mu],'winner_all_variable_coefficients':g,'winner_orbit_profiles':winner_pairs,'winner_orbit_size':len(winner_pairs),'strict_lower_exclusion_threshold':str(threshold),'rational_exclusion_count':len(rational_certs),'rational_exclusions':rational_certs,'unrestricted_optimum':'45/59','gap_decimal':45/59-float(tstar),'status':'Exact quadratic-field primal and upper certificate checked; all remaining profiles excluded by verified rational inequalities.'}
Path(__file__).with_name('finite_k_m3_exact_certificates.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['rational_exclusions','winner_all_variable_coefficients','winner_orbit_profiles']},indent=2))
