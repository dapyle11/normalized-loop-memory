#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for pass in 1 2; do
  pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build source/main.tex > "build/pass${pass}.log"
done
printf 'Built build/main.pdf\n'
