# Mathematical verification report: raw-seeded normalized binary loop

30 October 2026. AI-assisted verification, not independent human review, formal proof-assistant verification, originality certification, or a physical experiment.

## Verdict

**PASS under the explicit model below.** The verification checked the mathematical reductions and attaining construction in `proof.md`. No counterexample or algebraic gap was found. The theorem is an exact restricted-model optimization result. Its potentially publishable novelty is not established by this audit.

For a finite-dimensional CPTP forward channel Phi, binary backward BSC(p), 0<p<1/2, and M>=2 messages, the best minimum message success under finite raw shared-seed mixing is

    2(1-p) / [M-(M-2)(1-2p) delta(Phi)],

where delta is the maximum output trace distance. The optimization is over seed distributions and finite seed alphabets; attainability is not asserted for every prescribed seed distribution. A uniform M-valued seed suffices.

## Assumptions indispensable to the result

* The seed is independent of the message and is not selected as a function of b in the raw contraction. Both encoder and decoder can read it. It is an additional resource outside the fixed noisy forward carrier.
* Raw weights are summed over the seed **before** dividing by the message-dependent normalizer. The success criterion minimizes only over messages, not over seed branches.
* The decoder at each b and seed prepares arbitrary positive subnormalized state blocks tau_yb with sum_y trace(tau_yb)=1. The encoder chooses any binary POVM depending on message and seed. This includes all permitted local randomization.
* No retained decoder-output record, ancillary side channel, pre-shared entanglement, or additional memory correlated with b is supplied. Such additions are different models.
* State spaces are finite dimensional. This ensures compactness and attainment of the channel diameter. Messages are a fixed finite alphabet.
* Decoder output labels may be taken to be precisely the message alphabet. If extraneous failure labels are allowed, relabeling each to any message preserves the normalizer and cannot decrease any correct weight, so the same upper bound still applies.
* p=0 is excluded: positivity is no longer uniform. M=1 is separately equal to 1. The p=1/2 endpoint can separately be included and equals 1/M.

## Proof checks

### 1. Positivity and aggregate reduction

Every binary-channel factor lies between p and A=1-p. Summing all output labels and encoder outcomes gives total unweighted trace 2. Therefore 2p <= Z_m,s <= 2A. No divisions by a potentially zero normalizer occur in the stated parameter range.

For any seeded protocol, its aggregate correct-weight/total-weight ratio is a positive weighted average of its per-message conditional success rates. Thus the minimum message rate is bounded above by that aggregate ratio. The aggregate ratio is in turn a positive denominator-weighted average of per-seed aggregate ratios. Maximizing a single-seed aggregate ratio is therefore a valid upper bound, even though a single seed may perform extremely poorly on some messages. It is precisely subsequent raw symmetrization that converts the aggregate optimum into a minimax achiever.

### 2. Decoder extremality

Fix all message encoder effects. Both numerator and denominator are affine in each decoder block family. Decompose each b-row into its spectral block extreme points, each of which has one output label and a rank-one state. Multiplying the two finite decompositions yields a convex decomposition of the decoder pair. Since the denominator is positive, its ratio is a denominator-weighted mean of extreme-pair ratios. At least one extreme pair is at least as good. This reduction does not assume that a ratio is linear or convex, and it does not exchange an invalid minimax operation.

### 3. Distinct output labels

Let k=1-2p, Delta=sigma_0-sigma_1 and d=TD(sigma_0,sigma_1). The normalizer is 1+k trace(E Delta), hence it ranges from 1-kd to 1+kd.

For the two active message labels, at any trial threshold 0<=t<=1 their respective correct-minus-t-total expressions are

    p-t+k trace[E((1-t)sigma_0+t sigma_1)],
    A-t-k trace[E(t sigma_0+(1-t)sigma_1)].

Both bracketed operators are positive, trace one. Each expression is at most A-t, attained respectively by E=I and E=0. For all M-2 inactive messages the expression is at most -t(1-kd), attained by the negative spectral projector of Delta. Substitution of

    t = 2A / [2+(M-2)(1-kd)]

makes the total upper bound zero. This t lies in [0,1]. There is no unjustified separate optimization of a numerator and denominator: the threshold argument optimizes their difference jointly.

### 4. Identical output labels

Only one message contributes to the numerator, which equals that message's normalizer. Independent encoder choices make the active normalizer as large as 1+kd and every inactive one as small as 1-kd. The resulting ratio is

    (1+kd)/[M-(M-2)kd].

Its denominator is identical to that of the distinct-label ratio and its numerator is no larger than 1+k=2A. Thus repeated labels cannot improve the bound. This also covers d=0 without a special Helstrom choice.

### 5. Diameter and attainment

The distinct-label bound is nondecreasing in d, so d<=delta yields the global upper bound. A diameter-attaining pair exists. Mixed inputs are permitted. In input dimension at least two, an orthogonal pure maximizing pair can be obtained by Jordan decomposition followed by spectral decomposition and trace-norm convexity when delta>0; if delta=0, any orthogonal pure pair suffices. In input dimension one, delta=0 and the unique input state is used for both preparations; no orthogonal pair exists and the formula is unchanged. No unproven assumption that all channel optima occur at antipodal inputs is needed in general dimension.

The cyclic construction makes every message active in exactly two of M uniform seed values. Each active branch has correct weight A and total weight 1. Every inactive branch has correct weight zero and total weight 1-kdelta. Consequently each message attains exactly the aggregate bound. This construction also works for M=2; no inactive branch is then needed, and no random seed is necessary. Seed minimality is not established.

## Normalization and operational interpretation

The conditional seed law is

    pi_s Z_m,s / sum_r pi_r Z_m,r.

It can depend on the message, despite message-independent raw pi_s. The theorem does not certify a message-independent seed in the normalized ensemble and does not promise success for each seed separately.

Exact same-code example: M=4, p=1/10, noiseless forward channel. For a fixed message the four seed branches have (correct,total) pairs (9/10,1), (9/10,1), (0,1/5), (0,1/5). Raw mixture followed by normalization gives 3/4. Uniform mixture of individually normalized branches gives 9/20. This proves the conventions differ for this code; it does **not** identify the optimum of the separately normalized convention.

Ordinary rejection sampling can illustrate the changed conditional seed weights, but is not a construction of a backward-in-time channel. The theorem assumes the normalized-loop rule. No physical realizability, experimental retrocausality, or solution of a general noisy-memory capacity problem follows.

## Numerical and exact checks

The accompanying `audit_checks.py` uses a separate implementation from `verify.py`. It constructs full random mixed decoder blocks and arbitrary binary encoder effects, rather than only the extremal achiever. See `audit_results.json` for the executed results. It checks:

* 220 exact rational cyclic-achiever cases for M=2,...,12, five p values including the trivial p=1/2 endpoint, and four diameters;
* 1,800 random finite-seed quantum protocols, with qubit amplitude-damping and qutrit depolarizing forward channels whose diameters are known exactly;
* positivity, minimum-versus-aggregate ordering, and the aggregate upper bound;
* the exact M=4 convention discrepancy 3/4 versus 9/20;
* the separate M=1 identity.

Random checks are not a global numerical optimization, a proof in arbitrary dimension, or evidence of originality. The analytic argument above is the reason to accept the theorem.

## Sources and scope of source checking

The exact normalized-loop optimization was independently derived from the explicit weights. The contraction coefficient is established mathematics. The companion `related_work.md` records the broader bounded literature screen.

Primary sources consulted for this verification:

* Ji, Lloyd, Wilde, *Retrocausal Capacity of a Quantum Channel: Communicating Through Noisy Closed Timelike Curves*, https://arxiv.org/html/2509.08965v3 . Establishes relevant normalized retrocausal-channel context; this audit makes no claim that the present restriction resolves their full program.
* Chitambar, George, Doolittle, Junge, *The Communication Value of a Quantum Channel*, https://arxiv.org/abs/2109.11144 . Establishes prior quantum communication-value context. Its ordinary communication-value objective should not be equated with the present nonlinear objective.

The standard qubit diameter formula is independently immediate from the affine Bloch representation: translation cancels, trace distance is half the Euclidean separation, and a maximizing right singular vector and its antipode attain the largest singular value. For amplitude damping this gives sqrt(1-gamma). For any-dimensional depolarization rho -> (1-epsilon)rho+epsilon I/d, output differences are scaled by 1-epsilon, giving diameter 1-epsilon.

## Scope and status

The result concerns raw mixture before normalization in the specified restricted-resource model. It is a derivation pending originality review, not a verified first discovery. AI assistance was used; independent human review remains pending. Matched-diameter classical/quantum equality follows in this model, but no universal disappearance of quantum advantage follows.
