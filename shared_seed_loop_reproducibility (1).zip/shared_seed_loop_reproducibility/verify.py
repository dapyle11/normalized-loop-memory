"""Exact finite classical checks plus symbolic identities; no numerical optimizer."""
from itertools import product
from fractions import Fraction as F
import json
import numpy as np
import sympy as sp

p,d,M=sp.symbols('p d M', real=True)
k=1-2*p
R2=2*(1-p)/(M-(M-2)*k*d)
R1=(1+k*d)/(M-(M-2)*k*d)
assert sp.simplify(2*(1-p-R2)-R2*(M-2)*(1-k*d))==0
assert sp.simplify((R2-R1)-k*(1-d)/(M-(M-2)*k*d))==0
records=[]
# Column-stochastic channels, all denominators 10. Includes asymmetric ternary output.
channels={
 'perfect_bit':np.array([[10,0],[0,10]],dtype=np.int64),
 'bsc_0.2':np.array([[8,2],[2,8]],dtype=np.int64),
 'constant_bit':np.array([[6,6],[4,4]],dtype=np.int64),
 'ternary_asymmetric':np.array([[8,1,2],[1,6,2],[1,3,6]],dtype=np.int64),
}
for name,C in channels.items():
 nout,nin=C.shape
 delta=max(F(int(np.abs(C[:,i]-C[:,j]).sum()),20) for i in range(nin) for j in range(nin))
 effects=np.array(list(product([0,1],repeat=nout)),dtype=np.int64)
 for m in [2,3,4]:
  codes=np.array(list(product(range(len(effects)),repeat=m)),dtype=np.int64)
  for pn in [1,3,5]:
   # N numerator pn if flipped, 10-pn otherwise. Weights denominator 100.
   kval=10-2*pn; A=10-pn
   best=F(0)
   for i,j,y0,y1 in product(range(nin),range(nin),range(m),range(m)):
    h0=effects@C[:,i]; h1=effects@C[:,j]
    w0=10*pn+kval*h0
    w1=10*A-kval*h1
    z=w0+w1
    correct=np.zeros((len(codes),m),dtype=np.int64)
    correct[:,y0]+=w0[codes[:,y0]]
    correct[:,y1]+=w1[codes[:,y1]]
    nums=correct.sum(axis=1); dens=z[codes].sum(axis=1)
    # Exact comparison to conjectured bound, avoiding float argmax.
    expect=2*(1-F(pn,10))/(m-(m-2)*(1-2*F(pn,10))*delta)
    cross=nums*expect.denominator-dens*expect.numerator
    assert np.max(cross)<=0,(name,m,pn,i,j,y0,y1)
    if np.any(cross==0): best=expect
   assert best==expect,(name,m,pn,best,expect)
   records.append({'channel':name,'M':m,'p':str(F(pn,10)),'delta':str(delta),'exact_aggregate_max':str(best),'all_extreme_encoders_decoders_checked':True})
# Cyclic raw-seed construction checked in exact arithmetic on wider parameter grid.
cyclic=0
for m in range(2,21):
 for pp in [F(1,100),F(1,10),F(1,4),F(1,2)]:
  for dd in [F(0),F(1,7),F(1,2),F(1)]:
   for msg in range(m):
    correct=F(0); normalizer=F(0)
    for s in range(m):
     active=msg==s or msg==(s+1)%m
     correct+=(1-pp) if active else 0
     normalizer+=1 if active else 1-(1-2*pp)*dd
    assert correct/normalizer==2*(1-pp)/(m-(m-2)*(1-2*pp)*dd)
   cyclic+=1
assert ((F(9,10)+F(9,10))/(1+1+F(1,5)))==F(9,11)
assert (F(9,10)+F(9,10)+0)/3==F(3,5)
result={'symbolic_identities':'passed','exact_classical_enumerations':records,'cyclic_parameter_settings':cyclic,'normalization_counterexample':'9/11 versus 3/5','scope':'Finite checks support but do not replace proof. No physical simulation.'}
with open('verification_results.json','w') as f: json.dump(result,f,indent=2)
print(json.dumps({'symbolic':'passed','exhaustive_cases':len(records),'cyclic_settings':cyclic,'status':'all passed'}))
