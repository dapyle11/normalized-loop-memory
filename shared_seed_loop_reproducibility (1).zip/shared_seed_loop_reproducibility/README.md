# Raw shared seeds in a normalized binary loop

Research supplement, 30 October 2026. AI-assisted research and verification;
independent human review and originality review remain pending. This is a
mathematical result for a stipulated model, not a physical backward channel.

## Exact scope

Let Phi be a finite-dimensional CPTP forward channel, let the stipulated binary
backward channel be BSC(p), 0 < p < 1/2, and let M >= 2 be the message count.
The decoder can prepare subnormalized quantum state blocks and the encoder uses
message- and seed-dependent binary POVMs. Both have access to a finite classical
seed independent of message and backward outcome at the raw level. There is no
extra retained record, additional side channel, or entanglement assistance.
The seed is an extra resource outside the fixed noisy forward carrier.

For per-seed nonnegative weights w_m^s(y) and normalizers Z_m^s, this model uses
RAW MIXTURE BEFORE CONDITIONING:

    P(y|m) = sum_s pi_s w_m^s(y) / sum_s pi_s Z_m^s.

The optimum over all finite seeds, seed distributions, and permitted local
operations of min_m P(m|m) is

    2(1-p) / [M - (M-2)(1-2p) delta(Phi)],
    delta(Phi) = max_{rho,sigma} ||Phi(rho)-Phi(sigma)||_1 / 2.

The diameter is a known trace-distance contraction coefficient, not a new
invariant. A uniform M-valued seed attains the bound; no minimum-cardinality
claim is made. M=1 has success 1; p=1/2 gives 1/M separately; p=0 is excluded
because zero normalizers require a separate convention. No seed is needed for M=2.

The conditional seed weights are pi_s Z_m^s / sum_r pi_r Z_m^r and may depend
on m. This is NOT an average of individually normalized protocols. For one
M=3 code these conventions give 9/11 and 3/5 respectively; this comparison does
not determine the optimum in the other convention. Success is minimized over
messages, not over seeds. Matched channel-diameter comparisons are restricted
to this model, not a universal claim about quantum advantage or physical time travel.

## Reproduce the checks

Tested with Python 3.12.14; tested package versions are pinned in requirements.txt.
For a researcher who extracts the archive, from its extracted directory:

    python -m pip install -r requirements.txt
    python run_checks.py

The runner can also be invoked by its path from any working directory. It
verifies bundled file hashes, runs each unchanged research script in an isolated
temporary directory, compares exact outputs exactly and floating-point summary
values within rel_tol=1e-9, abs_tol=1e-12, then prints a JSON PASS summary.
No network is needed after dependencies are installed. Temporary outputs are
cleaned automatically; included reference JSON files are not overwritten.
The scripts use Python assertions, so direct invocation should not use python -O.
The runner explicitly removes PYTHONOPTIMIZE for its subprocesses.

Checks cover 36 exhaustive finite classical cases; 304 exact cyclic-construction
settings; a separate 220 exact cyclic settings; 1,800 seeded random quantum
protocols; symbolic identities; and exact normalization counterexamples.
The random checks are not global optimization or experimental evidence.
Finite verification supports but cannot replace the analytic proof.

## Files

- proof.md: full mathematical proof and scope limitations.
- related_work.md: bounded primary-source literature screening and citations.
- verification_report.md: proof checks, assumptions, limitations, numerical scope.
- verify.py / verification_results.json: exact and symbolic checks and reference output.
- audit_checks.py / audit_results.json: separately implemented exact/random checks and reference output.
- run_checks.py: portable integrity and reproduction runner.
- requirements.txt / environment.json: dependencies and tested environment.
- SHA256SUMS: integrity hashes of all other bundled files (not an authenticity signature).

## Research status and repository placement

A bounded literature screening did not locate the identical restricted formula
in the checked material. That is not originality certification; a reduction to
an existing theorem remains possible. All mathematical claims require independent
human scrutiny before being treated as reviewed research. No general noisy-memory
capacity problem or physical time-travel problem is claimed solved.

This is a separate companion archive intended to be added alongside earlier work
at https://github.com/dapyle11/normalized-loop-memory, not to replace the prior
normalized_loop_memory_research.zip. The separate paper and its publication source
are not part of this code archive. This README does not claim that this archive
has already been uploaded or published. Uploading the ZIP as-is does not require
the repository owner to unzip it; extraction is only needed to run these checks.

No new license grant is made by this supplement. No LICENSE file has been added.
