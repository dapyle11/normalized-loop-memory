# Related work: pre-postselection shared seeds in a binary loop

Date: 30 October 2026. Research screening, not originality certification or independent mathematical peer review.

## Research scope and status

This is a restricted-model exact optimization theorem / technical note. AI-assisted verification has been completed; independent human review and originality review remain pending. It does not solve the published general noisy-memory rate tradeoff, introduce a new channel invariant, or establish physical backward communication. No identical formula was located in the checked primary-source sections. This bounded negative search result is not a novelty guarantee. A direct corollary of earlier work remains possible.

Candidate: one classical backward BSC(p), 0 < p < 1/2 (p=1/2 is a separate trivial endpoint; p=0 is excluded because zero normalizers require separate treatment); one finite-dimensional forward CPTP map Phi; unrestricted local instruments; a finite shared classical seed independent of message and backward outcome before postselection; no retained output label or other side channel and no entanglement assistance. Global seed mixture is normalized once per message. Proposed success is

    S_M = 2(1-p) / [M - (M-2)(1-2p) delta(Phi)], M >= 2,
    delta(Phi) = max_{rho,sigma} (1/2)||Phi(rho)-Phi(sigma)||_1.

Only this exact resource-restricted formula and its attaining construction are possible contributions. Trace-distance optimization, seed symmetrization, binary discrimination, and affine-fractional optimization are established tools.

## 1. Closest architecture and noisy-memory problem

Ji, Lloyd, Wilde, *Retrocausal Capacity of a Quantum Channel: Communicating Through Noisy Closed Timelike Curves*, arXiv:2509.08965v3:
https://arxiv.org/html/2509.08965v3

Main Eq.(1), supplemental Eq.(S28): nonlinear output is an unnormalized linear contraction divided by its trace. Main Eq.(2)/supplement IV.1: decoder followed by forward memory and encoder. IV.1 explicitly permits arbitrary-dimensional noiseless memory; it does not impose our fixed noisy-carrier restriction. Strategy 2 in VI.2 uses shared randomness and forward registers L1,L2. Their model therefore does not generally forbid shared randomness. Main Eq.(13) states the noisy-forward-memory rate tradeoff as an open question, not an exact solution.

Our interpretation: substitute T = sum_s q_s T_s into Eq.(1). Linearity before normalization gives sum_s q_s w_{m,s}(y) / sum_s q_s Z_{m,s}. This is **not** sum_s q_s w_{m,s}(y)/Z_{m,s}. It supports the candidate's mathematical convention, not physical realizability. The candidate is one-shot, classical-message, BSC-backward, fixed-forward-carrier, seed-only assistance: not the general asymptotic quantum rate tradeoff. Their unrestricted theorem can provide an outer benchmark, not an equality for this restriction.

## 2. Conditional minimax objective and assistance

Ji, Regula, Wilde, *Postselected communication over quantum channels*, arXiv:2308.02583v3:
https://arxiv.org/html/2308.02583v3

Section 3.1 Eq.(20) already defines worst-message conditional error as one minus a minimum of correct unnormalized weight divided by total conclusive weight. Section 3.2 Definition 3.5 allows an arbitrary bipartite shared state, a trace-preserving encoder, and a trace-nonincreasing decoder. Their main assisted results concern entanglement/nonsignalling assistance, not one fixed forward noisy memory plus only classical shared randomness. Remark 5.6 discusses feedback in that broader assisted framework.

Our inference: mixing the shared state/protocol before applying Eq.(20) also mixes raw weights before normalization. Their conditional error convention is not novel here. A postselected simulation of the loop does not identify our resource-restricted optimum with their assisted formula; one must show both directions of a resource-preserving reduction, and none was found.

## 3. Diameter is a known contraction coefficient

Fawzi, Mueller-Hermes, Shayeghi, *A Lower Bound on the Space Overhead of Fault-Tolerant Quantum Computation*, ITCS 2022, Eqs.(2)-(3):
https://drops.dagstuhl.de/storage/00lipics/lipics-vol215-itcs2022/LIPIcs.ITCS.2022.68/LIPIcs.ITCS.2022.68.pdf

These equations give the trace-norm contraction coefficient as a supremum ratio and equivalently a maximum over orthogonal pure inputs. This is the quantum Dobrushin coefficient. It equals the candidate's maximum output trace distance: Jordan-decompose rho-sigma into equally weighted orthogonal-support density operators; convexity reduces these to pure pairs. Consequently delta is not a newly introduced invariant. The same coefficient is treated in Hiai and Ruskai, *Contraction coefficients for noisy quantum channels*, https://arxiv.org/abs/1508.03551 (abstract checked).

## 4. Communication value overlap

Chitambar, George, Doolittle, Junge, *The Communication Value of a Quantum Channel*, arXiv:2109.11144v1:
https://arxiv.org/html/2109.11144

Definition 1 optimizes classical message transmission induced by quantum preparations and a POVM. Section IV.A, Theorem 2, Eq.(42), gives cv(Phi)=1+sigma_max(T) for a qubit channel's Bloch linear part (equivalently the relevant Choi correlation matrix; transpose/sign conventions do not affect singular values). This is 1+delta(Phi). Their objective is ordinary guessing/communication value, not the normalized-loop ratio. Thus identifying the candidate's qubit dependence with the largest Bloch singular value is a corollary of well-known geometry, not a separate novelty claim. In higher dimensions full cv is not generally 1+delta: that identity belongs to binary-state discrimination or the qubit theorem, and is not asserted in general dimension here.

## 5. Classical/quantum equality with shared randomness is not generally new

Frenkel and Weiner, *Classical information storage in an n-level quantum system*, arXiv:1304.5723; CMP340 (2015), 563-574:
https://arxiv.org/abs/1304.5723
https://real.mtak.hu/33623/1/1304.5723v3.pdf

Their ordinary one-preparation/one-fixed-measurement reward game has equal optimal expected reward for an n-level quantum system and an n-state classical system. This limits any broad claim that shared randomness removes quantum advantage. It does not directly optimize a fixed noisy carrier with message-selected binary effects and message-dependent normalization.

Bowles, Quintino, Brunner, *Certifying the dimension of classical and quantum systems in a prepare-and-measure scenario with independent devices*, arXiv:1311.1525v3:
https://arxiv.org/html/1311.1525v3

This antecedent explicitly separates independent-device models from shared-randomness convexification. The previous no-seed and present common-seed problems use distinct resource sets. Their dimension witnesses do not establish the candidate formula.

## Normalization convention

For raw seed weights q_s, posterior seed probability after postselection at message m is

    q(s | m, accepted) = q_s Z_{m,s} / sum_t q_t Z_{m,t}.

It is generally message-dependent. The seed is independent before postselection, not necessarily afterward. A separately normalized branch-mixture model has a different operational definition and is not covered. The seed is included in the conditioned ensemble; the minimax is over messages only, with the seed marginalized. Success is not guaranteed separately for every seed.

## Search scope and limitations

Read exact pertinent definitions/equations and nearby discussion in Ji2026, Ji2024, communication-value paper; checked Dobrushin primary-source equations; checked independent/shared-device and classical-simulation antecedents. Searches included retrocausal+shared randomness+memory, postselected+binary symmetric channel, two preparations+shared randomness, and trace-norm contraction coefficient. No exact fixed-Phi/BSC normalized-loop common-seed theorem located. No exhaustive citation-tree search or author confirmation; no conclusion about legal priority or publishability. A resource-preserving reduction to an existing theorem remains the principal originality risk.
