# Exact minimax theorem with a raw finite common seed

Research proof note. This is a theorem for a stipulated normalized-loop model, not a physical backward communication protocol. Novelty has not been established.

## 1. Model and normalization convention

Let Phi be a finite-dimensional CPTP map, let 0<p<1/2, and write A=1-p and k=1-2p. There are M>=2 messages and a binary backward channel N_p(b|a), equal to A for a=b and p otherwise. Define

    delta = max_{rho_0,rho_1} (1/2)||Phi(rho_0)-Phi(rho_1)||_1.

The maximum exists by compactness. A raw seed s has a finite alphabet and prescribed probabilities pi_s independent of the externally selected message. Both devices know s. For each b,s the decoder chooses positive operators tau^s_{yb} satisfying sum_y Tr(tau^s_{yb})=1. The encoder for message m and seed s chooses a binary POVM E^s_{0|m}=E^s_m and E^s_{1|m}=I-E^s_m. The unnormalized weights are

    w^s_m(y) = sum_{a,b} N_p(b|a) Tr[E^s_{a|m} Phi(tau^s_{yb})],
    Z^s_m = sum_y w^s_m(y).

The convention in this note is RAW MIXTURE BEFORE NORMALIZATION:

    P(y|m) = [sum_s pi_s w^s_m(y)]/[sum_s pi_s Z^s_m].

Every Z lies between 2p and 2A, so all denominators are positive. The quantity optimized is min_m P(m|m). Seed storage is an additional resource not available in an unseeded model.

This convention is NOT interchangeable with externally mixing individually normalized protocols, whose probabilities would instead be sum_s pi_s w^s_m(y)/Z^s_m. In the raw-mixture convention the conditional seed law is pi_s Z^s_m/(sum_r pi_r Z^r_m), and can depend on the message. Thus the seed is independent at the raw level, not necessarily in the normalized ensemble. All comparisons here use this raw-level convention.

## 2. Exact result

The supremum over all finite raw seeds, decoder preparations and encoder effects is attained and equals

    S_raw(Phi,p,M) = 2(1-p)/[M-(M-2)(1-2p)delta].                 (1)

A uniform seed of M values suffices. This is an upper bound on sufficient seed size, not a minimality claim. For M=2 no seed is needed. The case M=1 has success 1 and is separate.

## 3. Reduction to one aggregate ratio

Set D=sum_m sum_s pi_s w^s_m(m) and Q=sum_m sum_s pi_s Z^s_m. The minimum message success is at most D/Q, because D/Q is a positive weighted average of message successes with weights proportional to their averaged normalizers. Further, D/Q is a weighted average of the single-seed ratios

    R_s = [sum_m w^s_m(m)]/[sum_m Z^s_m],

with weights proportional to pi_s sum_m Z^s_m. It is therefore at most the largest achievable single-seed aggregate ratio R.

For fixed encoder effects, numerator and denominator of R are linear in the decoder block operators, with strictly positive denominator. The decoder feasible set is a product of two compact convex sets. Each factor has extreme points consisting of a single nonzero output-label block that is a rank-one unit-trace state. A convex decomposition of any decoder into such product extreme points decomposes R into a denominator-weighted average. Consequently some extreme decoder has at least as large an aggregate ratio. It suffices to consider deterministic output labels y_0,y_1 and pure preparation states rho_0,rho_1.

Write sigma_b=Phi(rho_b), Delta=sigma_0-sigma_1 and d=(1/2)||Delta||_1<=delta. For each encoder effect E_m,

    Z_m = 1+k Tr(E_m Delta),
    1-kd <= Z_m <= 1+kd.                                    (2)

Both endpoints are attainable by the negative/positive spectral projectors of Delta. Zero eigenvalues can be assigned arbitrarily.

## 4. Different output labels

Suppose y_0 != y_1; relabel these two messages 0 and 1. For any t in [0,1],

    w_0(0)-t Z_0
      = p-t + k Tr[E_0((1-t)sigma_0+t sigma_1)] <= A-t,
    w_1(1)-t Z_1
      = A-t - k Tr[E_1(t sigma_0+(1-t)sigma_1)] <= A-t.

The operators inside the traces are positive of trace one. Equality is simultaneous at E_0=I and E_1=0. For any other message the correct weight is zero, and -t Z_m <= -t(1-kd). Therefore

    sum_m [w_m(m)-t Z_m] <= 2(A-t)-t(M-2)(1-kd).

Taking

    R_2(d)=2A/[2+(M-2)(1-kd)]

as t gives an upper bound R<=R_2(d). It lies in [0,1], as required. Equality is attained by the two constant active encoders and the negative Helstrom projector for every inactive message. R_2(d) is nondecreasing in d and hence at most R_2(delta).

## 5. Identical output labels

If y_0=y_1=y_*, then only message y_* can be correctly decoded, and its correct weight is exactly Z_{y_*}. The ratio is increasing in that normalizer and decreasing in each other normalizer. By (2), its maximum for these preparations is

    R_1(d)=(1+kd)/[(1+kd)+(M-1)(1-kd)]
          =(1+kd)/[M-(M-2)kd]
          <=(1+k)/[M-(M-2)kd]=R_2(d),

because 0<=d<=1 and 1+k=2A. This completes the upper bound for arbitrary finite raw seeds.

## 6. Finite construction attaining the bound

Take a diameter-attaining input pair rho_0,rho_1 and an output effect H with Tr[H(sigma_0-sigma_1)]=-delta. Let the raw seed s be uniform on the integers modulo M. For b=0, output label s and prepare rho_0; for b=1, output label s+1 and prepare rho_1. For message m, use effect

    E^s_m = I if m=s;
            0 if m=s+1;
            H otherwise.

For every fixed message, exactly one seed makes it the first active label and exactly one makes it the second. Each active role has correct weight A and normalizer 1. Each of the remaining M-2 seeds has correct weight zero and normalizer 1-kdelta. Thus

    averaged correct weight = 2A/M,
    averaged normalizer = [2+(M-2)(1-kdelta)]/M,

and every message attains (1). A uniform M-valued seed has entropy log_2 M and can be stored using ceil(log_2 M) binary memory cells. Exact sampling from fair bits may require variable random-bit consumption when M is not a power of two; storage and generation cost are different resources.

## 7. Mixing and normalizing do not commute

The same construction provides an exact counterexample. Take M=3, p=1/10 and a perfect forward channel (delta=1). For each message, its three seed branches have pairs (correct weight,normalizer)

    (9/10,1), (9/10,1), (0,1/5).

Raw mixing then normalizing yields (9/5)/(11/5)=9/11. Uniform mixing of the three individually normalized protocols yields [(9/10)+(9/10)+0]/3=3/5. These are different operational conventions. The conditional seed probabilities in the raw mixture are 5/11,5/11,1/11 rather than 1/3 each.

Ordinary postselection realizes this mathematical distinction whenever a seed is sampled before a seed- and message-dependent acceptance event. Indeed the bound Z<=2A permits abstract acceptance weights Z/(2A). However, this observation does NOT construct the stipulated backward channel or a physical realization of all loop weights. It explains only the normalization bookkeeping. If a physical implementation promises a seed independent after conditioning, it is outside this theorem's convention.

## 8. Channel diameter facts and comparisons

The diameter delta equals the usual trace-distance contraction coefficient. To see this, write rho-sigma=t(omega_+-omega_-), where t=TD(rho,sigma), and the omega states are normalized positive/negative parts with orthogonal supports. Then TD(Phi(rho),Phi(sigma))/t=TD(Phi(omega_+),Phi(omega_-))<=delta. Conversely the ratio is always at least the unscaled distance, since t<=1, so its supremum is at least delta. If the input dimension is at least two, a diameter-achieving orthogonal pure input pair exists. For delta=0, any orthogonal pure pair attains the diameter. For delta>0, apply the Jordan reduction to an optimizing pair; then spectrally decompose the two orthogonally supported states and use convexity of trace norm to obtain an optimizing pure pair from those supports. If the input dimension is one, delta=0 and no orthogonal input pair exists; the main formula and construction remain unchanged, using the unique input state for both preparations.

For a qubit affine Bloch map v -> T v+c, delta is the largest singular value of T: translation cancels, and antipodal unit inputs in a maximizing direction attain it. For a classical channel, delta is the largest total-variation distance between two output columns.

For qubit depolarization Phi_e(rho)=(1-e)rho+e I/2 with 0<=e<=1, delta=1-e. For a classical BSC(q) with 0<=q<=1/2, delta=1-2q. At q=e/2 their optima (1) are equal for every M. This is a matched-diameter comparison under RAW seed mixing, not a claim about every definition of shared randomness or all quantum/classical noisy channels. For instance amplitude damping has optimized quantum diameter sqrt(1-gamma), while its fixed computational-basis classical restriction has diameter 1-gamma.

At delta=0 formula (1) becomes 2A/M. At delta=1 it becomes A/[1+(M-2)p]. At p=1/2 it extends directly to 1/M. The noiseless backward endpoint p=0 is excluded here because arbitrary protocols can have zero normalizers; extending it requires a separate admissibility convention.

## 9. Scope limitations and research status

A bounded primary-source literature screening has been completed; see `related_work.md`. No identical restricted-model formula was located in the checked material. This is not originality certification: a direct reduction to an existing result remains possible. The contraction coefficient and optimization ingredients are established mathematics. AI-assisted mathematical verification is documented in `verification_report.md`; independent human review of the model, proof and bibliography remains pending. The prior seed-forbidden model and the present raw-seeded model have different resource assumptions. No physical backward communication channel is demonstrated.
