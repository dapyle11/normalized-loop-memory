"""Reproduce and compare both verification suites without modifying reference data."""
from pathlib import Path
import hashlib
import json
import math
import os
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def main():
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest,
                'Integrity mismatch: ' + name)
    env = os.environ.copy()
    env.pop('PYTHONOPTIMIZE', None)
    with tempfile.TemporaryDirectory(prefix='shared_seed_checks_') as work:
        first = subprocess.run([sys.executable, str(ROOT / 'verify.py')],
                               cwd=work, env=env, text=True, capture_output=True, check=True)
        observed = json.loads((Path(work) / 'verification_results.json').read_text())
        reference = json.loads((ROOT / 'verification_results.json').read_text())
        require(observed == reference, 'Exact verification results differ from reference')
        second = subprocess.run([sys.executable, str(ROOT / 'audit_checks.py')],
                                cwd=work, env=env, text=True, capture_output=True, check=True)
        observed_audit = json.loads(second.stdout)
        reference_audit = json.loads((ROOT / 'audit_results.json').read_text())
        require(observed_audit.keys() == reference_audit.keys(), 'Audit keys differ')
        for key, expected in reference_audit.items():
            actual = observed_audit[key]
            if isinstance(expected, float):
                require(math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-12),
                        'Floating-point audit mismatch: ' + key)
            else:
                require(actual == expected, 'Audit mismatch: ' + key)
    print(json.dumps({'status': 'PASS', 'manifest': 'verified',
                     'verification': json.loads(first.stdout),
                     'audit': observed_audit}, indent=2))

if __name__ == '__main__':
    main()
