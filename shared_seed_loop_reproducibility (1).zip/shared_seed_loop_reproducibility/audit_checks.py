"""Independent theorem checks. No optimization or novelty certification claimed."""
import json
from fractions import Fraction as F
import numpy as np
rng=np.random.default_rng(871036)

def state(d):
    z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
    r=z@z.conj().T
    return r/np.trace(r)
def effect(d):
    z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
    u,_=np.linalg.qr(z)
    return (u*rng.random(d))@u.conj().T

def run():
    exact=0
    for M in range(2,13):
      for p in [F(1,100),F(1,10),F(1,4),F(49,100),F(1,2)]:
       for delta in [F(0),F(1,7),F(1,2),F(1)]:
        k=1-2*p; A=1-p
        target=2*A/(M-(M-2)*k*delta)
        ws=[]; zs=[]
        for m in range(M):
          ws.append(sum(A if m in [s,(s+1)%M] else 0 for s in range(M))/M)
          zs.append(sum(F(1) if m in [s,(s+1)%M] else 1-k*delta for s in range(M))/M)
        assert all(w/z==target for w,z in zip(ws,zs))
        assert (1+k*delta)/(M-(M-2)*k*delta)<=target
        exact+=1
    # General randomized quantum instrument blocks with seed mixing. Channels
    # include qutrit depolarization and qubit amplitude damping with exact diameters.
    largest_excess=-1.; smallest_Z=10.; random_cases=0
    for trial in range(1800):
      M=int(rng.integers(2,9)); S=int(rng.integers(1,6))
      p=float(rng.uniform(.00001,.49999)); k=1-2*p
      if trial%2:
        d=3; noise=float(rng.random()); delta=1-noise
        phi=lambda r:(1-noise)*r+noise*np.trace(r)*np.eye(d)/d
      else:
        d=2; gamma=float(rng.random()); delta=np.sqrt(1-gamma)
        K0=np.diag([1,np.sqrt(1-gamma)]); K1=np.array([[0,np.sqrt(gamma)],[0,0]])
        phi=lambda r:K0@r@K0.T+K1@r@K1.T
      q=rng.dirichlet(np.ones(S)); w=np.zeros((M,M))
      for s in range(S):
        # independent full mixed-state blocks, with arbitrary label distributions
        blocks=[[a*phi(state(d)) for a in rng.dirichlet(np.ones(M))] for b in range(2)]
        for m in range(M):
          E=effect(d)
          for y in range(M):
            r0,r1=blocks[0][y],blocks[1][y]
            w[m,y]+=q[s]*(p*np.trace(r0).real+(1-p)*np.trace(r1).real+k*np.trace(E@(r0-r1)).real)
      Z=w.sum(axis=1); D=np.trace(w); Q=Z.sum()
      bound=2*(1-p)/(M-(M-2)*k*delta)
      assert min(Z)>=2*p-1e-12 and max(Z)<=2*(1-p)+1e-12
      assert min(np.diag(w)/Z)<=D/Q+1e-12
      assert D/Q<=bound+1e-12
      largest_excess=max(largest_excess,D/Q-bound); smallest_Z=min(smallest_Z,min(Z)); random_cases+=1
    # Exact noncommutation example, M=4, noiseless forward channel.
    raw=(F(9,10)*2)/(2+2*F(1,5)); external=F(9,10)*2/4
    assert raw==F(3,4) and external==F(9,20)
    # M=1 output always equals the only message, regardless of normalizer.
    for p in [F(1,100),F(1,10),F(1,2)]:
      for z in [2*p,F(1),2*(1-p)]: assert z/z==1
    return dict(exact_achiever_cases=exact,random_quantum_protocols=random_cases,largest_aggregate_minus_upper_bound=largest_excess,smallest_random_normalizer=smallest_Z,raw_example=str(raw),external_example=str(external),M1_success='1',status='PASS',seed=871036)
if __name__=='__main__':
    result=run(); print(json.dumps(result,indent=2))
